/* File: settings.cpp
 * Author: Ryan Barrett (rbarret@stanford.edu)
 * --------------------
 * CS248 Fall 2001
 * HW3 - Video Game
 *
 * Defines the CSettings class. For more information, see settings.h.
 */

#include "settings.h"	// stl stuff (including string) is #included in stlini.h


// -----------------------------------------------------------------------------
// INITIALIZE STATIC MEMBERS
// -----------------------------------------------------------------------------
const string	CSettings::kFilename("tictactoe.ini");
INIFile			CSettings::sFile;
bool			CSettings::sLoaded = false;


// -----------------------------------------------------------------------------
// PRIVATE METHODS
// -----------------------------------------------------------------------------
void CSettings::Load()
{
  if (!sLoaded) {
	sFile = LoadIni(kFilename.c_str());
	sLoaded = true;
  }
}

