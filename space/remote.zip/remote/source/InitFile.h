/* File: InitFile.h
 * Author: Ryan Barrett
 * --------------------
 * InitFile is an initialization file manager. It manages both reading from and
 * writing to a section of an init file. InitFile reads lines and stores a key
 * and a value. The client can ask for the value that matches a given key at
 * any time. The value can be returned as one of many types. The client can
 * also ask for a list of all keys in the given section of the init file.
 *
 * The maximum line length is 255 characters. If necessary, you can change this
 * by changing the MAX_LINE_LEN constant.
 *
 * TODO: fix write so it preserves other sections
 */

#ifndef _INITFILE_H
#define _INITFILE_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


// constants
#define MAX_LINE_LEN			255
#define GROW_BY					10
#define SECTION_PREFIX			'['
#define SECTION_SUFFIX			']'
#define EQUALS_CHAR				'='

// error codes
#define IF_ERR_NONE				0
#define IF_ERR_MEM				1
#define IF_ERR_BAD_FILENAME		2
#define IF_ERR_BAD_SECTION		3
#define IF_ERR_BAD_LINE			4
#define IF_ERR_KEY_NOT_FOUND	5
#define IF_ERR_CANNOT_CONVERT	6
#define IF_ERR_BAD_LINENO		7

// error messages
#define IF_ERRM_UNKNOWN			"Unknown error."
#define IF_ERRM_NONE			"No error."
#define IF_ERRM_MEM				"Out of memory."
#define IF_ERRM_BAD_FILENAME	"Invalid filename."
#define IF_ERRM_BAD_SECTION		"Invalid section."
#define IF_ERRM_BAD_LINE		"Invalid line. Continuing..."
#define IF_ERRM_KEY_NOT_FOUND	"Key not found."
#define IF_ERRM_CANNOT_CONVERT	"Cannot convert value to given type."
#define IF_ERRM_BAD_LINENO		"Invalid line number."



// line type
struct line {
	char *key;
	char *value;
};


class InitFile {
public:

	/* ctor
	 * ----
	 * Takes a filename and a section name.
	 *
	 * Call getError after creating an InitFile object. If getError returns
	 * IF_ERR_NONE, the object was created successfully. If it returns
	 * IF_FILE_NOT_FOUND, the init file was not found. In this case, the
	 * getValue methods will fail but the write and setValue methods will
	 * succeed (barring other errors).
	 *
	 * If getError returns anything else, the constructor failed and the object
	 * should not be used.
	 */
	InitFile(char *filename, char *section);


	/* destructor
	 * ----------
	 * Frees the stored init file lines and other allocated memory.
	 */
	~InitFile();


	/* getValue
	 * --------
	 * Gets the value associated with the given key. getValue is overloaded to
	 * automatically convert the value to some datatypes.
	 *
	 * getValue returns true if successful, false otherwise. If the key is not
	 * found, getError will return IF_ERR_KEY_NOT_FOUND. If the file was not
	 * found, getError will return IF_ERR_BAD_FILENAME. If the value could not
	 * be converted to the specified type, getError will return
	 * IF_ERR_VALUE_BAD_TYPE.
	 */
	template <typename T> bool getValue(char *key, T *value);
	bool getValue(char *key, char *value, size_t size);


	/* getNumLines
	 * -----------
	 * Returns the number of lines currently stored. This can be 0.
	 */
	int getNumLines();


	/* getKey
	 * ------
	 * Fills in the key for the given line. Used with getNumLines, getLine can
	 * be used to walk an init file when the client may not know all of the
	 * keys explicitly. The size parameter gives an upper bound for the number
	 * of characters written to key.
	 *
	 * getLine returns true if successful, false otherwise. If lineNo is < 0
	 * or > num lines, getError will return IF_ERR_BAD_LINENO.
	 */
	bool getKey(int lineNo, char *key, size_t size);


	/* setValue
	 * --------
	 * Sets the value assocated with the given key. setValue is overloaded to
	 * automatically convert the value from some datatypes.
	 *
	 * setValue returns true if successful, false otherwise.
	 */
	template <typename T> bool setValue(char *key, T value);
	bool setValue(char *key, char *value);


	/* write
	 * -----
	 * Writes the current values out to the file.
	 *
	 * write returns true if successful, false otherwise.
	 */
	bool write();


	/* getError
	 * --------
	 * Returns the error code of the last error, or -1 if no errors have
	 * occurred yet.
	 */
	int getError();

		
	/* getErrorMsg
	 * -----------
	 * Returns the error message associated with the given error code.
	 */
	char *getErrorMsg(int err);


protected:

	// protected methods
	bool read();
	bool addLine(char *key, char *value);
	int findKey(char *key);
	bool growLines();
	void freeLines();

	// protected members
	char *filename;
	char *section;

	// numLines is number of actual lines, allocLines is size of lines array
	int numLines, allocLines;		
	struct line *lines;

	int error;

};





#endif /* _INITFILE_H */
