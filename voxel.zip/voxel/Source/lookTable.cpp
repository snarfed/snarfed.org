/* File: lookTable.cpp
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Implements the lookTable class. For more information, see lookTable.h.
 */


#include "lookTable.h"


/* ctor
 */
lookTable::lookTable(int fov, int width) {
	assert(fov > 1 && fov < 225);

	// calculate look_360
	look_360 = width * 360 / fov;

	// create lookup table
	table = new fixp[LOOK_360];
	if (!table) Err("Out of memory.");

	// build lookup table. it stores sin - cos is sin(angle + LOOK_90)
	for (lookAngle l = 0; l < LOOK_360; l++) {
		double angle = (double)l * 2 * PI / (double)LOOK_360;
		table[l] = (fixp)(sin(angle) * FIXP_MULT);
	}
}


/* dtor
 */
lookTable::~lookTable() {
	DEL(table);
}


/* cos
 */
fixp lookTable::lcos(lookAngle langle) {
	langle += LOOK_90;

	if (langle < 0)
		return(table[langle + LOOK_360]);
	else if (langle >= LOOK_360)
		return(table[langle - LOOK_360]);
	else
		return(table[langle]);
}


/* sin
 */
fixp lookTable::lsin(lookAngle langle) {
	if (langle < 0)
		return(table[langle + LOOK_360]);
	else if (langle >= LOOK_360)
		return(table[langle - LOOK_360]);
	else
		return(table[langle]);
}

