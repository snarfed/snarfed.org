Remote
http://snarfed.org/space/remote

Copyright 2000 Ryan Barrett <remote@ryanb.org>
http://ryan.barrett.name/

========

Remote is a client for httpQ (http://httpq.sf.net/), a network server plugin
for Winamp (http://winamp.com/). You can use remote to control an
httpQ-enabled Winamp over the Internet. Remote can control playback, manage
playlists, search and find songs, and show Winamp's status in real time.

Winamp is commonly used with Shoutcast (http://shoutcast.com/) as a streaming
audio platform, for anything from listening to your music remotely to running
a full-blown Internet radio station. With remote, you can control your
Shoutcast/Winamp platform from anywhere.

This package includes the full source code and Visual Studio project files for
building remote on Windows.

Remote is distributed under the GPL. See the LICENSE file for more
information. Copyright 2000 Ryan Barrett.
