//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Remote.rc
//
#define IDD_REMOTE                      101
#define IDD_QUERYBOX                    104
#define IDD_JUMPBOX                     105
#define IDR_ACCELERATOR1                106
#define IDC_BACK                        1001
#define IDC_PREVIOUS                    1001
#define IDC_PLAY                        1002
#define IDC_PAUSE                       1003
#define IDC_STOP                        1004
#define IDC_NEXT                        1005
#define IDC_OPEN                        1006
#define IDC_PLAYLIST                    1007
#define IDC_REPEAT                      1008
#define IDC_SHUFFLE                     1009
#define IDC_CONNECT                     1010
#define IDC_PASSWORD                    1011
#define IDC_ADDRESS                     1012
#define IDC_PORT                        1013
#define IDC_STATUS                      1014
#define IDC_TIME                        1015
#define IDC_CLEAR                       1016
#define IDC_RESPONSE                    1017
#define IDC_JUMP                        1017
#define IDC_PROMPT                      1018
#define IDC_FIND                        1018
#define IDC_SEARCH                      1020
#define IDC_ABOUT                       1027
#define IDA_JUMP                        40001
#define IDA_PREVIOUS                    40002
#define IDA_PLAY                        40003
#define IDA_PAUSE                       40004
#define IDA_STOP                        40005
#define IDA_NEXT                        40006
#define IDA_OPEN                        40007
#define IDA_FIND                        40008
#define IDA_UP                          40010
#define IDA_ABOUT                       40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
