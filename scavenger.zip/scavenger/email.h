/* File: email.h
 * Author: Ryan Barrett
 *
 * Defines a bare-bones email address class, derived from string, for use with
 * the email address scavenger written for Richard Barrett, 11/23/2002.
 *
 * Most necessary methods are already implemented by string. However, this class
 * implements a few interesting methods, including is_email, is_email_char,
 * sanitize, and operator<. See the method comments for more details.
 **/

#ifndef _EMAIL_H
#define _EMAIL_H

#include <string>
#include <cassert>

using namespace std;


/******************************************************************************
 * CEMAIL CLASS
 ******************************************************************************/
class cemail : public string
{
  public:

	/* copy ctor, char* ctor
	 *
	 * Throws an assertion if the paraameter does not pass the is_email
	 * heuristic test.
	 **/
	cemail(const string &orig) : string(orig) { assert(is_email(*this)); }
	cemail(const char *orig)   : string(orig) { assert(is_email(*this)); }


	/* is_email
	 *
	 * This is a crude heuristic function that determines whether a string is or
	 * isn't an email address, based on a few notable characteristics -
	 * specifically, existence of the '@' character and at least one '.'
	 * character after the '@'.
	 **/
	static bool is_email(const string &token);


	/* is_email_char
	 *
	 * Returns true if the character is a letter, a digit, an underscore, or a
	 * dot, false otherwise.
	 **/
	static bool is_email_char(char c);


	/* get_host, get_username
	 *
	 * Accessors for the two parts of the email address.
	 **/
	string get_host() const;
	string get_username() const;


	/* sanitize
	 *
	 * Removes garbage characters from the beginning and end of the email
	 * address, and converts it to lowercase. For example, if a cemail stored
	 * the email address to "<ryan@stanford.EDU>", then calling sanitize on it
	 * would change the stored email address to "ryan@stanford.edu".
	 **/
	void sanitize();


	/* operator<, operator<=, operator>, operator>=
	 *
	 * Overloads the comparison operators. Defines a linear ordering on email
	 * addresses, based on the lexicographic ordering of the hostname first,
	 * then the username.
	 *
	 * In other words, given two email addresses x@a and y@b (where x, y, a, b
	 * are strings), then operator< is defined s.t.:
	 *
	 *   x@a < y@b  <==>  a < b V (a == b && x < y)
	 *
	 * Note that operator<=, operator>, and operator>= are defined in terms of
	 * operator<.
	 **/
	bool operator< (const cemail& operand) const;

	bool operator<= (const cemail& operand) const
		{ return (*this < operand || *this == operand); }

	bool operator> (const cemail& operand) const
		{ return (*this != operand && !(*this < operand)); }

	bool operator>= (const cemail& operand) const
		{ return (*this > operand || *this == operand); }


  private:
	static bool not_email_char(char ch);

	iterator find_at();
	const_iterator find_at() const
		{ return const_cast<cemail *>(this)->find_at(); }

	// disallow default ctor
	cemail();
};

#endif	// _EMAIL_H
