/* File: Jump.cpp
 * Author: Ryan Barrett
 * --------------------
 *
 * Implements a jump to file dialog box.
 * See Jump.h for more details.
 */


#include "Jump.h"



// private methods
BOOL CALLBACK JumpProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK EditProc(HWND hedit, UINT msg, WPARAM wParam, LPARAM lParam);
bool RefreshList(HWND hdlg, char **playlist, int len);
char *strtoupper(char *str);


// global vars
WNDPROC oldEditProc;



bool JumpBox(HINSTANCE hInstance, HWND hwnd, QServer *server, int *pos) {
	int jumpto;

	if (hInstance == NULL || hwnd == NULL || pos == NULL)
		return false;

	jumpto = DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_JUMPBOX),
		hwnd, (DLGPROC)JumpProc, (LPARAM)server);

	if (jumpto == -2)	// cancelled
		return false;
	*pos = jumpto;		// successful
	return true;
}



/* JumpProc
 * --------
 * Window procedure for the dialog box.
 */
BOOL CALLBACK JumpProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam) {
	static QServer *server;
	static char **playlist;
	static int len;

	switch (msg) {

	case WM_INITDIALOG:	// startup
		HWND hwnd, hwndSearch;

		hwnd = GetParent(hdlg);
		hwndSearch = GetDlgItem(hdlg, IDC_SEARCH);
		server = (QServer *)lParam;

		// subclass the edit box wndproc
		oldEditProc = (WNDPROC)SetWindowLong(hwndSearch, GWL_WNDPROC,
			(LONG)EditProc);

		// create the playlist
		server->getPlaylist(false, &playlist, &len);
		RefreshList(hdlg, playlist, len);
		return true;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {

		case IDC_SEARCH:
			if (HIWORD(wParam) == EN_CHANGE)
				RefreshList(hdlg, playlist, len);
			return true;

		case IDOK:
			int pos, i;
			char titleBuf[BUF_LEN];

			// return selected song on success
			pos = SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_GETCURSEL, 0, 0);
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_GETTEXT, (WPARAM)pos,
				(LPARAM)titleBuf);
			for (i = 0; i < len; i++)
				if (strcmp(titleBuf, playlist[i]) == 0) break;

			if (i == len) i = -2;	// return -2 on failure
			EndDialog(hdlg, i);
			return true;

		case IDCANCEL:
			EndDialog(hdlg, -2);	// return -2 on failure
			return true;
		}
		return false;

	default: break;		// other message, don't process
	}

	return false;	// message was not processed
}



/* EditBox
 * -------
 * My edit control window procedure. I subclass the default one so I can
 * intercept WM_KEYDOWN for the down arrow key and the enter key.
 */
BOOL CALLBACK EditProc(HWND hedit, UINT msg, WPARAM wParam, LPARAM lParam) {
	HWND hdlg;
	int sel;

	hdlg = GetParent(hedit);

	switch (msg) {

	case WM_KEYDOWN:
		sel = SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_GETCURSEL, 0, 0);
		switch (wParam) {
		case VK_DOWN:		// down arrow, move down in playlist
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_SETCURSEL,
				(WPARAM)(sel + 1), 0);
			break;

		case VK_UP:
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_SETCURSEL,
				(WPARAM)(sel - 1), 0);
			break;

		case VK_RETURN:		// enter, send ID_OK to dialog box
			SendMessage(hdlg, WM_COMMAND, (WPARAM)IDOK, 0);
			return true;
		}

	default: break;

	}

	return CallWindowProc(oldEditProc, hedit, msg, wParam, lParam);
}





/* RefreshList
 * -----------
 * Refreshes the visible list to only show songs with the search text in their
 * title.
 */
bool RefreshList(HWND hdlg, char **playlist, int len) {
	char search[BUF_LEN], searchToks[BUF_LEN], title[BUF_LEN];
	char *tok;
	int sel, lineLen;

	// get the search text
	*(WORD *)search = BUF_LEN - 1;
	lineLen = SendDlgItemMessage(hdlg, IDC_SEARCH, EM_GETLINE, 0, (DWORD)search);
	search[lineLen] = '\0';
	strtoupper(search);

	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_RESETCONTENT, 0, 0);

	for (int i = 0; i < len; i++) {		// check each song title
		strcpy(title, playlist[i]);
		strtoupper(title);
		strcpy(searchToks, search);

		tok = strtok(searchToks, WHITESPACE);
		while (true) {		// check each token in the search string
			if (!tok) {		// no more tokens
				SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_ADDSTRING, 0,
					(LPARAM)playlist[i]);
				break;
			}
			if (!strstr(title, tok)) break;
			tok = strtok(NULL, WHITESPACE);
		}
	}

	// select the topmost visible song
	sel = SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_GETTOPINDEX, 0, 0);
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_SETCURSEL,
		(WPARAM)sel, 0);

	return true;
}



/* strtoupper
 * ----------
 * Converts the given string to uppercase.
 */
char *strtoupper(char *str) {
	if (str == NULL) return NULL;
	for (int i = 0; i < (int)strlen(str); i++)
		str[i] = toupper(str[i]);
	return str;
}
