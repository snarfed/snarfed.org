/* File: util.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Random utility macros, constants, and functions.
 */

#ifndef _UTIL_H
#define _UTIL_H

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include <math.h>

// forward declaration (header is included in util.cpp)
class framebuffer;

// constants
#define BUF_LEN		1024

// smarter free
#define FREE(ptr)	{ assert(ptr); free(ptr); (ptr) = NULL; }
// smarter delete
#define DEL(ptr)	{ assert(ptr); delete (ptr); (ptr) = NULL; }
// smarter array delete
#define ARRAYDEL(ptr) { assert(ptr); delete[] (ptr); (ptr) = NULL; }

// MIN and MAX
#define MIN(x, y)	(((x) < (y)) ? (x) : (y))
#define MAX(x, y)	(((x) > (y)) ? (x) : (y))

// ABS
#define ABS(num) (((num) >= 0) ? (num) : -(num))

// SIN, COS, TAN for angles in degrees
#define PI_OVER_180	(3.14159265 / 180)
#define COS(a)		(float)cos((a) * PI_OVER_180)
#define SIN(a)		(float)sin((a) * PI_OVER_180)
#define TAN(a)		(float)tan((a) * PI_OVER_180)



// utility functions

/* Err
 * ---
 * Writes the error message to stderr (with printf-style arguments) and exits.
 */
void __cdecl Err(char *msg, ...);


/* project
 * -------
 * Projects the given point onto the viewplane and draws it in the framebuffer.
 * The point is given by its 3D polar coordinates (r,theta,phi). These are
 * relative to the camera's position and orientation. The point's color is
 * (r,g,b).
 */
void project(framebuffer *fb, int theta, int phi,
			 unsigned char r, unsigned char g, unsigned char b);

/* powof2
 * ------
 * Returns true if the number is a power of 2, false otherwise. If num is less
 * than 0, powof2 returns false.
 */
bool powof2(int num);

#endif /* _UTIL_H */