/* File: Remote.cpp
 * Author: Ryan Barrett 6/26/2000
 * ------------------------------
 * Remote is a windows-based remote control program for any Shoutcast server
 * with a Winamp server running httpQ as the audio source. You can get
 * Shoutcast at http://www.shoutcast.com/ and httpQ at http://www.winamp.com/
 * in the plugins section.
 *
 * TODO:
 * - redesign qserver so i can process messages while waiting for the server
 *   sort of works, but still not great. asynchronous stuff in IE SDK sucks!
 * - migrate syncing to QServer
 * - do memory instrumentation and logging code
 *
 * BUGS:
 * - connect to an IP that's valid but offline (ex. 171.99.66.12), remote waits
 * for 15 seconds or so before timing out. not really a bug, but annoying.
 *
 * 9/9 - Fixed bug where clicking before the cursor on the slider closed the
 * program. evidently, IDCANCEL (for closing the dialog box) and TB_PAGEDOWN
 * (for page down or click below cursor on the slider) have the same value: 2.
 * moral of the story...don't mix code for handling WM_HSCROLL and WM_COMMAND
 * messages. ideally, don't mix handling for more than one type of message, but
 * I mix WM_COMMAND and WM_NOTIFY handling in UI. oh well...
 * 9/2 - I was working on InitFile for a while...I forgot when I started. maybe
 * a week or two ago. anyway, it's in and it works...remote remembers the last
 * address/port/password you used, very cool.
 * I also added a ShutdownRemote function and I finally deleting the qserver
 * which I didn't even realize I wasn't deleting. but it's causing problems
 * right now. i'm going to back up first...ok, fixed. the DEL macro was wrong.
 * 8/17 - added more checking for available net connection in QServer::sendCmd.
 * also I check the global offline state and, if the user is offline, I ask to
 * go online.
 * added a build date constant that is shown in the about box.
 * fixed a bug where jump would jump to the wrong song if sort by title was on.
 * I want to make an init file that will save the address, port, and password
 * automatically. I want to make it do The Right Thing, though, so I'm going
 * to make an InitFile class.
 * 8/12 - ok, so this one was weird. on nt/2000, jump worked fine. on 95/98,
 * it wouldn't display anything until you typed in a character. then it showed
 * songs, but only when the edit box had one and only one character. weird. so
 * I debugged on a 98 box and fixed it, but i'm still not sure exactly what
 * caused it. oh well. I also put "waiting for response" back in, so if you
 * try to connect to an IP that's valid but is offline, at least you know why
 * it's waiting so long.
 * added an about button. whee....that's my cue. i'm locking down the code. :P
 * 8/11 - added hot tracking to the playlist. the songs light up when the mouse
 * is over them. whee. also more random stuff to improve stability.
 * 8/7 - more and more minor housekeeping...it's almost done! if a command
 * times out, it won't clear the playlist.
 * 8/6 - moved error messages to QServer - on error, it sets the response
 * string to the error message. also clears the playlist if QServer isn't
 * connected after any command.
 * 8/5 - doing general housecleaning. it maintains the playing toggle better,
 * checks to see if it's connected more often, and it's happy with an empty
 * playlist. and it's more stable in general. also set up more checks for bad
 * address/port/whatever
 * 8/4 - current song works completely now, erasing the mark on the old song
 * works. minimizing then restoring works - focus goes back to the dialog.
 * changed errors so the error is written to the status box instead of brought
 * up in a message box.
 * 8/1 - added column headers and sorting...click on the column headers!
 * setting the current song somewhat works when the list is sorted. the
 * current song is marked, but it scrolls to the wrong place and doesn't
 * erase the previous song. details.
 * 7/31 - I fought asynchronous stuff for a LONG time and finally figured it
 * out....and it still doesn't work. so basically, this is what's up. Call
 * InternetSetStatusCallback on the HINTERNET you get from InternetOpen. You
 * don't need to call it after that. Then the call to InternetOpenUrl is
 * treated as asynchronous and will use the given callback. The other trick is,
 * you can't just call PostMessage from the callback with NULL as the hwnd
 * because it's a different thread. so I passed the top-level hwnd of Remote
 * as the context and grabbed that in the callback, and everything was ok. BUT.
 * Any asynchronous operation (read: any WinInet call) WILL RETURN FALSE if
 * it's asynchronous. if you call GetLastError immediately after, it should
 * return ERROR_IO_PENDING if all went well. so far so good. this works fine
 * with InternetOpenUrl - it returns false and ERROR_IO_PENDING, calls the
 * callback, I return when I see INTERNET_STATUS_REQUEST_COMPLETE, and I move
 * on. but I can't get it to work with InternetQueryDataAvailable. it just
 * returns false indefinitely and never calls the callback. GetLastError
 * returns error 12018, which I can't find defined anywhere. goddammit.
 * so I'm going back to synchronous for now and doing other things on the TODO
 * list. sigh.
 * 7/30 - listview is done! there are separate columns for song title, playlist
 * index, and currently playing song. I added a button - find - that scrolls
 * the playlist to bring the currently playing song into sight. I updated
 * Sync to only scroll the currently playing song (the marked song) into sight
 * if it just changed or if the user changed it. The listview even has pretty
 * colors! (mmm....colors....) so. that's good. i'm going to sleep.
 * 7/23 - man, it's been a while. ok, so i'm still fighting the listview
 * control. it shows the songs in everything but report view. i don't want to
 * use any of the other views. I first tried giving the listview control the
 * song titles, but now I'm trying the callback way instead, so the control
 * asks me every time it wants a song title. we'll see if that works.
 * 7/8 - redid sendCmd in QServer and response storage. sendCmd now resizes
 * its download buffer to accomodate any size http reply. finishing up the
 * retrofit up the new playlist d/l method.
 * when I allocate the playlist array, have to allocate room for 1 more
 * string than the playlist length or else free messes up. why?
 * 7/7 - reverted to the backup before the list view control. i'll get it
 * working eventually, i just have some cool ideas i want to try out right
 * now and i don't feel like fighting it at the moment.
 * i'm going to try getting the playlist all at once and parsing it, instead
 * of getting one song at a time. it should be faster.
 * i think i might also be able to fix the inability to process messages
 * while waiting for the server, too! check the waitForResponse() call
 * 7/6 - basically all i did today was try to get the list view control to
 * show my damn songs. they get added successfully, they just don't appear.
 * grr.
 * 7/5 - tried to get processing while internet requests are outstanding. it's
 * not as good as i'd like, but close enough. also, I made the slider disable
 * itself if we're not connected or not playing. the slider moving back bug
 * is really weird though. i have no idea what's causing it.
 * 7/4 - random stuff. pressing enter in the playlist plays the song. (I had
 * to subclass the list control window. grr.) accelerators aren't processed
 * while edit boxes have the focus (a very good thing.) 
 * 7/3 - finished jump. scrolling with up and down keys in the text box works.
 * also other little fixes to jump
 * 7/2 - implemented jump. i also got tab and accelerators to work. and little
 * things...it works like a normal app and everything. there are still some
 * weird little glitches though. mostly dealing with the window.
 * 7/1 - various fixes. title bar shows the current song. remote now checks the
 * server every 10 seconds to see if the song, position, or playlist has
 * changed. little tweaks to slider and other stuff.
 * 6/30 - I added a slider and got setting the position in the song to work. I
 * also implemented adding files and playlists. I still need to do delete tho.
 * added the clear button. it's a cute little division sign. :P
 * preliminary syncing to server works.
 * 6/29 - i'm building the listbox stuff. later i need to make it politely
 * process messages while waiting for responses from the server. not now tho.
 * also, when a song is selected (double-clicked or pressed enter on), i get
 * that song with LB_GETCARETINDEX because i'm lazy. can this cause problems?
 * no. it's fine. nevermind.
 * I'm also changing repeat and shuffle so you can only toggle. i'll leave in
 * the old stuff tho, just commented out.
 * repeat and shuffle are changed back. the problem was in getStatus()...repeat
 * and shuffle are golden now. i'm done for the night.
 * 6/28 - I'm building sendCmd() in QServer. I still need to put some kind of
 * error handling system into QServer (to give the QServer client information
 * if a server error occurs, if it doesn't respond, etc. i'll get to that
 * later.)
 * 6/27 - for a dialog box (at least a modeless one, one created with
 * CreateDialog()), GetParent() doesn't get the parent window handle. use
 * GetWindowLong(<dialog box handle>, GWL_HWNDPARENT).
 * everything's happy except i can't get the dialog box to act as the app - it
 * doesn't minimize to the system tray, etc. oh well. not a big deal.
 * also, I created the QServer class. it will deal with server communication;
 * remote.cpp will deal with ui stuff solely. it will own a QServer instance
 * and send and receive info through that.
 * 6/26 - created. check what RegisterClassEx() returns.
 */


#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"
#include "QServer.h"
#include "QueryBox.h"
#include "Jump.h"
#include "InitFile.h"


// predefined constants
#define BUILD_DATE			"9/9/2000"

#define REMOTE_CLASS_NAME	"Remote"
#define REMOTE_CAPTION		"Remote"
#define DIALOG_NAME			"IDD_REMOTE"
#define DEF_PORT			4800
#define ADDRESS_KEY			"address"
#define PASSWORD_KEY		"password"
#define	PORT_KEY			"port"
#define INITFILE_FILENAME	"remote.ini"
#define NO_CONNECTION		"Could not connect to server."
#define BUF_LEN				200
#define TM_ADVANCE_ID		1
#define TM_ADVANCE_INT		1000
#define TM_CHECK_ID			2
#define TM_CHECK_INT		10000
#define TIC_FREQ			30	
#define DLGBOX_CLASS_NAME	"#32770"
#define MAX_STATUS_LEN		80
#define HOVER_TIME			3600000
#define ABOUT_MSG \
">Remote<\t\t\t     (C) 2000 Ryan Barrett\n\t\t\t\t       build date %s\n\n\
Thanks to Ken Ashcraft, Hal Daum�, Maulik Shah, and Grant Yang\n\
for beta testing and listening to my constant rantings and ravings."


// playlist constants
#define PLAYLIST_COLOR_TEXT	0x00e6f0fa
#define PLAYLIST_COLOR_BKG	0x00b48246
#define PLAYLIST_SONG_SUB	0
#define PLAYLIST_IND_SUB	1
#define PLAYLIST_CUR_SUB	2
#define PLAYLIST_SONG_CAP	"Song Title"
#define PLAYLIST_IND_CAP	"#    "	
#define PLAYLIST_CUR_CAP	""
#define PLAYLIST_MARKER		">"
#define PLAYLIST_MARKER_LP	101
#define PLAYLIST_WIDTH		251
#define PLAYLIST_IND_FRAC	.12
#define PLAYLIST_CUR_FRAC	.05
#define PLAYLIST_IND_WIDTH	(int)(PLAYLIST_WIDTH * PLAYLIST_IND_FRAC)
#define PLAYLIST_CUR_WIDTH	(int)(PLAYLIST_WIDTH * PLAYLIST_CUR_FRAC)
#define PLAYLIST_SONG_WIDTH	(int)(PLAYLIST_WIDTH * (1 - PLAYLIST_IND_FRAC - PLAYLIST_CUR_FRAC))



// macros

/* DEL
 */
#define DEL(ptr)	if (ptr) delete(ptr); (ptr) = NULL;

/* MBOX
 * messagebox macro, for debugging
 */
#define MBOX(string)		MessageBox(hdlg, (string), "Remote", MB_OK)

/* ERRBOX
 * specific messagebox macro, for errors
 */
#define ERRBOX() \
	{ char errbuf[BUF_LEN] = ""; \
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, \
		NULL, GetLastError(), 0, errbuf, BUF_LEN - 1, NULL); \
	MBOX(errbuf); }

/* SET_STATUS
 * sets the status line to the httpQ server's response
 */
#define SET_STATUS() \
	{ char *response; server->getResponse(&response); \
	if (response) \
	SendDlgItemMessage(hdlg, IDC_STATUS, WM_SETTEXT, 0, (LPARAM)response); \
	else \
	SendDlgItemMessage(hdlg, IDC_STATUS, WM_SETTEXT, 0, (LPARAM)Q_ERRM_NONE); }

/* TEST
 * calls a given function. writes the status if it succeeds, otherwise
 * pops up an error.
 */
#define TEST(func) \
	{ bool success; \
	SetCursor(LoadCursor(NULL, IDC_WAIT)); \
	SendDlgItemMessage(hdlg, IDC_STATUS, WM_SETTEXT, 0, (LPARAM)QR_WAITING); \
	UpdateWindow(GetDlgItem(hdlg, IDC_STATUS)); \
	success = (func); SET_STATUS(); \
	SetCursor(LoadCursor(NULL, IDC_ARROW)); \
	if (!server->isConnected()) ResetPlaylist(hdlg); \
	if (!success || !server->isConnected()) return false; }


/* RESET_COL_WIDTHS
 * resets the playlist column widths to the defaults.
 */
#define RESET_COL_WIDTHS() \
{ SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETCOLUMNWIDTH, \
	PLAYLIST_SONG_SUB, MAKELPARAM(PLAYLIST_SONG_WIDTH, 0)); \
SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETCOLUMNWIDTH, \
	PLAYLIST_IND_SUB, MAKELPARAM(PLAYLIST_IND_WIDTH, 0)); \
SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETCOLUMNWIDTH, \
	PLAYLIST_CUR_SUB, MAKELPARAM(PLAYLIST_CUR_WIDTH, 0)); }




// prototypes
DWORD msgLoop(bool waitingForResponse);
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam);
bool InitRemote(HINSTANCE, int);
void ShutdownRemote(HWND hdlg, QServer *server);
void ResetPlaylist(HWND hdlg);
bool UI(HWND hdlg, QServer *server, WPARAM wParam, LPARAM lParam);
bool PlaySel(HWND hdlg, QServer *server);
bool Connect(HWND hdlg, QServer *server);
bool GetPlaylist(HWND hdlg, QServer *server);
bool Sync(HWND hdlg, QServer *server, bool initSong);
bool AdvanceSlider(HWND hdlg, QServer *server);
bool RepositionWindow(HWND hdlg);
bool FindMarker(HWND hdlg, QServer *server, int *pos, int *itemInd);
bool FindItem(HWND hdlg, LPARAM lParam, int *item);
int CALLBACK SongCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
int CALLBACK IndexCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
void CheckMessages();


// global vars
HINSTANCE hInst;
HWND globalhdlg;
HACCEL hAccel;


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	if (!InitRemote(hInstance, nCmdShow))
		return false;

	// load accelerator table
	hAccel = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_ACCELERATOR1));

	return msgLoop(false);
}



/* msgLoop
 * -------
 * Main windows message loop.
 */
DWORD msgLoop(bool waitingForResponse) {
	MSG msg;
	HWND focus;

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		// don't do accelerators if an edit box has the focus
		focus = GetFocus();
		if (focus != GetDlgItem(globalhdlg, IDC_ADDRESS) &&
			focus != GetDlgItem(globalhdlg, IDC_PORT) &&
			focus != GetDlgItem(globalhdlg, IDC_PASSWORD)) {
			if (TranslateAccelerator(globalhdlg, hAccel, &msg))
				continue;
		}

		// don't process message if it's a dialog box message
		if (IsDialogMessage(globalhdlg, &msg))
			continue;

		// message is ok, process
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}



/* WndProc
 * -------
 * The window procedure. Deals with messages to the main window (very few).
 */
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HINSTANCE hInstance;

	switch (msg) 
	{
	case WM_CREATE:
		hInstance = ((LPCREATESTRUCT) lParam)->hInstance;
		break;

	case WM_ACTIVATE:	// restore, set focus to dialog box
		SetFocus(globalhdlg);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
   }
   return 0;
}


/* DlgProc
 * -------
 * The dialog box's window procedure. Handles messages sent to the dialog box.
 */
LRESULT CALLBACK DlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static QServer server(NULL, NULL, 0);
	HWND parent;

	parent = (HWND)GetWindowLong(hdlg, GWL_HWNDPARENT);

	switch (msg) {

	case WM_INITDIALOG:	// startup
		return true;

	case WM_SYSCOMMAND:
		if (wParam == SC_MINIMIZE) {	// minimize main window with dialog box
			ShowWindow(parent, SW_MINIMIZE);
			return true;
		}
		return false;

	case WM_MOVING:		// moving - hide main window behind dialog box
		RepositionWindow(hdlg);
		return true;

	case WM_SETFOCUS:	// restore or maximize - set focus to dialog box
		Sync(hdlg, &server, true);
		break;

	case WM_COMMAND:
		if (wParam == IDCANCEL) {	// from the dialog box, user closed window
			DestroyWindow(hdlg);
			return true;
		} else if (HIWORD(wParam) == 1) {	// accelerator key
			switch (LOWORD(wParam)) {
			case IDA_ABOUT: return UI(hdlg, &server, (WPARAM)IDC_ABOUT, 0);
			case IDA_PREVIOUS: return UI(hdlg, &server, (WPARAM)IDC_PREVIOUS, 0);
			case IDA_PLAY: return UI(hdlg, &server, (WPARAM)IDC_PLAY, 0);
			case IDA_PAUSE: return UI(hdlg, &server, (WPARAM)IDC_PAUSE, 0);
			case IDA_STOP: return UI(hdlg, &server, (WPARAM)IDC_STOP, 0);
			case IDA_NEXT: return UI(hdlg, &server, (WPARAM)IDC_NEXT, 0);
			case IDA_OPEN: return UI(hdlg, &server, (WPARAM)IDC_OPEN, 0);
			case IDA_JUMP: return UI(hdlg, &server, (WPARAM)IDC_JUMP, 0);
			case IDA_FIND: return UI(hdlg, &server, (WPARAM)IDC_FIND, 0);
			default: return false;
			}
		} else		// it's not an accelerator, it's a message from a control
			return UI(hdlg, &server, wParam, lParam);


	case WM_HSCROLL:	// message from the slider
		return UI(hdlg, &server, wParam, lParam);


	case WM_NOTIFY:		// notification message
		if (wParam == IDC_PLAYLIST)		// from the playlist, send to UI
			return UI(hdlg, &server, wParam, lParam);
		else return false;
			

	case WM_TIMER:
		switch (wParam) {
		case TM_ADVANCE_ID:	// advance slider
			return AdvanceSlider(hdlg, &server);
		case TM_CHECK_ID:	// sync playlist
			if (server.isConnected())
				return Sync(hdlg, &server, false);
		default:
			return false;
		}
		return true;


	case WM_DESTROY:	// dialog box is closing; shut down remote
		ShutdownRemote(hdlg, &server);
		return true;

	default: break;		// other message, don't process
	}

	return false;
}



/* InitRemote
 * ----------
 * Performs all necessary initialization. This includes registering the window,
 * creating the dialog box, loading common controls, initializing the listview
 * control, and reading the remote init file.
 *
 * TODO: what does registerclassex return?
 */
bool InitRemote(HINSTANCE hInstance, int nCmdShow)
{
	WNDCLASS wndclass;
	HWND hwnd, hdlg;

	hInst = hInstance;

	// set up and register custom dialog box class
//	wndclass.cbSize			= sizeof(WNDCLASSEX); 
	wndclass.style			= CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc	= WndProc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= hInstance;
	wndclass.hIcon			= LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wndclass.lpszMenuName	= NULL;
	wndclass.lpszClassName	= REMOTE_CLASS_NAME;

	if (!RegisterClass(&wndclass))
		return false;

	hwnd = CreateWindowEx(WS_EX_APPWINDOW || WS_EX_CONTROLPARENT,
		REMOTE_CLASS_NAME, REMOTE_CAPTION,
		WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, 0, 0, NULL, NULL,
		hInstance, NULL);

	if (!hwnd)
		return false;

	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);


	// create dialog box
	hdlg = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_REMOTE),
		hwnd, (DLGPROC)DlgProc);
	ShowWindow(hdlg, nCmdShow);
	UpdateWindow(hdlg);
	if (!RepositionWindow(hdlg))
		return false;

	SetFocus(hdlg);
	globalhdlg = hdlg;

	// set timers
	if (!SetTimer(hdlg, TM_ADVANCE_ID, TM_ADVANCE_INT, NULL))
		MBOX("Too many timers!");
	if (!SetTimer(hdlg, TM_CHECK_ID, TM_CHECK_INT, NULL))
		MBOX("Too many timers!");

	// call InitCommonControlsEx for slider and listview control
	INITCOMMONCONTROLSEX ctls;
	ctls.dwSize = sizeof(INITCOMMONCONTROLSEX);
	ctls.dwICC = ICC_BAR_CLASSES | ICC_LISTVIEW_CLASSES;
	if (!InitCommonControlsEx(&ctls))
		ERRBOX();

	// add columns to listview
	LVCOLUMN lvc;
	memset(&lvc, 0, sizeof(LVCOLUMN));
	// song title column (main column)
	lvc.mask = LVCF_WIDTH | LVCF_ORDER | LVCF_TEXT;
	lvc.cx = PLAYLIST_SONG_WIDTH;
	lvc.iOrder = 1;
	lvc.pszText = PLAYLIST_SONG_CAP;
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_INSERTCOLUMN, 0, (LPARAM)&lvc);
	// currently playing mark column
	lvc.mask = LVCF_WIDTH | LVCF_ORDER | LVCF_SUBITEM | LVCF_TEXT;
	lvc.cx = PLAYLIST_CUR_WIDTH;
	lvc.iSubItem = PLAYLIST_CUR_SUB;
	lvc.iOrder = 0;
	lvc.pszText = PLAYLIST_CUR_CAP;
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_INSERTCOLUMN, 1, (LPARAM)&lvc);
	// playlist index column
	lvc.mask = LVCF_WIDTH | LVCF_ORDER | LVCF_SUBITEM | LVCF_FMT | LVCF_TEXT;
	lvc.fmt = LVCFMT_RIGHT;
	lvc.cx = PLAYLIST_IND_WIDTH;
	lvc.iSubItem = PLAYLIST_IND_SUB;
	lvc.iOrder = 1;
	lvc.pszText = PLAYLIST_IND_CAP;
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_INSERTCOLUMN, 1, (LPARAM)&lvc);
	// set listview colors
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETTEXTCOLOR, 0,
		(COLORREF)PLAYLIST_COLOR_TEXT);
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETTEXTBKCOLOR, 0,
		(COLORREF)PLAYLIST_COLOR_BKG);
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETBKCOLOR, 0,
		(COLORREF)PLAYLIST_COLOR_BKG);
	RESET_COL_WIDTHS();
	// set hot tracking
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETEXTENDEDLISTVIEWSTYLE,
		LVS_EX_TRACKSELECT, LVS_EX_TRACKSELECT);
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETHOVERTIME, 0,
		(LPARAM)(DWORD)HOVER_TIME);

	// initialize default slider settings
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETRANGE, (WPARAM)true,
		(LPARAM)MAKELONG(0, 1));
	SendDlgItemMessage(hdlg, IDC_TIME, WM_ENABLE, (WPARAM)false, 0);

	// read init file
	InitFile init(INITFILE_FILENAME, REMOTE_CLASS_NAME);
	char valBuf[BUF_LEN + 1];

	if (init.getError() == IF_ERR_NONE) {	// initfile was read successfully
		if (init.getValue(ADDRESS_KEY, valBuf, BUF_LEN))
			SendDlgItemMessage(hdlg, IDC_ADDRESS, WM_SETTEXT, 0, (LPARAM)valBuf);
		if (init.getValue(PASSWORD_KEY, valBuf, BUF_LEN))
			SendDlgItemMessage(hdlg, IDC_PASSWORD, WM_SETTEXT, 0, (LPARAM)valBuf);
		if (init.getValue(PORT_KEY, valBuf, BUF_LEN))
			SendDlgItemMessage(hdlg, IDC_PORT, WM_SETTEXT, 0, (LPARAM)valBuf);
	} else {								// use default port
		sprintf(valBuf, "%d", DEF_PORT);
		SendDlgItemMessage(hdlg, IDC_PORT, WM_SETTEXT, 0, (LPARAM)valBuf);
	}

	return true;
}


/* ShutdownRemote
 * --------------
 * Performs all necessary shutdown steps. This includes writing to the remote
 * init file and deallocating memory.
 */
void ShutdownRemote(HWND hdlg, QServer *server) {
	InitFile init(INITFILE_FILENAME, REMOTE_CLASS_NAME);
	char buf[BUF_LEN + 1];
	int len;

	// delete qserver (commented out because it's not dynamically allocated)
//	DEL(server);

	// write init file
	*(WORD *)buf = BUF_LEN;
	len = SendDlgItemMessage(hdlg, IDC_ADDRESS, EM_GETLINE, 0, (DWORD)buf);
	buf[len] = '\0';
	init.setValue(ADDRESS_KEY, buf);

	*(WORD *)buf= BUF_LEN;
	len = SendDlgItemMessage(hdlg, IDC_PASSWORD, EM_GETLINE, 0, (DWORD)buf);
	buf[len] = '\0';
	init.setValue(PASSWORD_KEY, buf);

	*(WORD *)buf = BUF_LEN;
	len = SendDlgItemMessage(hdlg, IDC_PORT, EM_GETLINE, 0, (DWORD)buf);
	buf[len] = '\0';
	init.setValue(PORT_KEY, buf);

	init.write();

	// tell parent window to close
	SendMessage((HWND)GetWindowLong(hdlg, GWL_HWNDPARENT), WM_DESTROY, NULL,
		NULL);
}


/* ResetPlaylist
 * -------------
 * Clears the playlist and sets default settings for the playlist and slider.
 */
void ResetPlaylist(HWND hdlg) {
	int timeCur, timeLen;

	// reset playlist
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_DELETEALLITEMS, 0, 0);
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETITEMCOUNT, 0, 0);
	RESET_COL_WIDTHS();

	// reset slider
	timeCur = 0;
	timeLen = 1;
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETRANGE, (WPARAM)true,
		(LPARAM)MAKELONG(0, timeLen));
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETPOS, (WPARAM)true,
		(LPARAM)timeCur / 1000);
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETTICFREQ, (WPARAM)TIC_FREQ, 0);
}



/* UI
 * --
 * Handles messages from the controls.
 */
bool UI(HWND hdlg, QServer *server, WPARAM wParam, LPARAM lParam) {
	char filename[BUF_LEN];
	bool toggle;

	switch (LOWORD(wParam)) {

	case IDC_ABOUT:		// about
		char about[BUF_LEN];

		sprintf(about, ABOUT_MSG, BUILD_DATE);
		MessageBox(hdlg, about, "About", MB_OK);
		return true;

	case IDC_CONNECT:	// connect
		TEST(Connect(hdlg, server));
		return true;

	case IDC_PLAY:		// play
		TEST(server->play());
		Sync(hdlg, server, false);
		return true;

	case IDC_PREVIOUS:	// previous
		TEST(server->prev());
		Sync(hdlg, server, true);
		return true;

	case IDC_PAUSE:		// pause
		TEST(server->pause());
		Sync(hdlg, server, false);
		return true;

	case IDC_STOP:		// stop
		TEST(server->stop());
		Sync(hdlg, server, false);
		return true;

	case IDC_NEXT:		// next
		TEST(server->next());
		Sync(hdlg, server, true);
		return true;

	case IDC_CLEAR:		// clear playlist
		bool success;
		
		success = server->clear();
		GetPlaylist(hdlg, server);
		return success;

	case IDC_OPEN:		// add files
		if (QueryBox(hInst, hdlg, "Enter filename:", filename, BUF_LEN)) {
			TEST(server->add(filename));
			GetPlaylist(hdlg, server);
		}
		return true;

	case IDC_JUMP:		// jump to song
		int pos;
		if (JumpBox(hInst, hdlg, server, &pos)) {	// jumpbox was successful, jump
			FindItem(hdlg, (LPARAM)pos, &pos);
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETSELECTIONMARK,
				0, (LPARAM)pos);
			PlaySel(hdlg, server);
		}
		return true;

	case IDC_FIND:		// scroll to currently playing song
		int cur, ind;

		TEST(server->curPos(&cur))			// select current song
		if (!FindItem(hdlg, cur, &ind))
			break;
		SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_ENSUREVISIBLE, (WPARAM)ind,
			(LPARAM)false);
		return true;

	case IDC_REPEAT:	// repeat toggle
		toggle = (SendDlgItemMessage(hdlg, IDC_REPEAT, BM_GETCHECK, 0, 0)
			== BST_CHECKED);
		TEST(server->setRepeat(toggle));
		return true;

	case IDC_SHUFFLE:	// shuffle toggle
		toggle = (SendDlgItemMessage(hdlg, IDC_SHUFFLE, BM_GETCHECK, 0, 0)
			== BST_CHECKED);
		TEST(server->setShuffle(toggle))
		return true;

	case IDC_PLAYLIST:	// playlist message
		switch (((NMHDR *)lParam)->code) {
		case NM_DBLCLK:				// double click in the playlist
			if (SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_GETHOTITEM, 0, 0)
				!= -1)
				PlaySel(hdlg, server);	// only play if dblclk was on a song
			return true;

		case NM_RETURN:				// pressed return
			PlaySel(hdlg, server);
			return true;

		case LVN_KEYDOWN:
			if (((NMLVKEYDOWN *)lParam)->wVKey == VK_RETURN) {
				PlaySel(hdlg, server);
				return true;
			}
			return false;

		case LVN_COLUMNCLICK:		// click on a column
			switch (((NMLISTVIEW *)lParam)->iSubItem) {
			case PLAYLIST_CUR_SUB:	//marker column, resize columns
				RESET_COL_WIDTHS();
				break;
			case PLAYLIST_IND_SUB:	// index column, sort by index
				SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SORTITEMS,
					(WPARAM)server, (LPARAM)IndexCompare);
				break;
			case PLAYLIST_SONG_SUB:	// song column, song title sort
				SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SORTITEMS,
					(WPARAM)server, (LPARAM)SongCompare);
				break;
			default: break;
			}
			return true;

		default:
			return false;
		}

	case IDOK:	// user pressed enter
		if (GetFocus() == GetDlgItem(hdlg, IDC_PLAYLIST)) {
			PlaySel(hdlg, server);	// in playlist, play selected song
			return true;
		}
		return false;

	case TB_ENDTRACK:	// slider message
		if ((HWND)lParam == GetDlgItem(hdlg, IDC_TIME)) {
			int set;
			// set position in song
			set = SendDlgItemMessage(hdlg, IDC_TIME, TBM_GETPOS, 0, 0);
			TEST(server->setTime(set * 1000));	// slider's range is 0-length
			return true;
		}
		return false;

	default: return false;
	}

	return false;
}



/* PlaySel
 * -------
 * Plays the currently selected song in the playlist.
 */
bool PlaySel(HWND hdlg, QServer *server) {
	LVITEM item;
	char indBuf[10];
	int sel, ind;

	// get selected song
	sel = SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_GETSELECTIONMARK, 0, 0);

	// get index
	memset(&item, 0, sizeof(LVITEM));
	item.iSubItem = PLAYLIST_IND_SUB;
	item.pszText = indBuf;
	item.cchTextMax = 10;
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_GETITEMTEXT, (WPARAM)sel,
		(LPARAM)&item);
	if (sscanf(indBuf, "%d", &ind) != 1)
		return false;
	ind--;

	// play selected song
	TEST(server->setPos(ind));
	TEST(server->play());
	Sync(hdlg, server, true);
	return true;
}



/* Connect
 * -------
 * Connects to the httpQ server and updates the visible status displays.
 * Returns true if the connection was successful, false otherwise.
 */
bool Connect(HWND hdlg, QServer *server) {
	char addrBuf[BUF_LEN], passBuf[BUF_LEN], portBuf[BUF_LEN];
	int addrLen, passLen, portLen;
	int port;
	bool toggle;

	// first get address, password, port
	*(WORD *)addrBuf = BUF_LEN;
	addrLen = SendDlgItemMessage(hdlg, IDC_ADDRESS, EM_GETLINE, 0,
		(DWORD)addrBuf);
	addrBuf[addrLen] = '\0';

	*(WORD *)passBuf = BUF_LEN;
	passLen = SendDlgItemMessage(hdlg, IDC_PASSWORD, EM_GETLINE, 0,
		(DWORD)passBuf);
	passBuf[passLen] = '\0';

	*(WORD *)portBuf = BUF_LEN;
	portLen = SendDlgItemMessage(hdlg, IDC_PORT, EM_GETLINE, 0,
		(DWORD)portBuf);
	portBuf[portLen] = '\0';
	port = 0;
	sscanf(portBuf, "%d", &port);

	// error check
	if (addrBuf[0] == '\0') {
		MBOX("Please enter the address of an httpQ server.");
		return false;
	} else if (passBuf[0] == '\0') {
		MBOX("Please enter a password.");
		return false;
	} else if (port < 1 || port > MAX_PORT) {
		sprintf(portBuf, "Please enter a port between 1 and %d.", MAX_PORT);
		MBOX(portBuf);
		return false;
	}

	// everything's there, try to connect
	TEST(server->connect(addrBuf, passBuf, port));

	// update repeat and shuffle
	if (server->getRepeat(&toggle))
		SendDlgItemMessage(hdlg, IDC_REPEAT, BM_SETCHECK,
			(toggle) ? BST_CHECKED : BST_UNCHECKED, 0);
	if (server->getShuffle(&toggle))
		SendDlgItemMessage(hdlg, IDC_SHUFFLE, BM_SETCHECK,
			(toggle) ? BST_CHECKED : BST_UNCHECKED, 0);

	// update playlist
	GetPlaylist(hdlg, server);

	return true;
}




/* GetPlaylist
 * -----------
 * Gets the current playlist and all song titles and displays them in the
 * list box.
 */
bool GetPlaylist(HWND hdlg, QServer *server) {
	int len;
	char **playlist, indBuf[10];
	LVITEM item;

	if (!SetTimer(hdlg, TM_CHECK_ID, 999999, NULL))	// turn off syncing
		MBOX("Too many timers!");
	SendDlgItemMessage(hdlg, IDC_TIME, WM_ENABLE, (WPARAM)false, 0); // slider
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LB_RESETCONTENT, 0, 0);

	// get playlist & number of songs
	TEST(server->getPlaylist(true, &playlist, &len))

	// set item attributes
	memset(&item, 0, sizeof(LVITEM));
	item.mask = LVIF_TEXT | LVIF_PARAM;

	// add songs
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_DELETEALLITEMS, 0, 0);
	SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETITEMCOUNT, (WPARAM)len, 0);
	for (int i = 0; i < len; i++) {			// add songs
		item.iItem = i;

		// song title
		item.iSubItem = PLAYLIST_SONG_SUB;
		item.pszText = playlist[i];
		item.cchTextMax = strlen(playlist[i]);
		item.lParam = i;
		SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_INSERTITEM, 0, (LPARAM)&item);

		// playlist index
		item.iSubItem = PLAYLIST_IND_SUB;
		sprintf(indBuf, "%d", i + 1);	// playlist index
		item.pszText = indBuf;
		item.cchTextMax = strlen(indBuf);
		SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETITEMTEXT, i, (LPARAM)&item);
	}

	RESET_COL_WIDTHS();

	Sync(hdlg, server, true);

	if (!SetTimer(hdlg, TM_CHECK_ID, TM_CHECK_INT, NULL))	// turn on syncing
		MBOX("Too many timers!");
	SendDlgItemMessage(hdlg, IDC_TIME, WM_ENABLE, (WPARAM)true, 0); // slider
	return true;
}



/* Sync
 * ----
 * Gets the currently playing song and highlights it in the playlist. Also
 * sets the range and position of the slider to the current time in the song.
 * If initSong is true OR the currently playing song is different from the
 * marked song (the song Remote thinks is currently playing), Sync also sets
 * the playlist mark, the title bar, and scrolls to the current song.
 */
bool Sync(HWND hdlg, QServer *server, bool initSong) {
	int timeCur, timeLen, remoteLen, localLen;
	char title[BUF_LEN], status[BUF_LEN];
	HWND hwndFocus = GetFocus();

	// save current status message
	*(WORD *)status = BUF_LEN;
	SendDlgItemMessage(hdlg, IDC_STATUS, EM_GETLINE, 0, (DWORD)status);
	status[BUF_LEN - 1] = '\0';

	TEST(server->listLen(&remoteLen));		// check that playlist is current
	TEST(server->getPlaylist(false, NULL, &localLen));
	if (remoteLen != localLen)
		GetPlaylist(hdlg, server);

	if (remoteLen == 0) {
		SendMessage(hdlg, WM_SETTEXT, 0, (LPARAM)REMOTE_CAPTION);

	} else {
		int markPos, markItem, pos, itemInd;
		LVITEM item;

		TEST(server->curPos(&pos));
		if (!FindMarker(hdlg, server, &markPos, &markItem))
			markPos = pos;
		if (!FindItem(hdlg, (LPARAM)pos, &itemInd))
			return false;

		if (initSong || markPos != pos) {
			// remove the playlist mark on the old song
			memset(&item, 0, sizeof(LVITEM));
			item.iItem = markItem;
			item.iSubItem = PLAYLIST_CUR_SUB;
			item.mask = LVIF_TEXT;
			item.pszText = NULL;
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETITEMTEXT, markItem,
				(LPARAM)&item);
			// set the playlist mark on the currently playing song
			item.iItem = itemInd;
			item.iSubItem = PLAYLIST_CUR_SUB;
			item.pszText = PLAYLIST_MARKER;
			item.cchTextMax = strlen(PLAYLIST_MARKER);
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_SETITEMTEXT,
				(WPARAM)item.iItem, (LPARAM)&item);
			// set the title bar
			memset(&item, 0, sizeof(LVITEM));
			item.pszText = title;
			item.cchTextMax = BUF_LEN - 4 - strlen(REMOTE_CAPTION);
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_GETITEMTEXT,
				(WPARAM)itemInd, (LPARAM)&item);
			title[item.cchTextMax] = '\0';
			strcat(title, " - ");
			strcat(title, REMOTE_CAPTION);
			SendMessage(hdlg, WM_SETTEXT, 0, (LPARAM)title);

			// scroll to current song
			SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_ENSUREVISIBLE,
				(WPARAM)itemInd, (LPARAM)false);
		}
	}

	// set the slider's range and pos
	timeCur = 0;
	timeLen = 1;
	TEST(server->curTime(&timeCur));
	TEST(server->curLen(&timeLen));
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETRANGE, (WPARAM)true,
		(LPARAM)MAKELONG(0, timeLen));
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETPOS, (WPARAM)true,
		(LPARAM)timeCur / 1000);
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETTICFREQ, (WPARAM)TIC_FREQ, 0);

	server->updatePlaying();				// update playing
	if (server->isPlaying())				// if playing, enable slider
		SendDlgItemMessage(hdlg, IDC_TIME, WM_ENABLE, (WPARAM)true, 0);

	SetFocus(hwndFocus);

	// set previous status message
	SendDlgItemMessage(hdlg, IDC_STATUS, WM_SETTEXT, 0, (LPARAM)status);

	return true;
}


/* AdvanceSlider
 * -------------
 * Advances the time indicator slider
 */
bool AdvanceSlider(HWND hdlg, QServer *server) {
	// if not connected or not playing, disable slider
	if (!server->isConnected() || !server->isPlaying()) {
		SendDlgItemMessage(hdlg, IDC_TIME, WM_ENABLE, (WPARAM)false, 0);
		return true;
	}

	int pos, len;

	len = SendDlgItemMessage(hdlg, IDC_TIME, TBM_GETRANGEMAX, 0, 0);
	pos = SendDlgItemMessage(hdlg, IDC_TIME, TBM_GETPOS, 0, 0);
	SendDlgItemMessage(hdlg, IDC_TIME, TBM_SETPOS, (WPARAM)true,
		(LPARAM)++pos);
	if (pos > len)	// end of song, re-sync
		Sync(hdlg, server, true);

	return true;
}



/* FindMarker
 * -----------
 * Sets the playlist position and the listview item of the song in the playlist
 * that currently has the marker (ie that Remote thinks is currently playing).
 * If index or itemPos is NULL, they won't be set.
 */
bool FindMarker(HWND hdlg, QServer *server, int *pos, int *itemInd) {
	LVITEM item;
	char markerBuf[10];
	int len, posBuf;

	TEST(server->getPlaylist(false, NULL, &len));
	memset(&item, 0, sizeof(LVITEM));
	item.iSubItem = PLAYLIST_CUR_SUB;
	item.mask = LVIF_TEXT | LVIF_PARAM;
	item.pszText = markerBuf;
	item.cchTextMax = 10;
	for (item.iItem = 0; item.iItem < len; item.iItem++) {
		posBuf = SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_GETITEM, 0,
			(LPARAM)&item);
		if (strcmp(markerBuf, PLAYLIST_MARKER) == 0)
			break;
	}
	if (item.iItem == len) return false;
	if (itemInd) *itemInd = item.iItem;
	if (pos) *pos = item.lParam;
	return true;
}



/* FindItem
 * --------
 * Returns the item (into *item) in the playlist with the given lParam. Returns
 * true on success, false otherwise.
 */
bool FindItem(HWND hdlg, LPARAM lParam, int *item) {
	LVFINDINFO find;
	int found;

	memset(&find, 0, sizeof(LVFINDINFO));
	find.flags = LVFI_PARAM;
	find.lParam = lParam;
	found = SendDlgItemMessage(hdlg, IDC_PLAYLIST, LVM_FINDITEM, -1, (LPARAM)&find);
	if (found == -1)
		return false;

	*item = found;
	return true;
}



/* RepositionWindow
 * ----------------
 * Moves the main window so that it is always under the dialog box. Returns
 * true on success, false on failure.
 */
bool RepositionWindow(HWND hdlg) {
	WINDOWPLACEMENT placement;
	RECT *wRect = &placement.rcNormalPosition;
	HWND parent = (HWND)GetWindowLong(hdlg, GWL_HWNDPARENT);

	placement.length = sizeof(WINDOWPLACEMENT);
	if (!GetWindowPlacement(hdlg, &placement))
		return false;
	wRect->right = wRect->left;
	wRect->bottom = wRect->top;
	if (!SetWindowPlacement(parent, &placement))
		return false;

	return true;
}



/* SongCompare
 * -----------
 * Comparison function used with the LVN_SORTITEMS message for sorting the
 * playlist by song title. Basically a wrapper for _stricmp - lParam1 and lParam2
 * are the indexes of the two songs.
 */
int CALLBACK SongCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort) {
	char **playlist;

	if (!((QServer *)lParamSort)->getPlaylist(false, &playlist, NULL))
		return 0;	// couldn't get playlist
	return _stricmp(playlist[lParam1], playlist[lParam2]);
}



/* IndexCompare
 * ------------
 * Comparison function used with the LVN_SORTITEMS message for sorting the
 * playlist by song title. Simply returns lParam1 - lParam2, since lParam1 and
 * lParam2 are the indexes of the two songs.
 */
int CALLBACK IndexCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort) {
	return lParam1 - lParam2;
}




/* CheckMessages
 * -------------
 * Processes outstanding messages if there are any.
 */
void CheckMessages() {
	MSG msg;

	if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

