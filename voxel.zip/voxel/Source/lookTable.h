/* File: lookTable.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * The lookTable class provides a lookup table of sin and cosine values for
 * "look angles" - an angle in degrees converted so that adding 1 to a look
 * angle increases it by one screen column, not by one degree.
 *
 * Also, the lookup tables are stored in a (hacked) fixed point, which is used
 * to hopefully avoid expensive floating point operations. The fixed point uses
 * 20.12 format, and can be created from an int by bit shifting or multiplying.
 *
 * This optimization is described in Andre LaMothe's article on voxel terrain
 * rendering in Game Developer Magazine, 11/1997.
 */

#ifndef _LOOKTABLE_H
#define _LOOKTABLE_H

#include <assert.h>
#include <math.h>
#include "util.h"


#define PI	(double)3.14159265

// fixed point - fixed point type is 20.12, multiplication by 2^12 (4096)
// instead of shift is a half-hearted attempt to make this stuff portable
typedef int fixp;
#define FIXP_SHIFT	12
#define FIXP_MULT	4096
#define FIXP_FRACTION_MASK	0xFFF

// look angles
typedef int lookAngle;
//#define LOOK_360	(width * 360 / this->fov)
#define LOOK_360	(this->look_360)
#define LOOK_180	(LOOK_360 / 2)
#define LOOK_120	(LOOK_360 / 3)
#define LOOK_90		(LOOK_360 / 4)
//#define LOOK_60		(LOOK_360 / 6)
//#define LOOK_45		(LOOK_360 / 8)
//#define LOOK_30		(LOOK_360 / 12)
//#define LOOK_5		(LOOK_360 / 72)
//#define LOOK_2		(LOOK_360 / 180)
//#define LOOK_1		(LOOK_360 / 360)

class lookTable {
public:

	/* ctor
	 * ----
	 * Creates a lookup table with the given frustum FOV and screen width. The
	 * FOV cannot be more than 225 degrees - if it is, an assertion is thrown.
	 * (This is a side effect of the way the lookup tables are designed.)
	 */
	lookTable(int fov, int width);

	/* dtor
	 */
	~lookTable();

	/* cos
	 * ---
	 * Returns the cosine value for the given look angle.
	 */
	fixp lcos(lookAngle langle);

	/* sin
	 * ---
	 * Returns the sin value for the given look angle.
	 */
	fixp lsin(lookAngle langle);

	/* Table
	 * -----
	 * Returns a pointer to the lookup table.
	 */
	fixp *Table() { return table; }

	// public member look_360, look angle for 360 degrees
	int look_360;

protected:
	int fov, width;
	fixp *table;	// lookup table
};


#endif /* _LOOKTABLE_H */