-----------
TIC TAC TOE
http://snarfed.org/space/tictactoe
-----------
Ryan Barrett
http://ryan.barrett.name/
-----------

Tic-tac-toe is distributed under the GPL (GNU General Public License). See the
COPYING.txt file for more details.

How to build
------------
Unzip source.zip and open tictactoe.dsw and tictactoe.dsp in Microsoft Visual
C++. Build as usual.

How to run
----------
Run tictactoe.exe. The game will appear and immediately begin a game pitting
the AI against itself. To rotate your view, click and hold the left mouse
button and move the mouse. To bring up the in-game menu, right-click anywhere
in the screen. You can use the in-game menu to start a new game, make a move
(if it is your turn), change rendering options, or quit. Right-click to select
an item in any of the menus. To scroll the top-level menu, right-click and hold
on one of the scrollbars, then move the mouse.

You can also play with the keypad (make sure NumLock is on). Each button on the
keypad corresponds to a possible move. If you rotate your view around so that it
is not centered, press 'C' to center your view.


Inspiration
-----------
- The inspiration for this game came from the underground demo scene,
specifically from a 64Kb demo by Foobug called Exodus. It has two or three
different water effects that are all incredible. (The first minute or two
is boring, but the rest is definitely worth it!)

The Foobug site is at http://foobug.yoki.org, and you can download the demo from
this link:

ftp://ftp.yoki.org/pub/groups/foobug/exodus.zip

If you haven't checked out the demo scene, you should! Check out www.scene.org
and/or www.pouet.net.



Technical description
--------------------

- Procedural modeling:

The main advanced features is the procedural modeling and dynamics of the water.
The water is stored as a heightfield, and the ripples are propagated with a
surprisingly simple filter. I wish I could claim credit for the filter, but I
can't - it's down in the citations section. I did extend it to 3D, though - it
was originally conceived only for 2D images. I also added damping and relaxation
to the algorithm. Basically, I store the heightfields for the current and
previous game ticks, and to generate the next heightfield, I take the difference
between the current and previous heightfield at each point and use it as the
velocity for that point. There's more to it, but that's the gist.

To generate ripples, you can simply displace a point in the heightfield. However,
this creates jagged ripples if the displacement is large. So when the game loads,
I precompute a few ripples by displacing a heightfield and repeatedly running the
filter over it. Then, when I need to create a ripple during this game, I add the
heights from one of these precomputed ripples to the heightfield, centered at the
place the ripple should appear.

To make the pieces float, I store their velocity and orientation. For each game
tick, I apply the velocity along their orientation and then update their velocity
and orientation based on the heightfield below them and its normals. Again, I use
damping and relaxation to keep this smooth and somewhat delayed, so that the
look like they are reacting to the water's motion instead of moving exactly in
sync with it.

- Advanced rendering:

I implemented both refraction and the fresnel term in an attempt to make the
water appear more realistic. I approximated both of them with formulas that
I think are acceptable, since there's no need for it to be physically exact. For
more information, see refract.cpp and fresnel.cpp. The approximation I used for
refraction requires a fixed viewpoint, so it can only be turned on if the viewer
is at the top, looking straight down. I wish I had started earlier so that I
could have used the GeForce3's programmable vertex shaders. I'm sure I could have
done it fast enough for any viewpoint using them. But I didn't have enough time
to learn how to use them...oh well.

Strangely, though, it looks best without refraction or fresnel term, just with
plain texturing and environment mapping. I guess I learned a good lesson - if
you can get as good or better results with phenomenological models, go for it.

- In-game UI

I wrote a windowing toolkit similar to GLUI or MUI, except that it is drawn in
the same window as your game. This allowed me to run my game full-screen, which
is more immersive. It provides windows, items, checkboxes, scrollbars, and
scrollable windows. (This is definitely less functionality than GLUI or MUI, but
it was all I needed and it was still plenty of work.) Windows can have child
windows, much the way application menus can have sub-menus in most common
windowing systems.

I'm pretty proud of my UI. I tried to make it as modular and independent from the
game as possible. It's aesthetically pleasing (at least to me :P), it doesn't
slow down the rendering, and it doesn't require GLUT. I think I could drop it
into any other OpenGL program with a negligible amount of effort.


Other features
--------------
These were a few other features that didn't take a lot of work, but deserve
mentioning:

- Rain. It rains on the water. The raindrops create ripples where they hit.
- AI. The computer plays a pretty good game of tic-tac-toe.
- Configurable settings. Most game and (especially) rendering settings can be
changed in tictactoe.ini without rebuilding the game. Settings that can be
changed include the size of the height field, the sound effects, all of the
textures, rain settings, and variables that affect the behavior of the water.
(See citations section.)


Models and textures
-------------------
I created the X piece model myself and the O piece is a call to glutSolidTorus.
Unfortunately, I don't know where the textures are from. I've compiled a small
library of public-domain textures and art assets over the last four years or so,
and all of these are taken from that. I downloaded the sounds from free sound
effects web sites, but I also forgot to write down specifically which sites.


Citations
---------
- Ripple filter. This is definitely the most important citation - I developed
the ripple engine, but I didn't come up with the basic idea. I just took this
algorithm, extended it to 3D, and added damping and relaxing. I found the
algorithm on Hugo Elias' website, but he doesn't know who originally came up
with it. :P

	http://freespace.virgin.net/hugo.elias/graphics/x_water.htm

- The stlini library for reading .ini files. This was written by Robert
Kesterson.

	http://robertk.com/source/

- Some of the GLUT initialization (like the code in main()) was copied from
Matt Ginzton's glut_example program.
