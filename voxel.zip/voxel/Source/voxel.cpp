/* File: voxel.cpp
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * This program runs a game that uses a voxel engine for terrain rendering.
 * See http://www.stanford.edu/~rbarrett/voxel.html for more details.
 *
 * NOTE: The WinGame animation is a tight loop. Sorry - if I have time before
 * submitting, I'll do the Right Thing and make it part of an idle function.
 * But it's only 10 seconds, so it shouldn't be a big deal.
 *
 * All of the Voxel Hunt! source code is (C) Ryan Barrett, 2000.
 */

#define WIN32_LEAN_AND_MEAN  // make sure certain headers are included correctly

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "glut.h"
#include "util.h"
#include "voxelmap.h"
#include "renderer.h"
//#include "polyRenderer.h"
#include "spanRenderer.h"


/* constants */
#define VOXEL_WND_CAPTION	"Voxel Hunt!"
#define HEIGHTMAP_SIZE		256
#define MOUNTAIN_HEIGHTMAP	"mountain.raw"
#define VOLCANIC_HEIGHTMAP	"volcanic.raw"
#define SKY_WIDTH			900
#define MOUNTAIN_SKY		"bluemoon.raw"
#define VOLCANIC_SKY		"crimsonsky.raw"

/* win animation stuff */
#define COIN_COUNT			50
#define COIN_SIZE			16
#define COIN_NUM_FRAMES		4
#define COIN_FRAME_1		"coin1.raw"
#define COIN_FRAME_2		"coin2.raw"
#define COIN_FRAME_3		"coin3.raw"
#define COIN_FRAME_4		"coin4.raw"
#define COIN_FRAME_MSECS	250
#define COIN_ANIM_SECS		10


/* game constants */
#define INIT_WINDOW_SIZE	300
#define INIT_X				50
#define INIT_Y				200
#define INIT_Z				50
#define INIT_VELOCITY		5
#define INIT_ANGLE			45
#define SKIM_HEIGHT			100


/* function prototypes */
void Keyboard(unsigned char key, int mx, int my);
void KeyboardSp(int key, int mx, int my);
void Display();
void Mouse(int button, int state, int x, int y);
void Motion(int x, int y);
void Reshape(int w, int h);
void Idle();
// game state stuff
void InitGame();
void WinGame();


/* global variables */
int window_width = INIT_WINDOW_SIZE, window_height = INIT_WINDOW_SIZE;
voxelmap *map;
framebuffer *sky;
spanRenderer *renderer;

// game state stuff
float x, y, z, velocity, angle;
bool printfps, autopilot, winning;


/* function definitions */

int __cdecl main(int argc, char **argv) {
	// set the renderer
	renderer = new spanRenderer(window_width, window_height);
	if (!renderer) Err("Out of memory.");

	// set up sky framebuffer
	sky = new framebuffer(SKY_WIDTH, window_height);
	if (!sky) Err("Not enough memory.");

	// read in the heightmap
	// start with volcanic tileset by default
	map = new voxelmap("test heightmap");
	if (!map) Err("Out of memory.");
	map->read(VOLCANIC_HEIGHTMAP, HEIGHTMAP_SIZE);
	map->volcanic();
	sky->readRawfile(VOLCANIC_SKY);

	// initialize glut
	glutInit(&argc, argv);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(window_width, window_height);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

	// set glut callbacks
	glutCreateWindow(VOXEL_WND_CAPTION);
	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(KeyboardSp);
	glutReshapeFunc(Reshape);
	glutIdleFunc(Idle);

	// set up game state
	InitGame();

	// start game
	glutMainLoop();

	// clean up and return
	return 0;
}


// game state functions

void InitGame() {
	x = INIT_X;
	y = INIT_Y;
	z = INIT_Z;
	velocity = INIT_VELOCITY;
	angle = INIT_ANGLE;
	printfps = false;
	autopilot = false;
	winning = false;
	renderer->interpolate = true;
}


// winning animation

void WinGame() {
	framebuffer *coins[COIN_NUM_FRAMES];	// coin animation frames
	framebuffer back(window_width, window_height),
		screen(window_width, window_height);
	int x[COIN_COUNT], y[COIN_COUNT], frame[COIN_COUNT];
	int sleeptime, c;
	clock_t start, animStart;
	unsigned char r, g, b;

	winning = true;
	srand(time(NULL));

	// display "You Win!" messagebox
#ifdef WIN32
	MessageBox(NULL, "You Win!", VOXEL_WND_CAPTION, MB_OK);
#endif

	// copy screen to backup
	glReadPixels(0, 0, window_width, window_height, GL_RGB, GL_UNSIGNED_BYTE,
		back.memptr());

	// create animation framebuffers
	for (int i = 0; i < COIN_NUM_FRAMES; i++) {
		coins[i] = new framebuffer(COIN_SIZE, COIN_SIZE);
		if (!coins[i]) Err("Out of memory.");
	}

	// load animation frames
	coins[0]->readRawfile(COIN_FRAME_1);
	coins[1]->readRawfile(COIN_FRAME_2);
	coins[2]->readRawfile(COIN_FRAME_3);
	coins[3]->readRawfile(COIN_FRAME_4);

	// position coins randomly
	for (c = 0; c < COIN_COUNT; c++) {
		x[c] = rand() % (window_width - COIN_SIZE);
		y[c] = rand() % (window_height - COIN_SIZE);
		frame[c] = rand() % 4;
	}

	// animate coins for a while (rate controlled)
	start = animStart = clock();
	while ((animStart - start) / CLOCKS_PER_SEC < COIN_ANIM_SECS) {
		// timestamp
		animStart = clock();

		// redraw screen
		memcpy(screen.memptr(), back.memptr(), window_width * window_height *
			sizeof(pixel));

		// draw current animation frame for each coin
		for (c = 0; c < COIN_COUNT; c++) {
			for (int u = 0; u < COIN_SIZE; u++) {
				for (int v = 0; v < COIN_SIZE; v++) {
					coins[frame[c]]->getPixel(u, v, &r, &g, &b);
					// black is the transparent color
					if (r || g || b)
						screen.setPixel(x[c] + u, y[c] + v, r, g, b);
				}
			}
		}

		// draw to screen
		screen.draw();
		glutSwapBuffers();

		// sleep until frame time is done
		sleeptime = COIN_FRAME_MSECS - (clock() - animStart) * 1000 /
			CLOCKS_PER_SEC;
		Sleep(MIN(sleeptime, 0));

		// increment animation frames
		for (c = 0; c < COIN_COUNT; c++)
			frame[c] = (frame[c] + 1) % COIN_NUM_FRAMES;
	}
}


// main functions

void Keyboard(unsigned char key, int mx, int my)
{
	key = tolower(key);

	switch (key) {

	case 'f':	// toggle printing fps to console
		printfps = !printfps;
		return;

	case 'm':	// toggle mountain heightmap, colormap, and sky
		map->read(MOUNTAIN_HEIGHTMAP, HEIGHTMAP_SIZE);
		map->mountain();
		sky->readRawfile(MOUNTAIN_SKY);
		return;

	case 'v':	// toggle volcanic heightmap, colormap, and sky
		map->read(VOLCANIC_HEIGHTMAP, HEIGHTMAP_SIZE);
		map->volcanic();
		sky->readRawfile(VOLCANIC_SKY);
		return;

	case 'i':	// toggle interpolation
		renderer->interpolate = !renderer->interpolate;
		return;

	case 'a':	// toggle autopilot (follow ground)
		autopilot = !autopilot;
		return;

	case 'q':	// clean up and quit
		DEL(map);
		DEL(renderer);
		exit(0);

	default:
		return;
	}
}


void KeyboardSp(int key, int mx, int my) {
	switch (key) {

	case GLUT_KEY_UP:		// forward
		if (velocity < 20) velocity++; return;

	case GLUT_KEY_DOWN:		// backward
		if (velocity > -20) velocity--; return;

	case GLUT_KEY_LEFT:		// left
		angle += 5; break;

	case GLUT_KEY_RIGHT:	// right
		angle -= 5; break;

	case GLUT_KEY_END:		// down (decrease altitude)
		if (y >= 10) y -= 10; break;

	case GLUT_KEY_HOME:		// up (increase altitude)
		if (y <= 245) y += 10; break;

	default:
		return;
	}

	// clip angle
	if (angle < 0) angle += 360;
	if (angle > 360) angle -= 360;

	// redraw if angle or altitude has changed
	glutPostRedisplay();
}

void Display() {
	clock_t start, end;	/* in clock ticks */

	if (winning) {
		glutSwapBuffers();
		return;
	}

	glClearColor(0, 0, 0, 0);
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

	if (printfps) start = clock();
	renderer->drawsky(sky, angle);
	renderer->render(map, x, y, z, angle);
	if (printfps) end = clock();

	/* get difference between timestamps */
	if (printfps)
		printf("%f fps\n", (float)CLOCKS_PER_SEC / (end - start));

	glutSwapBuffers();
}


// not allowed to resize!
void Reshape(int w, int h) {
	// reset to original width and height
	glutReshapeWindow(window_width, window_height);
	glViewport(0, 0, window_width, window_height);

	glutPostRedisplay();
}



#define GAME_FPS	10

void Idle() {
	static clock_t start = clock();
	float diff;

	// rate control
	diff = (float)(clock() - start) * GAME_FPS / CLOCKS_PER_SEC;
	if (diff < 1) return;
	start = clock();

	// move according to velocity
	x += COS(angle) * velocity / 10 * diff;
	z += SIN(angle) * velocity / 10 * diff;

	// clip coordinates
	int size = map->size;
	if (x < 0) x += size;
	if (x > size) x -= size;
	if (z < 0) z += size;
	if (z > size) z -= size;

	if (autopilot) {
		// adjust height to follow terrain
		y = map->voxels[(int)x][(int)z].height / FIXP_MULT / HEIGHT_SCALE + SKIM_HEIGHT;
		if (y < 100) y = 100;
		if (y > 255) y = 255;
	}

	// check to see if the player won
	if (map->foundIsland(x, z)) {
		WinGame();
		InitGame();
	}

	glutPostRedisplay();
}



