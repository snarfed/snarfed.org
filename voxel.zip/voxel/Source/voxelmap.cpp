/* File: voxelmap.cpp
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Implements the voxelmap class. For more information, see voxelmap.cpp.
 */


#include "voxelmap.h"

#define ISLAND_RADIUS		10
#define MOUNTAIN_ISLAND_X	154
#define MOUNTAIN_ISLAND_Z	175
#define VOLCANIC_ISLAND_X	86
#define VOLCANIC_ISLAND_Z	218


/* ctor
 */
voxelmap::voxelmap(char *name) {
	voxels = NULL;
	size = 0;

	this->name = new char[strlen(name) + 1];
	if (!this->name) Err("Out of memory.");
	strcpy(this->name, name);
}


/* dtor
 */
voxelmap::~voxelmap() {
	if (voxels) DEL(voxels);
	DEL(name);
}


/* read
 */
void voxelmap::read(char *rawfile, int size) {
	FILE *raw;
	unsigned char val;

	assert(size > 0 && powof2(size));
	this->size = size;

	raw = fopen(rawfile, "rb");
	if (!raw) Err("Could not open rawfile %s.", rawfile);

	// build map
	if (voxels) DEL(voxels);
	voxels = new struct voxel *[size];
	if (!voxels) Err("Out of memory.");
	for (int i = 0; i < size; i++) {
		voxels[i] = new struct voxel[size];
		if (!voxels) Err("Out of memory.");
	}

	// read heights from rawfile and fill in map
	for (int j = 0; j < size; j++) {
		for (int k = 0; k < size; k++) {
			if (fread(&val, 1, 1, raw) != 1)
				Err("Could not read from rawfile %s.", rawfile);
			voxels[k][j].height = (fixp)(val * HEIGHT_SCALE * FIXP_MULT);
		}
	}
}

/* mountain, volcanic
 */
void voxelmap::mountain() {
	unsigned char cMountain[][4] = {
//		bound	red, green, blue
		{ 0,	0, 0, 150 },		// water (blue)
		{ 30,	100, 100, 240 },	// shoreline (light blue)
		{ 50,	40, 120, 40 },		// shore (dark green)
		{ 110,	140, 220, 140 },	// grass (light green)
		{ 150,	200, 180, 0 },		// tundra (yellow-brown)
		{ 190,	120, 80, 40 },		// dirt (brown)
		{ 250,	255, 255, 255 },	// ice (white)
		{ 255,	120, 60, 160 }		// purple mountains majesty (purple) :P
	};

	// set colormap
	colormap(cMountain, 8);

	// set island coordinates
	islandx = MOUNTAIN_ISLAND_X;
	islandz = MOUNTAIN_ISLAND_Z;
}

void voxelmap::volcanic() {
	unsigned char cVolcanic[][4] = {
//		bound	red, green, blue
		{ 0,	0, 0, 150 },	// water (blue)
		{ 30,	80, 80, 240 },	// shoreline (light blue)
		{ 50,	60, 100, 60 },	// shore (dark green)
		{ 90,	80, 160, 80 },	// grass (light green)
		{ 120,	160, 140, 0 },	// tundra (yellow-brown)
		{ 160,	90, 60, 30 },	// dirt/sediment (brown)
		{ 200,	60, 20, 20 },	// ash (dark gray, slightly red)
		{ 235,	180, 60, 40 },	// drying lava (dark red)
		{ 255,	240, 50, 50 }	// hot lava (bright(er) red)
	};

	// set colormap
	colormap(cVolcanic, 9);

	// set island coordinates
	islandx = VOLCANIC_ISLAND_X;
	islandz = VOLCANIC_ISLAND_Z;
}


/* foundIsland
 */
bool voxelmap::foundIsland(int cx, int cz) {
	return (abs(cx - islandx) <= ISLAND_RADIUS && 
		abs(cz - islandz) <= ISLAND_RADIUS);
}




/********** PROTECTED METHODS **********************************************/


/* colormap
 * --------
 * Applies a multi-level gradient to the bounds to produce a colormap table.
 * Each height in the colormap table is assigned a color.
 */

#define BOUND(i)	(cbound[i][0])
#define R(i)		(cbound[i][1])
#define G(i)		(cbound[i][2])
#define B(i)		(cbound[i][3])

void voxelmap::colormap(unsigned char cbound[][4], int numBounds) {
	int h, b;	// current height and current bound
	float grad;	// gradient for blending between two colors

	assert(cmap && cbound && numBounds > 1);
	// bounds must include all heights
	assert(BOUND(0) == 0 && BOUND(numBounds - 1) == 255);

	// set color for each height
	for (h = 0; h < 256; h++) {
		// look through bounds and find the right one
		for (b = 1; h > BOUND(b) && b < numBounds; b++);
		assert(b < numBounds);	// check to make sure we found a color

		// blend gradient between two bounding colors
		grad = (float)(h - BOUND(b - 1)) / (BOUND(b) - BOUND(b - 1));
		cmap[h].r = (unsigned char)(grad * R(b) + (1 - grad) * R(b - 1));
		cmap[h].g = (unsigned char)(grad * G(b) + (1 - grad) * G(b - 1));
		cmap[h].b = (unsigned char)(grad * B(b) + (1 - grad) * B(b - 1));
	}
}


