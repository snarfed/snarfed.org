/* File: QueryBox.h
 * Author: Ryan Barrett
 * --------------------
 * 
 * Implements a standard dialog box that prompts for a string.
 * The prompt and response can each be a maximum of 1024 characters.
 */

#ifndef _QUERYBOX_H
#define _QUERYBOX_H


#include <windows.h>
#include "resource.h"


// constants
#define QB_MAX_LEN		1024


/* QueryBox
 * --------
 * Shows the query box. Writes the response into the response buffer. Writes
 * a maximum of n characters and null-terminates. Returns true if the user
 * selected OK, false if the user selected CANCEL.
 */
bool QueryBox(HINSTANCE hInstance, HWND hwnd, char *prompt, char *response, int n);

// dialog proc
BOOL CALLBACK QueryProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam);


#endif /* _QUERYBOX_H */
