/* File: util.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Random utility macros, constants, and functions. For more information, see
 * util.h.
 */

#include "util.h"
#include "framebuffer.h"


/* Err
 */
void __cdecl Err(char *msg, ...) {
	char msgBuf[BUF_LEN];
	va_list va_alist;

	if (!msg) exit(-1);

	va_start(va_alist, msg);
	vsprintf(msgBuf, msg, va_alist);
	va_end(va_alist);
	msgBuf[BUF_LEN - 1] = '\0';

	fprintf(stderr, "ERROR %s %d: %s\n", __FILE__, __LINE__, msgBuf);

	exit(-1);
}


/* project
 */
void project(framebuffer *fb, int theta, int phi,
			 unsigned char r, unsigned char g, unsigned char b) {
	int px, py;

	px = (int)(fb->width / 2 * TAN(theta)) + fb->width / 2;
	py = (int)(fb->height / 2 * TAN(phi)) + fb->height / 2;

	fb->setPixel(px, py, r, g, b);
}


/* powof2
 */
bool powof2(int num) {
	// set to true when a bit is found set. if more than one is set, the
	// number is not a power of two.
	bool found = false;

	// if < 1, not a power of 2!
	if (num < 1) return false;

	// check each bit
	for (int mask = 1; mask > 0; mask = mask << 1) {
		if (num & mask) {
			if (found) return false;
			else found = true;
		}
	}

	return found;
}

