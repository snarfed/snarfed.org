/* File: email.h
 * Author: Ryan Barrett
 *
 * Defines the methods for the cemail class, a bare-bones email address class.
 * Used with scavenger.cpp. For more information, see email.h.
 **/

#include "email.h"
#include <algorithm>  // for transform
#include <ctype.h>    // for isalnum


/*****************************************************************************
 * PUBLIC METHODS
 *****************************************************************************/
bool cemail::is_email(const string &token)
{
  int at_loc = token.find('@');
  int dot_loc = token.rfind('.');

  if (dot_loc - at_loc <= 1)        // '.' must be after '@', and there
    return false;                   // must be at least one char in between

  if (at_loc == 0 ||                // must be at least one char before the
    dot_loc == token.length() - 1)  // '@', and at least one after the '.'
    return false;

  if (!is_email_char(token[at_loc - 1]) ||  // preliminary checks that it
    !is_email_char(token[at_loc + 1]) ||    // has email characters
    !is_email_char(token[dot_loc - 1]) ||
    !is_email_char(token[dot_loc + 1]))
    return false;

  return true;
}


bool cemail::is_email_char(char c)
{
  return (c == '@' || c == '.' || c == '_' || c == '-' || isalnum(c));
}


string cemail::get_host() const
{
  return string(find_at() + 1, end());
}

string cemail::get_username() const
{
  return string(begin(), find_at());
}


void cemail::sanitize()
{
  // find where actual email address starts and stops
  iterator at_loc = find_at();
  iterator stop = ::find_if(at_loc, end(), not_email_char);

  reverse_iterator rat_loc(at_loc);
  reverse_iterator rstart = ::find_if(rat_loc, rend(), not_email_char);

  // strip out prefix and suffix garbage
  assign(rstart.base(), stop);

  // set to lower case
  transform(begin(), end(), begin(), tolower);
}


bool cemail::operator< (const cemail &operand) const
{
  string host(get_host()), op_host(operand.get_host());

  return (host < op_host ||
      (host == op_host && get_username() < operand.get_username()));
}



/*****************************************************************************
 * PRIVATE METHODS
 *****************************************************************************/
// inverts is_email_char
bool cemail::not_email_char(char ch)
{
  return !is_email_char(ch);
}

// returns the index of the '@' character in the email address
string::iterator cemail::find_at()
{
  iterator at = ::find(begin(), end(), '@');

  assert(at > begin() && at < end() - 1);
  return at;
}



/*****************************************************************************
 * TEST MAIN
 *****************************************************************************/


#if 0
char compare_ch(const cemail &x, const cemail &y)
{
  if (x < y)
    return '<';
  else if (x > y)
    return '>';
  else
    return '=';
}

#include <iostream>

int main(int argc, char **argv)
{
  cout << "\tTesting construction...";

  cemail good("blah@blah.com");
  cemail good2(string("blah@blah.com"));

  assert(!cemail::is_email("blah"));
  assert(!cemail::is_email(string("blah")));
  assert(!cemail::is_email("@blah.com"));
  assert(!cemail::is_email("asdf@blah."));
  assert(!cemail::is_email("asdf.blah@"));
  assert(!cemail::is_email("$%^@asdf.blah"));
  assert(!cemail::is_email("asdf@%^&.blah"));
  assert(!cemail::is_email("asdf@blah.$^"));

  cout << "ok." << endl << endl;


  cout << "\tTesting sanitization..." << endl;

  cemail test("#$(*%>asdf<$<yOurMoM@YOURmom.COM>#!)*$ASD&%#$");
  cout << "Unsanitized: " << test << endl;

  test.sanitize();
  cout << "Sanitized: " << test << endl << endl;


  cout << "\tTesting parser... " << endl;
  cout << "Username: " << test.get_username() << endl;
  cout << "Host: " << test.get_host() << endl << endl;


  cout << "\tTesting comparison..." << endl;

  cemail arr[3] =
    { "yourmom@abc.com", "zzz@yourmom.com", "yourmom@yourmom.com" };

  for (int i = 0; i < 3; i++)
    cout << test << ' ' << compare_ch(test, arr[i]) << ' ' << arr[i] << endl;

  cout << endl;


  return 0;
}
#endif

