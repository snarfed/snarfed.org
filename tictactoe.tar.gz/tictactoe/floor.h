/* File: floor.h
 * Author: Ryan Barrett (rbarret@stanford.edu)
 * --------------------
 * CS248 Fall 2001
 * HW3 - Video Game
 *
 * Declares the CFloor class. CFloor is the class for the bottom of the pool. It's
 * dirt simple. Let's keep it that way. :P
 *
 * Its methods are:
 *  void		Draw();
 */


#ifndef _FLOOR_H
#define _FLOOR_H

// -----------------------------------------------------------------------------
// CFLOOR CLASS
// -----------------------------------------------------------------------------
class CFloor
{
public:
  // public constants
  static const int kHeight;

  // ctor
  CFloor() {}

  // dtor
  ~CFloor() {}

  /* Draw
   * ----
   * Draws the floor.
   */
  void Draw() const;
};


#endif	// _FLOOR_H
