/* File: voxelmap.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Declares the voxel type and the voxelmap class. The voxelmap class stores a
 * rectangular map of voxels. The map can be read in from a RAW file.
 */

#ifndef _VOXELMAP_H
#define _VOXELMAP_H

#include <stdlib.h>
#include <string.h>
#include "util.h"
#include "lookTable.h"
#include "framebuffer.h"


#define HEIGHT_SCALE	8


/* Type: voxel
 * -----------
 * Stores a voxel's height, color, alpha, and other material properties.
 */
struct voxel {
	fixp height;
	float alpha;
	unsigned char r, g, b;
	// ctors
	voxel() {}
	voxel(fixp h) : height(h) {} 
};



/********** VOXELMAP CLASS *************************************************/

class voxelmap {

public:

	/* ctor
	 * ----
	 * Takes a name (for debugging).
	 */
	voxelmap(char *name);

	/* dtor
	 */
	~voxelmap();

	/* getName
	 * -------
	 * Returns the voxel map's name (for debugging).
	 */
	char *getName() { return name; }

	/* read
	 * ----
	 * Reads in a set of displacements (heights) from a heightmap stored as a
	 * RAW file. The width and height values must match the size of the
	 * heightmap stored in the RAW file.
	 *
	 * The dimensions of the heightmap must be square and must be a power of 2.
	 * If they aren't, an assertion is thrown.
	 */
	void read(char *rawfile, int size);

	/* mountain, volcanic
	 * ------------------
	 * These fill in the mountain and volcanic colormap tables based on a mountain
	 * color set and a volcanic color set.
	 */
	void mountain();
	void volcanic();

	/* foundIsland
	 * -----------
	 * Returns true if the camera is on top of the island (or within a certain
	 * radius), false otherwise.
	 */
	bool foundIsland(int cx, int cz);

	// public members
	voxel **voxels;	// the map, stored as a 2D array of voxels
	int size;		// size of the map
	pixel cmap[256];	// colormap table (indexed by height)

protected:

	// methods
	void colormap(unsigned char cbound[][4], int numBounds);

	// members
	char *name;		// the map's name
	int islandx, islandz;	// coordinates of x-shaped island
};



#endif	/* _VOXELMAP_H */
