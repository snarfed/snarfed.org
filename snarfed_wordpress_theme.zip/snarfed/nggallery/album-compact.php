<?php 
/** Nextgen gallery compact album template. Based on
 nextgen-gallery/view/album-compact.php.
**/
?>
<?php if (!defined ('ABSPATH')) die ('No direct access allowed'); ?><?php if (!empty ($galleries)) : ?>

<div class="ngg-albumoverview">
  <!-- List of galleries -->
  <?php foreach ($galleries as $gallery) : ?>
  
  <div class="ngg-album-compact">
    <div class="ngg-album-compactbox">
      <div class="ngg-album-link">
        <a class="Link" href="<?php echo $gallery->pagelink ?>">
          <img class="Thumb" alt="<?php echo $gallery->title ?>" src="<?php echo $gallery->previewurl ?>"/>
        </a>
      </div>
    </div>
    <h4><a class="ngg-album-desc" title="<?php echo $gallery->title ?>" href="<?php echo $gallery->pagelink ?>" ><?php echo $gallery->title ?></a></h4>
  </div>

   <?php endforeach; ?>
   
  <!-- Pagination -->
   <?php echo $pagination ?>

</div>

<?php endif; ?>