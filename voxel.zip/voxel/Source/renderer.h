/* File: renderer.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Declares a virtual renderer class. The renderer class provides an interface
 * that all voxel renderers must adhere to. All voxel renderers should subclass
 * renderer and implement all of renderer's pure virtual methods.
 *
 * This is only the minimum functionality that renderers must support. Each
 * renderer can provide additional features beyond this base.
 *
 * The renderer class itself should never be instantiated; it is only an
 * interface. Only implemented renderers (subclasses of renderer) should be
 * instantiated.
 */

#ifndef _RENDERER_H
#define _RENDERER_H

#include "voxelmap.h"


class renderer {

public:

	/* ctor
	 */
	renderer() {}	// renderer should never be instantiated

	/* dtor
	 */
	~renderer() {}


	/* These functions define the standard renderer interface that all voxel
	 * renderers must adhere to. They are defined as pure virtual functions so
	 * that subclasses are forced to implement them.
	 */

	/* render
	 * ------
	 * Renders the voxel map with the given camera position and orientation.
	 */
	virtual void render(voxelmap *map, float cx, float cy, float cz, int ctheta) = 0;

	/* resize
	 * ------
	 * Called when the screen is resized.
	 */
	virtual void resize(int width, int height) = 0;
};


#endif /* _RENDERER_H */