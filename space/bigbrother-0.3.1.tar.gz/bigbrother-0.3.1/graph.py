#!/usr/bin/python
#
# BigBrother
# http://snarfed.org/space/bigbrother
# Copyright 2003 Ryan Barrett <bigbrother@ryanb.org>
#
# File: graph.py
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

"""
Provides methods for generating graphs and plots of away message data generated
by bigbrother.py.
"""

import os
import gdchart
import chart
import bigbrother


# constants
TMP_DIR = '/tmp'
TMP_PREFIX = 'bigbrother_'
BIG_SIZE = (640, 480)
SMALL_SIZE = (320, 240)

COLORS = [0x0000ff, 0x00ff00, 0xff0000, 0x0080ff, 0x00ff80, 0xff0080, 0x8000ff,
          0xff8000, 0x8080ff, 0x80ff00, 0xff8080, 0xffff80, 0xff80ff, 0x80ffff,
          0x00ffff, 0xff00ff, 0xffff00, 0x808000, 0x800080, 0x008080]

# this is set from bigbrother.py
config = None

# a simple Chart wrapper that actually draws the chart on draw()
class BBChart(chart.Chart):
    def __init__(self):
        chart.Chart.__init__(self)
        self.option(format=gdchart.GDC_PNG)
#        self.option(bg_transparent=1)
        self.option(bg_color=0xffffff, edge_color=0x0, line_color=0x0,
                    plot_color=0x0000cd)
        self.option(set_color=COLORS)
        self.option(requested_yinterval=1)

    def draw(self, style, size, file, labels, *data):
        chart.Chart.draw(self)
        args = (style, size, file, labels) + data
        apply(gdchart.chart, args)


def pygd_piechart(graphfile, points):
    # cut off at threshold
    threshold = config.getint('BigBrother', 'large_tier_size')
    points, other = (points[:threshold - 1], points[threshold:])
    other = reduce((lambda x, y: ('Other', x[1] + y[1])), other, ('', 0))
    points.append(other)

    # set up chart
    c = BBChart()
    c.option(pie_color=list(COLORS))

    # make chart
    labels = [x[0] for x in points]
    values = [x[1] for x in points]
    c.draw(gdchart.GDC_2DPIE, BIG_SIZE, graphfile, labels, values)


def pygd_barchart(graphfile, points, big_size=True):
    # set up chart
    c = BBChart()

    # make chart
    labels = [label for (label, val) in points]
    values = [val for (label, val) in points]
    if big_size:
        size = BIG_SIZE
    else:
        size = SMALL_SIZE
    c.draw(gdchart.GDC_BAR, size, graphfile, labels, values)


def pygd_timeplot(graphfile, points):
    # set up chart
    c = BBChart()

    # prepare data
    points.sort()
    timestrs = [bigbrother.secs_to_time(secs) for (secs, val) in points]
    values = [val for (secs, val) in points]

    # make chart
    c.draw(gdchart.GDC_LINE, SMALL_SIZE, graphfile, timestrs, values)


def pygd_stack_timeplot(graphfile, *points_set):
    # set up chart
    c = BBChart()
#    c.option(requested_yinterval=.1)
#    c.option(requested_ymin=.5)

    # prepare labels
    intervals = range(0, bigbrother.SECS_IN_DAY, bigbrother.DIST_INTERVAL)
    timestrs = [bigbrother.secs_to_time(secs) for secs in intervals]

    # prepare datasets
    datasets = []
    for points in points_set:
        all = dict(zip(intervals, [0] * len(intervals)))
        all.update(dict(points))
        allpoints = all.items()
        allpoints.sort()
        datasets.append([val for (secs, val) in allpoints])

    # make chart
    c.option(stack_type=gdchart.GDC_STACK_BESIDE)
    c.option(threed_angle=80)
    args = [gdchart.GDC_LINE, BIG_SIZE, graphfile, timestrs]
    apply(c.draw, args + datasets)


def gnuplot_barchart(points, graphfile, title):
    # create gnuplot datafile
    # (i don't use tmpfile - although i wish i could, since it'd be more secure
    # - because i can't find a way to get its filename! silly, silly.)
    datafile = open(os.tempnam(TMP_DIR, TMP_PREFIX), 'w')
    points.sort()
    for x, y in points:
        datafile.write('%f %f\n' % (x, y))
    datafile.close()

    return gnuplot_datafile(points, graphfile, title, datafile.name,
                            plot_clause='with boxes')


def gnuplot_timeplot(points, graphfile, title):
    # create gnuplot datafile
    # (i don't use tmpfile - although i wish i could, since it'd be more secure
    # - because i can't find a way to get its filename! silly, silly.)
    datafile = open(os.tempnam(TMP_DIR, TMP_PREFIX), 'w')
    points.sort()
    for secs, value in points:
        timestr = bigbrother.secs_to_time(secs)
        datafile.write('%s %f\n' % (timestr, value))
    datafile.close()

    time_cmds = """
    set xdata time
    set timefmt '%%H:%%M'
    set format x '%%H:%%M'
    """
    return gnuplot_datafile(points, graphfile, title, datafile.name,
                            extra_cmds=time_cmds, plot_clause='smooth bezier')


def gnuplot_datafile(points, graphfile, title, filename, extra_cmds='',
                     plot_clause=''):
    # run the gnuplot script
    script = extra_cmds + """
    set terminal png
    set output '%(outfile)s'
    set title '%(title)s'
    set autoscale
    plot '%(filename)s' using 1:2 %(clause)s
    """ % { 'title': title, 'filename': filename, 'outfile': graphfile,
            'clause': plot_clause }

#    print script
    gnuplot = os.popen('/usr/bin/gnuplot', 'w')
    gnuplot.write(script)
    gnuplot.close()

