/* File: fb.cpp
 * Author: CS148 staff, Fall 2000
 * ------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Implements a software framebuffer that draws to OpenGL's viewport. For more
 * information, see framebuffer.h.
 *
 * The framebuffer is stored as an array of struct pixels. It is represented as
 * rows, then as pixels in rows. So from the start of the framebuffer in
 * memory the first row is stored, followed by the second, etc. So (assuming
 * (0,0) is the lower left corner), pixel (x,y) is at the location in memory:
 *
 *		fb + width * y + x.
 *
 * NOTE: Don't do this. Use the FB(x, y) macro defined below.
 */

#include "framebuffer.h"

// returns true if (r,g,b) is a valid OpenGL color, false otherwise
#define VALID_COLOR(r, g, b) \
((r) >= 0 && (r) <= 1 && (g) >= 0 && (g) <= 1 && (b) >= 0 && (b) <= 1)

// returns true if (x,y) is in the framebuffer, false otherwise
#define IN_FB(x, y) \
((x) >= 0 && (x) < width && (y) >= 0 && (y) < height)

// FB returns a pointer to the struct pixel at (x,y) in the framebuffer
#define FB(x, y)	(&fb[(y) * width + (x)])



/* ctor
 */
framebuffer::framebuffer(int width, int height) : width(width), height(height) {
	assert(width > 0 && height > 0);

	fb = NULL;
	fbInit();
}


/* dtor
 */
framebuffer::~framebuffer() {
	DEL(fb);
}


/* resize
 */
void framebuffer::resize(int width, int height) {
	DEL(fb);

	this->width = width;
	this->height = height;
	fbInit();
}


/* setPixel
 *
 * why do I assert that the color is valid but only return false if (x,y) is
 * out of bounds? I want to allow accesses outside the framebuffer to make
 * some algorithms easier to implement. but I can never draw a color that's not
 * valid, so I assert the color.
 */
bool framebuffer::setPixel(int x, int y, unsigned char r, unsigned char g,
						   unsigned char b) {
	if (!IN_FB(x, y))
		return false;

	FB(x, y)->r = r;
	FB(x, y)->g = g;
	FB(x, y)->b = b;
	return true;
}


/* getPixel
 */
bool framebuffer::getPixel(int x, int y, unsigned char *r, unsigned char *g,
						   unsigned char *b) {
	assert(r && g && b);

	if (!IN_FB(x, y))
		return false;

	*r = FB(x, y)->r;
	*g = FB(x, y)->g;
	*b = FB(x, y)->b;
	return true;
}


/* readRawfile
 */
void framebuffer::readRawfile(char *filename) {
	FILE *rawfile;
	unsigned char r, g, b;

	// open RAW file
	rawfile = fopen(filename, "rb");
	if (!rawfile) Err("Could not open rawfile %s.", filename);

	// read colors from rawfile into framebuffer
	for (int row = height - 1; row >= 0; row--) {
		for (int col = 0; col < width; col++) {
			if (fread(&r, 1, 1, rawfile) != 1 ||
				fread(&g, 1, 1, rawfile) != 1 ||
				fread(&b, 1, 1, rawfile) != 1)
				Err("Could not read from rawfile %s.", filename);
			setPixel(col, row, r, g, b);
		}
	}

	fclose(rawfile);
}


/* clear
 */
void framebuffer::clear() {
	memset(fb, 0, width * height * sizeof(struct pixel));
}


/* draw
 */
void framebuffer::draw() {
	glDrawPixels(width, height, GL_RGB, GL_UNSIGNED_BYTE, fb);
}


/* memptr
 */
struct pixel *framebuffer::memptr() {
	return fb;
}


/********** PROTECTED METHODS **********************************************/

/* fbInit
 * ------
 * Initialize the framebuffer in memory.
 */
void framebuffer::fbInit() {
	assert(!fb);

	fb  = new pixel[width * height];
	if (!fb)
		Err("Out of memory!");

	clear();
}


