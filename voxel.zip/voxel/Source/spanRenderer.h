/* File: spanRenderer.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Defines the spanRenderer class, which uses a span-based raycasting algorithm
 * to render a voxel map.
 *
 * The polyRenderer class is a subclass of renderer. It implements all of
 * renderer's virtual methods.
 */


#ifndef _SPANRENDERER_H
#define _SPANRENDERER_H

#include <math.h>
#include <assert.h>
#include "renderer.h"
#include "voxelmap.h"
#include "framebuffer.h"
#include "lookTable.h"

// distance from camera to screen projection plane
//#define SCREEN_DIST	(float)(1 / TAN((FOV) / 2))
#define FOV	60		// field of vision angle (angle of frustrum)



class spanRenderer : renderer {

public:

	/* ctor
	 * ----
	 * Constructor. The width and height arguments are for the OpenGL window.
	 */
	spanRenderer(int width, int height);

	/* dtor
	 */
	~spanRenderer();

	/* render
	 */
	void render(voxelmap *map, float cx, float cy, float cz, int ctheta);

	/* resize
	 * ------
	 * Resizes the renderer to the given screen size.
	 */
	void resize(int width, int height);

	/* drawsky
	 * -------
	 * Draws a sky picture onto the framebuffer. The height of the sky picture
	 * must match the height of the window, and width must be greater than the
	 * window width.
	 */
	void drawsky(framebuffer *sky, int ctheta);

	// public members
	bool interpolate;

protected:

	// methods
	inline fixp interpHeight(fixp fx, fixp fz, voxelmap *map);
	void lookRender(voxelmap *map, float cx, float cy, float cz, int ctheta);
	void surfRender(voxelmap *map, float cx, float cy, float cz, int ctheta);
	void nonPerspectiveRender(voxelmap *map, float cx, float cy, float cz, int ctheta);

	// members
	int width, height;
	framebuffer *fb;
	lookTable *lt;

	// stuff for ray surfing renderers to use
	int screen_dist;	// distance from the camera to the viewing plane
	fixp dphi;			// diff btw the angles through two adjacent columns
};



#endif /* _SPANRENDERER_H */

