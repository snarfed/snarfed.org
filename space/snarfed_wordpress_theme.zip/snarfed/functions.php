<?php
/*
 * snarfed WordPress theme
 * http://snarfed.org/snarfed_wordpress_theme
 * Ryan Barrett <wordpress-theme@ryanb.org>
 * Public domain.
 */

/*
 * Remove lots of things that we don't want:
 * - access div in the header
 * - blog description (we replace it with our own below)
 * - an annoying inline stylesheet that the recent comments widget injects
 * - edit/delete/login/logout links
 * - meta navigation links
 * - misc javascript
 * etc.
 *
 * Note that some actions can't be removed directly in functions.php; have to
 * remove them indirectly like this. See the bottom of
 * http://themeshaper.com/thematic/guide/?page_id=10 .
 *
 * Also, some things are preserved on wp-admin requests because they're needed
 * there. (I originally preserved them on requests from localhost instead, with
 * $_SERVER['REMOTE_ADDR'] == '127.0.0.1', but that made them show up when
 * looking at normal pages on my local instance.)
 */
function snarfed_remove_actions() {
  remove_action('thematic_header', 'thematic_blogdescription', 5);
  remove_action('thematic_header', 'thematic_access', 9);

  global $wp_widget_factory;
  remove_action('wp_head', array($wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style'));
}
add_action('init','snarfed_remove_actions');

function snarfed_thematic_show_pingback($orig) {
  return FALSE;
}
add_filter('thematic_show_pingback', 'snarfed_thematic_show_pingback');

function snarfed_disable_unless_admin($orig) {
  if (substr_count($_SERVER['REQUEST_URI'], '/wp-admin/'))
    return $orig;
  else
    return '';
}
add_filter('get_edit_post_link', 'snarfed_disable_unless_admin');
add_filter('get_delete_post_link', 'snarfed_disable_unless_admin');
add_filter('get_edit_comment_link', 'snarfed_disable_unless_admin');
add_filter('post_comments_link', 'snarfed_disable_unless_admin');
add_filter('thematic_postheader_posteditlink', 'snarfed_disable_unless_admin');
add_filter('thematic_postfooter_posteditlink', 'snarfed_disable_unless_admin');
add_filter('thematic_postmeta_editlink', 'snarfed_disable_unless_admin');
add_filter('comment_form_logged_in', 'snarfed_disable_unless_admin');
add_filter('comment_form_logged_in', 'snarfed_disable_unless_admin');
add_filter('comment_form_logged_in_after', 'snarfed_disable_unless_admin');
add_filter('wlwmanifest_link', 'snarfed_disable_unless_admin');
add_filter('login_url', 'snarfed_disable_unless_admin');
add_filter('logout_url', 'snarfed_disable_unless_admin');
add_filter('loginout', 'snarfed_disable_unless_admin');

add_filter('thematic_create_robots', 'snarfed_disable_unless_admin');
add_filter('thematic_head_scripts', 'snarfed_disable_unless_admin');

remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');

/*
 * If openid delegation is configured in wp-config.php, add OpenID tags.
 */
function snarfed_add_openid($orig) {
  ?>
  <link rel="openid2.provider" href="<?php print OPENID_DELEGATION_PROVIDER ?>" />
  <link rel="openid2.local_id" href="<?php print OPENID_DELEGATION_LOCAL_ID ?>" />
  <?php
}
if (defined("OPENID_DELEGATION_PROVIDER") && defined("OPENID_DELEGATION_LOCAL_ID")) {
  add_action('wp_head', 'snarfed_add_openid');
}

function snarfed_add_ajax_search() {
  ?>
  <script type="text/javascript" src="http://www.google.com/uds/api?file=uds.js&v=1.0&key=<?php print GOOGLE_AJAX_SEARCH_API_KEY ?>"></script>
  <script type="text/javascript" src="/w/wp-content/themes/snarfed/ajax_search.js"></script>
  <?php
}
if (defined("GOOGLE_AJAX_SEARCH_API_KEY")) {
  add_action('wp_head', 'snarfed_add_ajax_search');
}



/*
 * Linkify the blog description.
 */
function snarfed_blogdescription() {
  ?>
  <div id="blog-description"><a href="about">
    <?php bloginfo('description'); ?>
  </a></div>
  <?php
}
add_action('thematic_header', 'snarfed_blogdescription', 5);



/* --------------------------------------------------------------
 * Entry meta
 * -------------------------------------------------------------- */

/*
 * Show meta on pages as well as posts.
 */
function snarfed_postheader($orig) {
  if (is_404()) {
    return thematic_postheader_posttitle();        
  } else {
    return thematic_postheader_posttitle() . thematic_postheader_postmeta();
  }
}
add_filter('thematic_postheader', 'snarfed_postheader');


/*
 * Add extra stuff to entry-meta, but only if we're display a single post or
 * page.
 */
function snarfed_build_postmeta($label, $value, $separator) {
  return "\n<span class=\"meta-sep meta-sep-snarfed meta-sep-" .
    $label . '">' . $separator . "</span>\n" .
    '<span class="' . $label . '">' . $value . '</span>';
}

function snarfed_postmeta($orig) {
  // No post meta stuff on index page
  if (is_page_template("posts-and-pages.php")) {
    return '';
  }

  $extra = '';
  if (get_the_time('j F Y') !== get_the_modified_time('j F Y')) {
    $updated_str = '<span class="entry-updated">' .
      get_the_modified_date() . '</span>';
    $extra .= snarfed_build_postmeta('updated', $updated_str, '<br />updated');
  }

  if (is_single() || is_page()) {
    // $extra .= snarfed_build_postmeta('raw', '<a href="' . get_permalink() . '.txt">raw</a>', '<br />');
    // $extra .= snarfed_build_postmeta('history', '<a href="#todo">history</a>', '|');
  }

  $suffix = '</div><!-- .entry-meta -->';
  return str_replace($suffix, $extra . $suffix, $orig);
}
add_filter('thematic_postheader_postmeta', 'snarfed_postmeta');


/*
 * 404 page. Run a google ajax site search for the url, using ajax_search.js.
 */
function get_tld($url) {
  preg_match("%https?://([^/]+)%", $url, $matches);
  return $matches[1];
}

function childtheme_override_404_content() {
  global $wp_query;
  $query = join($wp_query->query);
  $domain = get_tld(get_bloginfo('url'));

?>
  <h1 class="entry-title">Not Found</h1>
  <p class="entry-content">Sorry, <?php echo $query ?> was not found.
  <a href="http://www.google.com/search?sitesearch=<?php echo $domain ?>&q=<?php echo $query ?>">
    Search for related pages?</a></p>

<script type="text/javascript">
  results_div = document.getElementById('content');
  results_div.style.display = "none";

  // insert the "not found" header before the results div
  header = document.createElement('div');
  header.innerHTML =
    '<h1 class="entry-title">Not Found</h1>' +
    '<p class="entry-content">Sorry, <?php echo $query ?> was not found.' +
    '  Here are some related pages:</p>';
  results_div.parentNode.insertBefore(header, results_div);

  // queue the search
  window.onload=function() {
    site_search('<?php echo $domain ?>',
                '<?php echo ereg_replace("[_!?:,()-]", " ", $query) ?>');
  }
</script>
<?php
}


/* --------------------------------------------------------------
 * Comments
 * -------------------------------------------------------------- */

/*
 * Pages need the 'comments' custom field to allow comments. Set that
 * automatically.
 * TODO: do this in blogpost.sh?
 */
function snarfed_add_comments_value($orig) {
  global $id;
  add_post_meta($id, 'comments', true, true /* unique */);
  return $orig;
}
add_filter('thematic_postheader', 'snarfed_add_comments_value');


/*
 * Hide the comment form behind Javascript.
 */
function snarfed_post_comment_link() {
  ?>
  <script type="text/javascript">
  function show_comment_form() {
    document.getElementById('commentform').style.display = 'block';
    document.getElementById('comment-toggle').style.display = 'none';
    return false;
  }
  </script>
  
  <p id="comments-feed">
    <a href="<?php print get_post_comments_feed_link(); ?>">
      <img src="/w/wp-content/themes/snarfed/images/rss_16.png" /></a>
    <a href="<?php print get_post_comments_feed_link(); ?>">
      Comments feed</a>
    </a>
  </p>

  <p id="comment-toggle">
    <a href="#commentform" onclick="return show_comment_form();">
      <img src="/w/wp-content/themes/snarfed/images/comment_16.png" /></a>
    <a href="#commentform" onclick="return show_comment_form();">
      Post a comment...</a>
  </p>
  <?php
}
add_action('thematic_abovecommentsform', 'snarfed_post_comment_link');

/*
 * Tweak comments meta. Show time only if the comment was posted today,
 * otherwise show date only.
 */
function snarfed_commentmeta($orig) {
  $time = (date('d/m/Y') == get_comment_date('d/m/Y'))
    ? get_comment_time() : get_comment_date();
  return '<div class="comment-meta">' . $time .
    ' <a class="comment-permalink" href="' . get_comment_link() . '">#</a></div>';
}
add_filter('thematic_commentmeta', 'snarfed_commentmeta');

/*
 * Tweak recent comment text. Remove comment author and add icon.
 *
 * TODO: looks like the widget_recent_comment filter was removed in WP 3.0. :/ 
 * I was able to do use the get_comment_author_link filter to do something
 * similar, but that's too broad: it also happens when displaying comments
 * normally, in the admin pages, etc. grr.
 */
function snarfed_tweak_recent_comment($orig) {
  /* TODO: switch to preg_replace('/.../', ...) */
  return ereg_replace(
    '^(<a[^>]*>)?([^<]*)(</a>)? on',
    '<img src="/w/wp-content/themes/snarfed/images/comment_16.png" />',
    $orig);
}
add_filter('widget_recent_comment', 'snarfed_tweak_recent_comment');

/*
 * Add comment icon to "X Comments"/"Post Comment" link at bottom of posts in
 * front page.
 */
function snarfed_thematic_postfooter_postcomments($orig) {
  return '<img src="/w/wp-content/themes/snarfed/images/comment_16.png" />' .
    $orig;
}
add_filter('thematic_postfooter_postcomments',
           'snarfed_thematic_postfooter_postcomments');


/* --------------------------------------------------------------
 * Posts and Pages template
 * -------------------------------------------------------------- */
function childtheme_override_category_archives() {
  return false;
}
function childtheme_override_archivesopen() {
  return false;
}
function childtheme_override_archivesclose() {
  return false;
}

/*
 * Add the post date to each post's link, outside of the link itself.. Have to
 * parse this out of the link html because i don't know of a way to get at the
 * post itself, or its id, inside a get_archives_link or the_title filter.
 */
function snarfed_add_date_header($orig) {
  global $snarfed_add_date_header_last_year;
  preg_match("/<a href='[^']*(\d{4})-\d{2}-\d{2}/", $orig, $matches);
  if ($matches[1] != $snarfed_add_date_header_last_year) {
    $orig = '<h3>' . $matches[1] . ':</h3>' . $orig;
    $snarfed_add_date_header_last_year = $matches[1];
  }
  return $orig;
}
add_filter('get_archives_link', 'snarfed_add_date_header');

/*
 * Show the posts and pages archives, separately. The first div is list of all
 * posts, ordered by date descending. The second div is a list of all pages,
 * ordered alphabetically.
 */
function childtheme_override_monthly_archives() {
?>
  <div id="posts-and-pages-posts" class="posts-and-pages">
    <ul>
      <?php
        /* defined in wp-includes/general-template.php */
        wp_get_archives('type=postbypost')
      ?>
    </ul>
  </div>

  <div id="posts-and-pages-pages" class="posts-and-pages">
    <h3>Pages:</h3>
      <?php
        /* defined in wp-includes/post-template.php. also see wp_list_pages() */
        wp_page_menu()
      ?>
  </div>
<?php
}
