<?php
/*
Template Name: Posts and Pages Archive
Customized in snarfed/functions.php.
*/
?>

<?php
require(TEMPLATEPATH . '/archives.php');
?>
