/* AJAX comment support for pyblosxom.
 *
 * Ryan Barrett <pyblosxom@ryanb.org>
 * http://snarfed.org/space/pyblosxom+ajax+comments
 */
var xml_http_request;

function get_xmlhttpreq() {
  if (window.XMLHttpRequest) {
    xml_http_request = new XMLHttpRequest()
  } else if (window.ActiveXObject) {
    try {
      xml_http_request = new ActiveXObject("Msxml2.XMLHTTP");
    } catch(e) {
      xml_http_request = new ActiveXObject("Microsoft.XMLHTTP");
    }
  }

  if (!xml_http_request) {
    alert("Browser does not support HTTP Request");
    return null;
  }

  return xml_http_request;
}

// Initially, only the 'submit' buttons in the comment form are displayed, so
// that they're used if JavaScript is disabled. If JavaScript and
// XmlHttpRequest are supported, this hides the 'submit' buttons and shows
// the 'button' buttons, which use AJAX.
// function prepare_comment_form() {
if (get_xmlhttpreq()) {
  document.getElementById('preview-post').style.display = 'none';
  document.getElementById('post-post').style.display = 'none';   
  document.getElementById('preview-ajax').style.display = 'inline';
  document.getElementById('post-ajax').style.display = 'inline';
}

// remove the dom element with the given id
function remove(id) {
  elem = document.getElementById(id);
  if (elem)
    elem.parentNode.removeChild(elem);
}

function send_comment(type) {
  req = get_xmlhttpreq();
  if (!req)
    return;

  if (type != 'post' && type != 'preview') {
    alert('Bad comment request: ' + type);
    return;
  }

  // if there's already a preview or "waiting for server" message, delete it
  remove('comment-preview');
  remove('waiting');

  // build the XmlHttpRequest. the form's "action" is the URL to POST to.
  form = document.getElementById('comment-form');
  req.onreadystatechange = function() { comment_statechange(type); }
  req.open('POST', form.action, true);

  // build the post data
  post_data = 'ajax=' + type;
  post_data += '&' + type + '=1';

  // include all of the the form elements (for e.g. comment spam plugins)
  for (i = 0; i < form.elements.length; i++) {
    elem = form.elements[i];
    if (elem.type != 'submit' && elem.type != 'button')
      post_data += '&' + elem.name + '=' + escape(elem.value);
  }

  // send the request and tell the user. note that innerHTML is case sensitive.
  req.send(post_data);

  waiting = document.createElement('p');
  type_capitalized = 'P' + type.substring(1)
  waiting.innerHTML = '<span id="waiting" class="ajax-message">' +
                      type_capitalized + 'ing...</span>';
  comment_anchor = document.getElementById('comment-anchor');
  comment_anchor.parentNode.insertBefore(waiting, comment_anchor);
}

function comment_statechange(type) {
  if (type != 'post' && type != 'preview') {
    alert('Bad comment request: ' + type);
    return;
  }

  if (xml_http_request.readyState == 4) {
    remove('waiting');
    comment = document.createElement('div');
    if (type == 'preview')
      comment.setAttribute('id', 'comment-preview');

    if (xml_http_request.responseText.length > 0) {
      comment.innerHTML = xml_http_request.responseText;
      if (type == 'post') {
        // clear the comment form
        document.getElementById('comment-author').value = '';
        document.getElementById('comment-url').value = '';
        document.getElementById('comment-body').value = '';
      }
    }
    else {
      comment.innerHTML =
        '<p id="waiting" class="ajax-error">Empty response from server.</p>';
    }

    comment_anchor = document.getElementById('comment-anchor');
    comment_anchor.parentNode.insertBefore(comment, comment_anchor);
  }
}
