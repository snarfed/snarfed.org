/* File: spanRenderer.cpp
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Implements the spanRenderer class. For more information, see spanRenderer.h.
 */


#include "spanRenderer.h"


/* ctor
 */
spanRenderer::spanRenderer(int width, int height) : width(width),
	height(height) {
	fb = new framebuffer(width, height);
	lt = new lookTable(FOV, width);

	screen_dist = width / 64;
	dphi = (fixp)(((double)1 / (double)screen_dist) * FIXP_MULT);
	interpolate = false;
}


/* dtor
 */
spanRenderer::~spanRenderer() {
	DEL(fb);
	DEL(lt);
}


/* resize
 */
void spanRenderer::resize(int width, int height) {
	this->width = width;
	this->height = height;

	fb->resize(width, height);
	DEL(lt);
	lt = new lookTable(FOV, width);
}


/* render
 * ------
 * Most of the renderers in spanRenderer iterate through the viewing frustrum
 * left-to right, and rasterize each column before moving on to the next. The
 * rendering is done with a ray, and the ray is stored in polar coordinates,
 * so all of the renderers will have r and theta variables that store current
 * length and angle of the ray.
 */
#define RAY_X	((float)cx + (float)r * COS(theta))
#define RAY_Y	((float)cy + (float)r * SIN(phi))
#define RAY_Z	((float)cz + (float)r * SIN(theta))

void spanRenderer::render(voxelmap *map, float cx, float cy, float cz, int ctheta) {
	assert(cx >= 0 && cx < map->size && cz >= 0 && cz < map->size);

//	nonPerspectiveRender(map, cx, cz, ctheta);
//	surfRender(map, cx, cy, cz, ctheta);
	lookRender(map, cx, cy, cz, ctheta);

	fb->draw();
}


/********** PRIVATE METHODS ************************************************/

/* lookRender
 * ----------
 * A column surfing renderer. Precomputes the delta phi angle between the rays
 * through two adjacent screen pixels in a column. Uses this with look angles
 * (angles based on this delta angle instead of single degrees). Also uses a
 * (hacked) fixed-point data type to avoid expensive floating point operations.
 *
 * This optimization is described in Andre LaMothe's article on voxel terrain
 * rendering in Game Developer Magazine, 11/1997.
 */
#undef LOOK_360
#define LOOK_360 (lt->look_360)

#define LOOK_1		(LOOK_360 / 360)
#define MAX_STEPS	200

// FB returns the struct pixel at (x,y) in the framebuffer
#define FB(x, y)	(fbptr[(y) * width + (x)])

// LSIN and LCOS, fake inlined functions to parallel lookTable::sin and cos
#define LSIN(delta, la) \
{ if ((la) < 0) (delta) = table[(la) + LOOK_360]; \
else if ((la) >= LOOK_360) (delta) = table[(la) - LOOK_360]; \
else (delta) = table[(la)]; }
#define LCOS(delta, la) LSIN(delta, (la) + LOOK_90);


inline fixp spanRenderer::interpHeight(fixp fx, fixp fz, voxelmap *map) {
	// get integer coordinates - clip x and z to be positive and on the map
	int sizemask = map->size - 1;
	int x = fx / FIXP_MULT & sizemask, z = fz / FIXP_MULT & sizemask;

	// get four height values to interpolate across
	fixp y1 = map->voxels[x][z].height;
	fixp y2 = map->voxels[(x + 1) & sizemask][z].height;
	fixp y3 = map->voxels[x][(z + 1) & sizemask].height;
	fixp y4 = map->voxels[(x + 1) & sizemask][(z + 1) & sizemask].height;

	// get differences
	fixp dx = fx & FIXP_FRACTION_MASK, dz = fz & FIXP_FRACTION_MASK;

	// interpolate
	fixp y5 = y1 + (y2 - y1) * dx / FIXP_MULT;
	fixp y6 = y3 + (y4 - y3) * dx / FIXP_MULT;
	return y5 + (y6 - y5) * dz / FIXP_MULT;
} 

void spanRenderer::lookRender(voxelmap *map, float cx, float cy, float cz, int ctheta) {
	fixp fcx = (int)(cx * FIXP_MULT),	// fixed-point camera coordinates
		fcy = (int)(cy * FIXP_MULT) * HEIGHT_SCALE,
		fcz = (int)(cz * FIXP_MULT);
	fixp frx, fry, frz;	// fixed-point ray coordinates
	fixp dx, dy, dz;	// ray deltas
	fixp fyscale;		// y scale, increases with each ray step
	lookAngle rtheta;	// ray look angle
	int line;			// screen line
	fixp vheight;		// height of current voxel column
	pixel *color;		// pointer to current (interpolated) color
	fixp *table = lt->Table();		// lookup table pointer
	pixel *fbptr = fb->memptr();	// pointer to framebuffer in memory

	assert(map);

	// initialize ray angle
	rtheta = (ctheta + FOV / 2) * LOOK_1;

	// cast a ray for each column on the screen
	for (int column = 0; column < width; column++) {
		// start ray at the camera coordinates
		frx = fcx;
		fry = fcy;
		frz = fcz;

		// calculate the ray deltas
		LCOS(dx, rtheta);
		LSIN(dz, rtheta);
		dy = - dphi * height / 2;
		fyscale = 0;

		line = 0;

		// step ray for a while
		for (int step = 0; step < MAX_STEPS; step++) {

			// get current voxel column (and interpolate if it's toggled)
			if (interpolate)
				vheight = interpHeight(frx, frz, map);
			else
				vheight = map->voxels[frx / FIXP_MULT][frz / FIXP_MULT].height;

			// check if ray intersected a column
			if (fry < vheight) {

				// draw pixels in column until top of column
				for ( ; fry <= vheight; fry += fyscale) {
					// adjust ray's delta slope
					dy += dphi;

					// draw pixel with colors in colormap
					if (fry < 0)
						color = &map->cmap[0];
					else color = &map->cmap[fry / FIXP_MULT / HEIGHT_SCALE];
					FB(column, line).r = color->r;
					FB(column, line).g = color->g;
					FB(column, line).b = color->b;

					// check if pixel is off screen
					if (++line >= height) {
						// it is, force outer step loop to exit
						step = MAX_STEPS;
						break;
					}
				}

			}	// end if

			// step ray coordinates, clip x and z to be positive and on the map
			int mapmask = map->size * FIXP_MULT - 1;
			frx = (frx + dx) & mapmask;
			frz = (frz + dz) & mapmask;
			fry = fry + dy;

			// increment voxel y coordinate scale
			fyscale += dphi;
		}

		// increment ray angle
		rtheta--;
	}
}




/* surfRender
 * ----------
 * A smarter renderer. Uses ray surfing, since the terrain is constrained to
 * convexity on the Y axis. Also renders the voxels in perspective correctly.
 */
#define MIN_R_ITER	((float)150 / width)
#define MAX_R_ITER	((float)1000 / width)
#define D_R_ITER	((float)10 / width)
#define A_ITER		((float)43 / width)
// FB returns the struct pixel at (x,y) in the framebuffer
#define FB(x, y)	(fbptr[(y) * width + (x)])
#define SCREEN_DIST	1

void spanRenderer::surfRender(voxelmap *map, float cx, float cy, float cz, int ctheta) {
	float r, theta, phi;	// ray's polar coordinates
	float rx, rz, ry;	// ray's cartesian coordinates
	float dr = MIN_R_ITER, ddr = D_R_ITER, maxr = MAX_R_ITER;
	float da = A_ITER;
	struct pixel *fbptr = fb->memptr();
	int px, py;			// framebuffer pixel coordinates
	voxel *v;

	assert(dr > 0 && da > 0);

	// iterate through viewing frustrum (left to right, bottom to top)
	for (theta = ctheta + FOV / 2; theta >= ctheta - FOV / 2; theta -= da) {
		phi = - FOV / 2;

		// extend ray until we we're off the heightmap
//		for (r = SCREEN_DIST; ; r += dr) {
		for (r = SCREEN_DIST; ; r += dr) {
//			if (dr < MAX_R_ITER) dr += ddr;
			rx = RAY_X;
			rz = RAY_Z;
			if (rx < 0 || rx >= map->size || rz < 0 || rz >= map->size)
				break;	// ray is off the heightmap
			v = &map->voxels[(int)rx][(int)rz];

			// if we hit a column, draw it
			ry = RAY_Y;
			for ( ; ry <= v->height && phi <= FOV / 2; phi += da) {
//			for ( ; ry <= v->height && phi <= FOV / 2; ) {
//				ry += 1;
//				phi = (float)sinh((ry - cy) / r) / PI_OVER_180;

//				project(theta - ctheta, phi, v->r, v->g, v->b);
//				project(rx, ry, rz, v->r, v->g, v->b);

//				fb->setPixel((int)(width / 2 * TAN(theta - ctheta)) + width / 2,
//					(int)(height / 2 * TAN(phi)) + height / 2, v->r, v->g, v->b);

				px = (int)(width / 2 * TAN((theta - ctheta) * 90 / FOV)) + width / 2;
				py = (int)(height / 2 * TAN(phi * 90 / FOV)) + height / 2;
				FB(px, py).r = v->r;
				FB(px, py).g = v->g;
				FB(px, py).b = v->b;

				ry = RAY_Y;
			}
			if (phi > FOV / 2)
				break;
		}

	}
}



/* nonPerspectiveRender
 * --------------------
 * A naive renderer. only renders peaks and doesn't do perspective right. also slow. 
 */
void spanRenderer::nonPerspectiveRender(voxelmap *map, float cx, float cy, float cz, int ctheta) {
	int ye = 100,		// eye height
		yv,				// altitude of voxel column
		yk = 100,			// scale constant
		yc = MIN(width, height) / 2,	// centering constant (half window resolution)
		x, z,			// voxelmap coords
		ys;				// screen coord for current voxel
	voxel *curv;

	// just draw a single line of voxel columns right now
	for (int theta = ctheta - FOV / 2; theta < ctheta + FOV / 2; theta++) {
		for (int r = 255; r > 0; r--) {
			x = RAY_X;
			z = RAY_Z;
			if (x < 0 || x >= map->size || z < 0 || z >= map->size)
				continue;

			curv = &map->voxels[x][z];
			yv = curv->height;
			ys = (yv - ye) * yk / r + yc;
			fb->setPixel(x + 100, ys, curv->r, curv->g, curv->b);
		}
	}
}


/* drawsky
 * -------
 * Draws the right part of the sky to the framebuffer, according to the
 * camera angle. Throws an assertion if a sky is not loaded.
 */
void spanRenderer::drawsky(framebuffer *sky, int ctheta) {
	assert(sky);
	pixel *fbptr = fb->memptr(), *skyptr = sky->memptr();
	int start, end,	// sky columns to start and end drawing at
		len;		// number of columns to draw

	// clip start column to a valid sky column
	start = (LOOK_360 - ctheta) * LOOK_1 % LOOK_180;

	// get end column and length
	end = (start + width) % LOOK_180;
	if (end > start)
		len = width;
	else len = LOOK_180 - start;

	// copy rows from sky to framebuffer
	for (int row = 0; row < height; row++) {
		memcpy(fbptr, skyptr + start, len * sizeof(pixel));
		if (len < width) {	// sky wraps on screen, copy partial row
			memcpy(fbptr + len, skyptr, (width - len) * sizeof(pixel));
		}

		// move fbptr and skyptr to next row
		fbptr += width;
		skyptr += LOOK_180;
	}
}



/********** HELPER FUNCTIONS ************************************************/

