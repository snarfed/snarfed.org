import bigbrother_unittest, bigbrother
bigbrother.read_awaylog(bigbrother_unittest.LINES)
print bigbrother.msgs_by_time
print bigbrother_unittest.MSGS_BY_TIME


from bigbrother import *
import bigbrother_unittest
read_awaylog(bigbrother_unittest.LINES)
print times_by_msg
