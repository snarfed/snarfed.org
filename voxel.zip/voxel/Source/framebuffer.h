/* File: framebuffer.h
 * Author: CS148 staff, Fall 2000
 * ------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Implements a software framebuffer that draws to OpenGL's viewport. Supports
 * resizing, setting a pixel's color, reading a pixel's current color, and clearing to
 * 0 (black in OpenGL).
 */


#ifndef _FRAMEBUFFER_H
#define _FRAMEBUFFER_H

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "glut.h"
#include "util.h"


/* Type: pixel
 * -----------
 * Defines a pixel stored in the framebuffer.
 */
struct pixel {
	unsigned char r, g, b;
	// ctors
	pixel(unsigned char r, unsigned char g, unsigned char b) : r(r), g(g), b(b) {}
	pixel() { r = g = b = 0; }
};



class framebuffer {
public:
	
	/* ctor
	 * ----
	 * Constructor. Takes a width and a height.
	 */
	framebuffer(int width, int height);

	/* dtor
	 */
	~framebuffer();

	/* resize
	 * ------
	 * Resizes the framebuffer.
	 */
	void resize(int width, int height);

	/* setPixel
	 * --------
	 * Sets the pixel at (x,y) to the given RGB color. Returns false if (x,y)
	 * is outside the bounds of the framebuffer. Throws an assertion if (r,g,b)
	 * is not a valid OpenGL color.
	 */
	bool setPixel(int x, int y, unsigned char r, unsigned char g,
		unsigned char b);

	/* getPixel
	 * --------
	 * Reads the color of the pixel at (x,y). Returns false if (x,y) is outside
	 * the framebuffer. Throws an assertion if r, g, or b is NULL.
	 */
	bool getPixel(int x, int y, unsigned char *r, unsigned char *g,
		unsigned char *b);

	/* clear
	 * -----
	 * Clears the entire framebuffer to 0.
	 */
	void clear();

	/* draw
	 * ----
	 * Draws the current framebuffer to OpenGL's viewport.
	 */
	void draw();

	/* readRawfile
	 * -----------
	 * Reads a raw file into the framebuffer.
	 */
	void framebuffer::readRawfile(char *filename);

	/* memptr
	 * ------
	 * Returns a pointer to the framebuffer in memory.
	 */
	struct pixel *memptr();

	// public members
	int width, height;	// framebuffer dimensions

protected:

	// protected methods
	void fbInit();

	// members
	struct pixel *fb;	// framebuffer, stored as an array of pixels
};


#endif /* FRAMEBUFFER_H */