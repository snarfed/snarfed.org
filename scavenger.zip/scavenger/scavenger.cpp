/* File: scavenger.cpp
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------
 * Opens all the files in the directory specified on the command line, strips
 * out strings that are likely to be email addresses (according to a very crude
 * heuristic), and writes them to the output file, one per line.
 *
 * The last file is assumed to be the output file, all the rest are assumed to
 * be input files.
 **/

#include "email.h"

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <algorithm>
#include <cassert>
#include <stdlib.h>    // for system()

using namespace std;


/*****************************************************************************
 * CONSTANTS
 *****************************************************************************/
const string kusage(
"Usage: scavenger [INPUT FILES]... [OUTPUT FILE]\n");

const string kerr_output_exists("Error: output file exists: ");
const string kerr_input_not_found("Error: input file not found: ");
const string kerr_input_equals_log("Error: input file is same as log file: ");
const string kdefault_outfile("emails.out");

// the console command stuff for getting a plan vanilla directory listing -
// just a list of filenames, one per line, and no extra information
#ifdef _WIN32
  const string kdelete_cmd("del");
  const char kslash_char('\\');
#else
  const string kdelete_cmd("rm -f");
  const char kslash_char('/');
#endif


/*****************************************************************************
 * HELPER PROTOTYPES
 *****************************************************************************/
inline void err_exit(const string &msg, int retval = 0);
pair<string, string> parse_params(int argc, char **argv);
void get_infiles(int argc, char **argv, vector<string> &infiles);
void strip_file(ifstream &in, set<cemail> &emails);
void write_output(const string &filename, const set<cemail> &emails);


/*****************************************************************************
 * MAIN
 *****************************************************************************/
int main(int argc, char **argv)
{
  set<cemail> emails;

  if (argc < 3)
    err_exit(kusage, 0);

  string outfile(argv[argc - 1]);       // get output file
  ifstream out_test(outfile.c_str());

  if (out_test.is_open()) {
    cout << "Output file '" << outfile << "' exists, overwrite? ";
    char c;
    cin >> c;
    if (tolower(c) != 'y')
      exit(0);
  }


  vector<string> infiles;               // get input files
  get_infiles(argc, argv, infiles);
  if (find(infiles.begin(), infiles.end(), argv[argc - 1]) != infiles.end())
    err_exit(kerr_input_equals_log + argv[argc - 1]);

  cout << "Parsing";
  string filename;

  // strip each file
  vector<string>::const_iterator it;
  for (it = infiles.begin(); it != infiles.end(); it++) {
    cout << "." << flush;
    const string &filename = *it;
    if (filename == argv[0])
      continue;  // don't try to parse the executable

    ifstream in(filename.c_str());
    strip_file(in, emails);
  }


  // write to output file
  write_output(outfile, emails);

  cout << endl << emails.size() << " email addresses written to " << outfile
       << "." << endl;
  return 0;
}



/*****************************************************************************
 * HELPER DEFINITIONS
 *****************************************************************************/

/* err_exit
 *
 * Prints the given error message and an endline, then exits with the given
 * return value.
 **/
inline void err_exit(const string &msg, int retval /* = 0 */)
{
  cout << msg << endl;
  exit(retval);
}



/* get_infiles
 *
 * Parses the parameters into a vector of input files into the infiles vector.
 * If any of the input files don't exists, the program prints an error message
 * and exits.
 **/
void get_infiles(int argc, char **argv, vector<string> &infiles)
{
  assert(argc >= 3 && infiles.empty());

  ifstream in_test;

  for (int i = 1; i < argc - 1; i++) {
    assert(argv[i]);

    in_test.open(argv[i]);        // check that the file exists
    if (!in_test.is_open() || !in_test.good())
      err_exit(kerr_input_not_found + argv[i]);
    in_test.close();
  
    infiles.push_back(string(argv[i]));
  }
}


/* strip_file
 *
 * Parses the in stream, strips email addresses from it, and adds them to the
 * emails set. Doesn't add duplicates.
 *
 * THIS ISN'T IMPLEMENTED YET:
 * The heuristic functor is used to determine whether each token in the in
 * stream is or isn't an email address.
 **/
void strip_file(ifstream &in, set<cemail> &emails)
{
  assert(in.good());

  in.setf(ios::skipws);

  while (in.good()) {
    string token;
    in >> token;

    if (cemail::is_email(token)) {
      cemail email(token);
      email.sanitize();
      emails.insert(email);  // if it's already in the set, this is a nop
    }
  }
}



/* write_output
 *
 * Opens the output file and writes the given set of email addresses to the
 * output stream.
 *
 * NOTE: This depends on the fact that a set iterator returns its elements in
 * sorted order, least to greatest.
 **/
void write_output(const string &outfile, const set<cemail> &emails)
{
  ofstream out(outfile.c_str());
  assert(out.is_open() && out.good());

  set<cemail>::const_iterator it;
  for (it = emails.begin(); it != emails.end(); it++)
    out << *it << endl;
}



/*****************************************************************************
 * OLD USAGE MODEL
 *****************************************************************************/
#if 0

#ifdef _WIN32
  const string kdir_list_cmd("dir /b");
#else
  const string kdir_list_cmd("ls");
#endif

void get_dir_list(const string &dir, ifstream &dir_list);

const string kdir_list_tmpfile("scavenger.tmp");
const string kdefault_dir(".");
const string kusage(
"Usage: scavenger [DIRECTORY] [OUTFILE]\n \
DIRECTORY defaults to current directory\n \
OUTFILE defaults to emails.out");


// these would have been used with commands from the execv family - i'm using
// system(), not execv(), but i'm keeping the setup below around, just in case.
// const char *kdir_list_tmpfile("scavenger.tmp");
// #ifdef _WIN32
//   const char *kdir_list_cmd("dir /b");
//   const char *kdir_list_args[] = {"/b", ">", kdir_list_tmpfile}
// #else
//   const char *kdir_list_cmd("ls");
//   const char *kdir_list_args[] = {">", kdir_list_tmpfile}
// #endif


/* parse_params
 *
 * Parses the command-line parameters and returns the directory to parse and
 * the output file to write the email addresses to. (These default to '.' and
 * 'stripped_emails.txt', respectively.)
 *
 * If the output file already exists, the program prints an error message and
 * exits.
 **/
pair<string, string> parse_params(int argc, char **argv)
{
  pair<string, string> params;
  string &dir = params.first, &outfile = params.second;

  // get directory
  dir = (argc > 1) ? argv[1] : kdefault_dir;
  if (*dir.end() != kslash_char)
    dir += kslash_char;

  // get output file, check that it doesn't exist
  outfile = (argc > 2) ? argv[2] : kdefault_outfile;
  ifstream out_test(outfile.c_str());

  if (out_test.is_open()) {
    cout << "Output file '" << outfile << "' exists, overwrite? ";
    char c;
    cin >> c;
    if (tolower(c) != 'y')
      exit(0);
  }

  return params;
}



/* get_dir_list
 *
 * Gets a directory listing for the current directory (with a system call),
 * writes it to a temporary file, and opens the temporary file into the given
 * ifstream.
 *
 * Exits with an error if the temporary file cannot be opened for writing or
 * reading.
 */
void get_dir_list(const string &dir, ifstream &dir_list)
{
  // delete temporary file if it already exists
  string del_cmd(kdelete_cmd + " " + kdir_list_tmpfile);

  system(del_cmd.c_str());


  // build and execute shell command to get directory listing
  string dir_cmd(kdir_list_cmd + " " + dir + " > " + kdir_list_tmpfile);

  int retval = system(dir_cmd.c_str());

  if (retval != 0)
    err_exit("Could not write to temporary file: " + kdir_list_tmpfile);


  // open temporary file
  dir_list.open(kdir_list_tmpfile.c_str());
  if (!dir_list.is_open() || !dir_list.good())
    err_exit("Could not open temporary file: " + kdir_list_tmpfile);
}


int main(int argc, char **argv)
{
  set<cemail> emails;

  if (argc > 3)
    err_exit(kusage, 0);

  pair<string, string> params = parse_params(argc, argv);
  const string &dir = params.first, &outfile = params.second;

  // get directory listing
  ifstream dir_list;
  get_dir_list(dir, dir_list);


  string filename;
  cout << "Parsing";

  // strip each file
  while (dir_list.good()) {
    cout << "." << flush;
    getline(dir_list, filename);
    if (filename == kdir_list_tmpfile || filename == argv[0])
      continue;  // don't try to parse the tmp file or the executable

    ifstream in((dir + filename).c_str());
    strip_file(in, emails);
  }
  dir_list.close();


  // write to output file
  write_output(outfile, emails);

  cout << endl << emails.size() << " email addresses written to " << outfile
       << "." << endl;
  return 0;
}

#endif  /* #if 0 */
