/* File: QServer.cpp
 * Author: Ryan Barrett
 * --------------------
 * Implements the QServer class. See QServer.hpp for more information.
 */


#include "QServer.h"


/* FREE
 */
#define FREE(ptr)	if (ptr) free(ptr); (ptr) = NULL;


/* VERROR, BERROR, PERROR
 */
#define VERROR(e)	{ setError(e); return; }
#define BERROR(e)	{ setError(e); return false; }
#define PERROR(e)	{ setError(e); return NULL; }

/* WAIT_FOR
 */
#define WAIT_FOR(func) \
{ if (!(func)) return false; msgLoop(true); }


// msg loop function, in remote.cpp
DWORD msgLoop(bool waitingForResponse);




// QServer public methods


// ctor
QServer::QServer(char *addr, char *pass, int port) {
	DWORD optionVal;

	// set up internet handle
	internet = InternetOpen("QServer", INTERNET_OPEN_TYPE_PRECONFIG, NULL,
		NULL, NULL);
	if (!internet) VERROR(Q_ERR_I_OPEN);

	optionVal = TIMEOUT_MSECS;
	InternetSetOption(internet, INTERNET_OPTION_CONNECT_TIMEOUT, &optionVal,
		sizeof(DWORD));
	InternetSetOption(internet, INTERNET_OPTION_RECEIVE_TIMEOUT, &optionVal,
		sizeof(DWORD));
	InternetSetOption(internet, INTERNET_OPTION_SEND_TIMEOUT, &optionVal,
		sizeof(DWORD));
	InternetSetOption(internet, INTERNET_OPTION_DATA_RECEIVE_TIMEOUT,
		&optionVal, sizeof(DWORD));
	InternetSetOption(internet, INTERNET_OPTION_DATA_SEND_TIMEOUT, &optionVal,
		sizeof(DWORD));

	strcpy(this->addr, "");
	strcpy(this->pass, "");
	this->port = 0;
	error = -1;
	playlist = NULL;
	response = NULL;
	connected = false;
	playing = false;
	setError(Q_ERR_NONE);
}


// destructor
QServer::~QServer() {
	freePlaylist();
	InternetCloseHandle(internet);
}
	


bool QServer::connect(char *addr, char *pass, int port) {
	int prefixLen = strlen(HTTP_PREFIX);

	if (addr != NULL) strcpy(this->addr, addr);
	if (pass != NULL) strcpy(this->pass, pass);
	if (port != 0) this->port = port;

	connected = false;
	playing = false;

	// parse addr - strip leading "http://" if it exists
	if ((int)strlen(this->addr) > prefixLen &&
		strnicmp(this->addr, HTTP_PREFIX, prefixLen) == 0)
		strcpy(this->addr, this->addr + prefixLen);

	if (this->addr != NULL && this->pass != NULL && this->port != 0)
		return sendCmd(QC_GET_VER);
	else BERROR(Q_ERR_CONNECT_PARAM);
}



// status methods

bool QServer::isConnected() {
	return connected;
}


int QServer::getError() {
	return error;
}


char *QServer::getErrorMsg(int error) {
	switch (error) {
	case Q_ERR_NONE:			return Q_ERRM_NONE;
	case Q_ERR_MEM:				return Q_ERRM_MEM;
	case Q_ERR_CONNECT_PARAM:	return Q_ERRM_CONNECT_PARAM;
	case Q_ERR_HTTPQ:			return Q_ERRM_HTTPQ;
	case Q_ERR_TERMINATION:		return Q_ERRM_TERMINATION;
	case Q_ERR_TIMEOUT:			return Q_ERRM_TIMEOUT;
	case Q_ERR_RESPONSE:		return Q_ERRM_RESPONSE;
	case Q_ERR_PASS:			return Q_ERRM_PASS;
	case Q_ERR_CONNECT_END:		return Q_ERRM_CONNECT_END;
	case Q_ERR_I_OPEN:			return Q_ERRM_I_OPEN;
	case Q_ERR_I_OPEN_URL:		return Q_ERRM_I_OPEN_URL;
	case Q_ERR_I_QDA:			return Q_ERRM_I_QDA;
	case Q_ERR_I_READ_FILE:		return Q_ERRM_I_READ_FILE;
	case Q_ERR_I_READ_SIZE:		return Q_ERRM_I_READ_SIZE;
	case Q_ERR_I_BAD_ADDR:		return Q_ERRM_I_BAD_ADDR;
	case Q_ERR_I_NO_CON:		return Q_ERRM_I_NO_CON;
	case Q_ERR_PLAY_ON_EMPTY:	return Q_ERRM_PLAY_ON_EMPTY;
	case Q_ERR_I_RESPONSE_SIZE:	return Q_ERRM_I_RESPONSE_SIZE;
	default:					return Q_ERRM_UNKNOWN;
	}
}


void QServer::getResponse(char **ptr) {
	*ptr = response;
}



// command methods

bool QServer::getVer(char *buf, int n) {
	return getStr(QC_GET_VER, buf, n);
}



bool QServer::prev()	{
	return sendCmd(QC_PREV);
}

bool QServer::play() {
	if (playlistLen == 0) BERROR(Q_ERR_PLAY_ON_EMPTY);
	return sendCmd(QC_PLAY); }

bool QServer::pause()	{ return sendCmd(QC_PAUSE); }

bool QServer::stop()	{ return sendCmd(QC_STOP); }

bool QServer::next()	{ return sendCmd(QC_NEXT); }

bool QServer::isPlaying() {
	return playing;
}

bool QServer::updatePlaying() {
	int play = QR_STOPPED;
	bool success;

	success = getInt(QC_IS_PLAYING, &play);
	playing = (play == QR_PLAYING);
	return success;
}

bool QServer::getRepeat(bool *buf) {
	return getStatus(QC_SET_REPEAT, buf);
}

bool QServer::getShuffle(bool *buf) {
	return getStatus(QC_SET_SHUFFLE, buf);
}

bool QServer::setRepeat(bool repeat) {
	return setStatus(QC_SET_REPEAT, repeat);
}

bool QServer::setShuffle(bool shuffle) {
	return setStatus(QC_SET_SHUFFLE, shuffle);
}

bool QServer::clear()				{ return sendCmd(QC_CLEAR); }

bool QServer::listLen(int *buf)		{ return getInt(QC_LIST_LEN, buf); }

bool QServer::curPos(int *buf)		{ return getInt(QC_CUR_POS, buf); }

bool QServer::curTime(int *buf)		{ return getInt(QC_CUR_TIME, buf, "0"); }

bool QServer::curLen(int *buf)		{ return getInt(QC_CUR_TIME, buf, "1"); }

bool QServer::getTitle(char *buf, int n, int pos) {
	char arg[BUF_LEN];

	wsprintf(arg, "%d", pos);
	return getStr(QC_GET_TITLE, buf, n, arg);
}

bool QServer::getFile(char *buf, int n, int pos) {
	char arg[BUF_LEN];

	wsprintf(arg, "%d", pos);
	return getStr(QC_GET_FILE, buf, n, arg);
}

bool QServer::add(char *filename)	{ return sendCmd(QC_ADD, filename); }

bool QServer::setPos(int pos) {
	char arg[BUF_LEN];

	wsprintf(arg, "%d", pos);
	return sendCmd(QC_SET_POS, arg);
}


bool QServer::setTime(int ms) {
	char arg[BUF_LEN];

	wsprintf(arg, "%d", ms);
	return sendCmd(QC_SET_TIME, arg);
}



bool QServer::getPlaylist(bool refresh, char ***playlistPtr, int *lenPtr) {
	char *headptr, *tailptr, indBuf[10];
	int ind;

	if (!refresh) {
		if (playlistPtr) *playlistPtr = playlist;
		if (lenPtr) *lenPtr = playlistLen;
		return true;
	}

	freePlaylist();		// reset playlist storage
	if (!listLen(&playlistLen)) return false;
	if (playlistLen == 0) {
		*lenPtr = playlistLen;
		*playlistPtr = NULL;
		return true;
	}
	playlist = (char **)malloc((playlistLen + 1) * sizeof(char *));

	// d/l playlist
	if (!sendCmd(QC_GET_TITLE)) return false;

	// parse playlist
	headptr = response;
	while (tailptr = strstr(headptr, QR_BREAK)) {
		*tailptr = '\0';
		if (sscanf(headptr, "%[^.]. %*s", indBuf) != 1) return false;
		if (sscanf(indBuf, "%d", &ind) != 1) return false;
		headptr += strlen(indBuf) + 2;
		playlist[ind] = (char *)malloc((strlen(headptr) + 1) * sizeof(char));
		strcpy(playlist[ind], headptr);
		tailptr += 4;
		headptr = tailptr;
	}

	if (playlistPtr) *playlistPtr = playlist;
	if (lenPtr) *lenPtr = playlistLen;
	setError(Q_ERR_NONE);
	return true;
}


void QServer::freePlaylist() {
	if (!playlist) return;
	for (int i = 0; i < playlistLen; i++)
		FREE(playlist[i]);
	FREE(playlist);
}




// QServer protected methods

/* setError
 * --------
 * Sets the error and does some miscellaneous bookkeeping.
 */
void QServer::setError(int error) {
	char *r;

	// set error
	this->error = error;
	if (error < Q_ERR_CONNECT_END && error > Q_ERR_MEM) {
		connected = false;
		playing = false;
	}
	if (error == Q_ERR_NONE) return;

	// set response
	r = getErrorMsg(error);
	FREE(response);
	response = (char *)malloc(strlen(r) + 1);
	if (response)
		strcpy(response, r);
}


/* getInt, getStr, getStatus, setStatus
 * ------------------------------------
 *
 * Similar to accessors and modifiers for the httpQ server. getInt and getStr
 * send a command and write the returned integer or string, respectively.
 * getStatus sends a command and writes true or false, respectively. setStatus
 * sets a toggleable feature to true or false.
 */
bool QServer::getInt(char *cmd, int *buf, char *arg) {
	if (!sendCmd(cmd, arg)) return false;
	return (sscanf(response, "%d", buf) == 1);
}

bool QServer::getStr(char *cmd, char *buf, int n, char *arg) {
	if (!sendCmd(cmd, arg)) return false;
	strncpy(buf, response, n);
	buf[n - 1] = '\0';
	return true;
}

bool QServer::getStatus(char *cmd, bool *buf) {
	if (!sendCmd(cmd)) return false;
	if (!sendCmd(cmd)) return false;
	*buf = (strcmpi(response, QR_TRUE) == 0); // strcmpi is case insensitive
	return true;
}

bool QServer::setStatus(char *cmd, bool status) {
	bool cur;
	
	if (!getStatus(cmd, &cur)) return false;
	if (status != cur)
		return sendCmd(cmd);
	return TRUE;
}



/* sendCmd
 * -------
 * Sends the given command and argument strings to the httpQ server and waits
 * for a response. sendCmd returns true if the httpQ server responded correctly,
 * false otherwise. sendCmd also sets the connected var accordingly.
 */

bool QServer::sendCmd(char *cmd, char *arg) {
	char url[BUF_LEN];
	HINTERNET request;
	char *readptr;
	DWORD readsize, sentsize, tempsize;

	if (!isConnected() && cmd != QC_GET_VER) return false;

	// build url
	wsprintf(url, "http://%s:%d", addr, port);
	if (cmd[0] != '\0') wsprintf(url, "%s/%s?p=%s", url, cmd, pass);
	if (arg[0] != '\0') wsprintf(url, "%s&a=%s", url, arg);

	// check global offline mode, try to go online if offline
	DWORD conState = 0, sz = sizeof(DWORD);
	InternetQueryOption(NULL, INTERNET_OPTION_CONNECTED_STATE, &conState, &sz);
	if (conState & INTERNET_STATE_DISCONNECTED_BY_USER)
		if (!InternetGoOnline(url, GetDesktopWindow(), 0))
			BERROR(Q_ERR_I_NO_CON);

	// check connection, try to connect if offline
	if (!InternetCheckConnection(url, 0, 0)) {
		DWORD err = GetLastError();
		if (err == ERROR_NOT_CONNECTED || err == ERROR_INTERNET_DISCONNECTED)
			if (InternetAttemptConnect(0) != ERROR_SUCCESS)
				BERROR(Q_ERR_I_NO_CON);
	}

	// send request - pass this pointer as context value for callback
	request = InternetOpenUrl(internet, url, NULL, 0, INTERNET_FLAG_RELOAD,
		(DWORD)this);
	if (!request) {
		DWORD err = GetLastError();
		if (err == ERROR_INTERNET_TIMEOUT)
			BERROR(Q_ERR_TIMEOUT)
		else if (err == ERROR_INTERNET_DISCONNECTED)
			BERROR(Q_ERR_I_NO_CON)
		else if (err == ERROR_INTERNET_INVALID_URL ||
			err == ERROR_INTERNET_NAME_NOT_RESOLVED ||
			err == ERROR_INTERNET_CANNOT_CONNECT ||
			err == ERROR_INTERNET_SERVER_UNREACHABLE)
			BERROR(Q_ERR_I_BAD_ADDR)
		else BERROR(Q_ERR_I_OPEN_URL);
	}

	readsize = 0;
	FREE(response);
	while (TRUE) {
		//get data size
		if (!InternetQueryDataAvailable(request, &tempsize, NULL, NULL)) {
			if (GetLastError() == ERROR_INTERNET_TIMEOUT)
				BERROR(Q_ERR_TIMEOUT)
			else BERROR(Q_ERR_I_QDA);
		}
		if (tempsize == 0) break;
		if (readsize == 0) readsize = 1;	// make room for null terminator
		readsize += tempsize;

		//read data
		if (!(response = (char *)realloc(response, readsize)))
			BERROR(Q_ERR_MEM);
		readptr = response + readsize - tempsize - 1;
		if (!InternetReadFile(request, readptr, tempsize, &sentsize)) {
			if (GetLastError() == ERROR_INTERNET_TIMEOUT)
				BERROR(Q_ERR_TIMEOUT)
			else BERROR(Q_ERR_I_READ_FILE);
		}
		if (sentsize != tempsize)
			BERROR(Q_ERR_I_READ_SIZE);
		if (readsize > MAX_RESPONSE_LEN)	// response is too big
			BERROR(Q_ERR_I_RESPONSE_SIZE);
	}

	InternetCloseHandle(request);
	if (readsize <= 1) return false;

	// null terminate
	response[readsize - 1] = '\0';

	if (strstr(response, QR_BAD_PASS))
		BERROR(Q_ERR_PASS);

	setError(Q_ERR_NONE);
	connected = true;
	return true;
}

