<?php
/*
 * snarfed WordPress theme
 * http://snarfed.org/snarfed_wordpress_theme
 * Ryan Barrett <wordpress-theme@ryanb.org>
 * Public domain.
 */

/*
 * Remove lots of things that we don't want:
 * - access div in the header
 * - blog description (we replace it with our own below)
 * - an annoying inline stylesheet that the recent comments widget injects
 * - edit/delete/login/logout links
 * - meta navigation links
 * - misc javascript
 * etc.
 *
 * Note that some actions can't be removed directly in functions.php; have to
 * remove them indirectly like this. See the bottom of
 * http://themeshaper.com/thematic/guide/?page_id=10 .
 *
 * Also, some things are preserved on wp-admin requests because they're needed
 * there. (I originally preserved them on requests from localhost instead, with
 * $_SERVER['REMOTE_ADDR'] == '127.0.0.1', but that made them show up when
 * looking at normal pages on my local instance.)
 */

define('THEMATIC_COMPATIBLE_COMMENT_FORM', true);

function snarfed_remove_actions() {
  remove_action('thematic_header', 'thematic_blogdescription', 5);
  remove_action('thematic_header', 'thematic_access', 9);

  global $wp_widget_factory;
  remove_action('wp_head', array($wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style'));
}
add_action('init','snarfed_remove_actions');

function snarfed_thematic_show_pingback($orig) {
  return FALSE;
}
add_filter('thematic_show_pingback', 'snarfed_thematic_show_pingback');

function snarfed_disable_unless_admin($orig) {
  if (substr_count($_SERVER['REQUEST_URI'], '/wp-admin/'))
    return $orig;
  else
    return '';
}
add_filter('get_edit_post_link', 'snarfed_disable_unless_admin');
add_filter('get_delete_post_link', 'snarfed_disable_unless_admin');
add_filter('get_edit_comment_link', 'snarfed_disable_unless_admin');
add_filter('post_comments_link', 'snarfed_disable_unless_admin');
add_filter('thematic_postheader_posteditlink', 'snarfed_disable_unless_admin');
add_filter('thematic_postfooter_posteditlink', 'snarfed_disable_unless_admin');
add_filter('thematic_postmeta_editlink', 'snarfed_disable_unless_admin');
add_filter('comment_form_logged_in', 'snarfed_disable_unless_admin');
add_filter('comment_form_logged_in', 'snarfed_disable_unless_admin');
add_filter('comment_form_logged_in_after', 'snarfed_disable_unless_admin');
add_filter('wlwmanifest_link', 'snarfed_disable_unless_admin');
add_filter('login_url', 'snarfed_disable_unless_admin');
add_filter('logout_url', 'snarfed_disable_unless_admin');
add_filter('loginout', 'snarfed_disable_unless_admin');

add_filter('thematic_create_robots', 'snarfed_disable_unless_admin');
add_filter('thematic_head_scripts', 'snarfed_disable_unless_admin');

remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');

function get_blog_tld() {
  preg_match("%https?://([^/]+)%", get_bloginfo('url'), $matches);
  return $matches[1];
}

# allow anonymous (ie not logged in) comments via xmlrpc
# http://codex.wordpress.org/XML-RPC_wp#wp.newComment
function snarfed_xmlrpc_allow_anonymous_comments($orig) {
  return TRUE;
}
add_filter('xmlrpc_allow_anonymous_comments',
           'snarfed_xmlrpc_allow_anonymous_comments');

/*
 * If openid delegation is configured in wp-config.php, add OpenID tags.
 */
function snarfed_add_openid($orig) {
  ?>
  <link rel="openid2.provider" href="<?php print OPENID_DELEGATION_PROVIDER ?>" />
  <link rel="openid2.local_id" href="<?php print OPENID_DELEGATION_LOCAL_ID ?>" />
  <?php
}
if (defined("OPENID_DELEGATION_PROVIDER") && defined("OPENID_DELEGATION_LOCAL_ID") &&
    get_blog_tld() != "localhost") {
  add_action('wp_head', 'snarfed_add_openid');
}

/*
 * If ajax search is configured in wp-config.php, add OpenID tags.
 */
function snarfed_add_ajax_search($orig) {
  ?>
  <script type="text/javascript" src="http://www.google.com/uds/api?file=uds.js&v=1.0&key=<?php print GOOGLE_AJAX_SEARCH_API_KEY ?>"></script>
  <script type="text/javascript" src="/w/wp-content/themes/snarfed/ajax_search.js"></script>
  <?php
}
// comment out '&& get_blog_tld()...' for testing ajax search stuff locally
if (defined('GOOGLE_AJAX_SEARCH_API_KEY') && get_blog_tld() != 'localhost') {
  add_action('wp_head', 'snarfed_add_ajax_search');
}

/*
 * Shutter permalinks. Convert Shutter links in NextGEN Gallery and normal pages
 * to permalinks by adding fragments with the local shutter image id, e.g.
 * #shutter_25. Then, if the current page has a Shutter permalink fragment,
 * display that image in Shutter.
 */
function snarfed_shutter_permalinks() {
  ?>
  <script type="text/javascript">
    jQuery(document).ready(function() {
      // add permalinks to shutter image links
      var shutter_onclick_re = /shutterReloaded\.make\("(\d+)"\)/;
      var document_base_url = document.URL.replace(/#[^#?&]*$/, "");
      for (i = 0; i < document.links.length; i++) {
        link = document.links[i];
        match = shutter_onclick_re.exec(link.onclick);
        if (match && !link.hash) {
          link.href = document_base_url + "#shutter_" + match[1];
        }
      }
    
      // if this page is a shutter permalink, display the shutter image
      match = window.location.hash.match(/^#shutter_(\d+)$/);
      if (match) {
        shutterReloaded.make(match[1]);
      }
    });
  </script>
  <?php
}
add_action('wp_head', 'snarfed_shutter_permalinks');


/* Google Analytics. According to
 * http://www.google.com/support/analytics/bin/answer.py?answer=174090 , this
 * should (ideally) go *after* all other scripts in the <head> tag.
 */
function snarfed_add_google_analytics($orig) {
  ?>
  <script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', '<?php print GOOGLE_ANALYTICS_ID ?>']);
    _gaq.push(['_trackPageview']);
  
    (function() {
      var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
  </script>
  <?php
}
if (defined('GOOGLE_ANALYTICS_ID')) {
  add_action('wp_head', 'snarfed_add_google_analytics');
}

function snarfed_add_google_plus_publisher($orig) {
  ?>
  <link href="https://plus.google.com/103651231634018158746" rel="publisher" />
  <?php
}
add_action('wp_head', 'snarfed_add_google_plus_publisher');

/* Facebook Insights. Associate this domain with a user, page, or a.
 * http://www.facebook.com/insights/
 */
function snarfed_add_facebook_insights($orig) {
  ?>
  <meta property="<?php print FACEBOOK_INSIGHTS_PROPERTY ?>"
        content="<?php print FACEBOOK_INSIGHTS_CONTENT ?>" />
  <?php
}

if (defined('FACEBOOK_INSIGHTS_PROPERTY') && defined('FACEBOOK_INSIGHTS_CONTENT')) {
  add_action('wp_head', 'snarfed_add_facebook_insights');
}

/*
 * Add google-code-prettify and inject its onload into the body tag.
 * Not currently used because I mainly wanted it for Emacs Lisp, and its LISP
 * syntax highlighting isn't very good. :/
 */
/*function snarfed_add_prettify($orig) {
  ?>
  <link href="/google-code-prettify/prettify.css" type="text/css" rel="stylesheet" />
  <script type="text/javascript" src="/google-code-prettify/prettify.js"></script>
  <?php
}
add_action('wp_head', 'snarfed_add_prettify');

function childtheme_override_body() {
  echo '<body class="';
  thematic_body_class();
  echo '" onload="prettyPrint()">';
  }*/

/*
 * Linkify the blog description.
 */
function snarfed_blogdescription() {
  ?>
  <div id="blog-description"><a href="about">
    <?php bloginfo('description'); ?>
  </a></div>
  <?php
}
add_action('thematic_header', 'snarfed_blogdescription', 5);

/*
 * Customize the "Read more..." text.
 */
function snarfed_more_text($orig) {
  return '<p />Read more...';
}
add_filter('more_text', 'snarfed_more_text');

/*
 * Inject YARPP related posts/pages after the content.
 */
function snarfed_yarpp() {
  ?>
  <div class="yarpp">
  <?php if (function_exists('related_pages')) { related_pages(); } ?>
  </div>
  <?php
}
add_action('thematic_abovecomments', 'snarfed_yarpp');


/* --------------------------------------------------------------
 * Entry meta
 * -------------------------------------------------------------- */

/*
 * Show meta on pages as well as posts.
 */
function snarfed_postheader($orig) {
  if (is_404()) {
    return thematic_postheader_posttitle();        
  } else {
    return thematic_postheader_posttitle() . thematic_postheader_postmeta();
  }
}
add_filter('thematic_postheader', 'snarfed_postheader');


/*
 * Add extra stuff to entry-meta, but only if we're display a single post or
 * page.
 */
function snarfed_build_postmeta($label, $value, $separator) {
  return "\n<span class=\"meta-sep meta-sep-snarfed meta-sep-" .
    $label . '">' . $separator . "</span>\n" .
    '<span class="' . $label . '">' . $value . '</span>';
}

function snarfed_postmeta($orig) {
  // No post meta stuff on index page
  if (is_page_template("posts-and-pages.php")) {
    return '';
  }

  $extra = '';
  if (get_the_time('j F Y') !== get_the_modified_time('j F Y')) {
    $updated_str = '<span class="entry-updated">' .
      get_the_modified_date() . '</span>';
    $extra .= snarfed_build_postmeta('updated', $updated_str, '<br />last updated');
  }

  if (is_single() || is_page()) {
    // $extra .= snarfed_build_postmeta('raw', '<a href="' . get_permalink() . '.txt">raw</a>', '<br />');
    // $extra .= snarfed_build_postmeta('history', '<a href="#todo">history</a>', '|');
  }

  $suffix = '</div><!-- .entry-meta -->';
  return str_replace($suffix, $extra . $suffix, $orig);
}
add_filter('thematic_postheader_postmeta', 'snarfed_postmeta');


/* --------------------------------------------------------------
 * Search
 * Run a google ajax site search for the url, using ajax_search.js.
 * Also do this on 404s.
 * -------------------------------------------------------------- */

// disable wordpress's db query for the search. we replace it with google ajax
// site search.
function snarfed_search_posts_request($orig) {
  return is_search() ? null : $orig;
}

// Returns the search query *if* the current request is a search or 404.
function snarfed_get_search_query() {
  if (is_404()) {
    return ereg_replace("(\?.*)?$", "",
             trim(ereg_replace("[_!?:,()/]", " ", $_SERVER['REQUEST_URI'])));
  } elseif (is_search()) {
    // i tried to use $wp_query->get('s') or ->query_vars['s'], but no luck.
    // http://codex.wordpress.org/Function_Reference/WP_Query
    // also for trimming:
    // wp_specialchars(stripslashes(trim(ereg_replace("[_!?:,()/]", " ", ...)
    return $_GET['s'];
  } else {
    return null;
  }
}

// i originally used childtheme_override_{search_loop,404_content}(), they only
// get run in if there are search results from the db query. details in
// thematic/search.php.
function snarfed_search_and_404_abovecontent() {
  if ($query = snarfed_get_search_query()) {
    if (is_404()) {
      ?>
      <h1 class="entry-title">Not Found</h1>
      <p class="entry-content">Sorry, <?php echo $query ?>
        was not found. Here are some related pages.</p>
      <?php
    }

    ?>
    <script type="text/javascript">
    window.onload=function() {
      site_search('<?php echo get_blog_tld() ?>', '<?php echo $query ?>');
    }
    </script>
    <?php
  }
}

// this is the fallback for users who don't have js. it's in the abovepost hook
// and not the abovecontent hook so it's inside div#content, which ajax_search
// replaces.
function snarfed_abovepost() {
  if ($query = snarfed_get_search_query()) {
    ?>
    <a href="http://google.com/search?sitesearch=<?php echo get_blog_tld() ?>&q=<?php echo $query ?>">
      Search for <?php echo $query ?></a>
    <?php
  }
}

function snarfed_search_field_value($orig) {
  return 'Search';
}

function snarfed_thematic_search_submit($orig) {
  return '';
}

if (defined('GOOGLE_AJAX_SEARCH_API_KEY')) {
  add_filter('posts_request', 'snarfed_search_posts_request');
  add_action('thematic_abovecontent', 'snarfed_search_and_404_abovecontent');
  add_action('thematic_abovepost', 'snarfed_abovepost');
  add_filter('search_field_value', 'snarfed_search_field_value');
  add_filter('thematic_search_submit', 'snarfed_thematic_search_submit');
}


/*
 * On a 404, if the request is a prefix of a post or page name, WordPress will
 * "guess" that that's what you meant and redirect there. Disable that.
 */
function snarfed_no_404_guess_redirect($redirect_url)
{
  return is_404() ? false : $redirect_url;
}
add_filter('redirect_canonical', 'snarfed_no_404_guess_redirect');


/* --------------------------------------------------------------
 * Comments
 * -------------------------------------------------------------- */

/*
 * Pages need the 'comments' custom field to allow comments. Set that
 * automatically.
 * TODO: do this in blogpost.sh?
 */
function snarfed_add_comments_value($orig) {
  global $id;
  add_post_meta($id, 'comments', true, true /* unique */);
  return $orig;
}
add_filter('thematic_postheader', 'snarfed_add_comments_value');


/*
 * Hide the comment form behind Javascript.
 */
function snarfed_post_comment_link() {
  ?>
  <script type="text/javascript">
  function show_comment_form() {
    document.getElementById('commentform').style.display = 'block';
    document.getElementById('comment-toggle').style.display = 'none';
    window.scrollBy(0, 500);
    return false;
  }
  </script>
  
  <p id="comment-toggle">
    <a href="#commentform" onclick="return show_comment_form();">
      Post a comment...</a></p>
  <?php
}
add_action('comment_form_before', 'snarfed_post_comment_link');

/*
 * Tweak comments meta. Show time only if the comment was posted today,
 * otherwise show date only.
 */
function snarfed_commentmeta($orig) {
  $time = (date('d/m/Y') == get_comment_date('d/m/Y'))
    ? get_comment_time() : get_comment_date();
  return '<div class="comment-meta">' . $time .
    ' <a class="comment-permalink" href="' . get_comment_link() . '">#</a></div>';
}
add_filter('thematic_commentmeta', 'snarfed_commentmeta');

/*
 * Add a recent comments widget filter so I can tweak it by removing comment
 * author and adding icon.
 *
 * The recent comments widget code is at wp-includes/default-widgets.php:598.
 *
 * looks like the widget_recent_comment filter was removed in WP 3.0. :/ I was
 * able to use the get_comment_author_link filter to do something similar, but
 * that's too broad: it also happens when displaying comments normally, in the
 * admin pages, etc. grr.
 *
 * Also note that I can't just use the list-style-image CSS property, like I do
 * with the actual comments themselves on pages, since the ul.recentcomments
 * list is display: inline, which won't show list bullet images.
 *
 * Finally used this, inspired by the Widget Logic plugin and this forum post:
 * http://wordpress.org/support/topic/insert-a-ltbr-gt-in-the-recent-comments-widget-via-functionsphp
 */
function snarfed_add_recent_comments_widget_filter(){
  global $wp_registered_widgets;
  foreach ($wp_registered_widgets as $id => $widget) {
    if ($widget['name'] == 'Recent Comments') {
      array_push($wp_registered_widgets[$id]['params'], $id);
      $wp_registered_widgets[$id]['callback_redirect'] = $wp_registered_widgets[$id]['callback'];
      $wp_registered_widgets[$id]['callback'] = 'recent_comments_widget_redirected';
    }
  }
}
add_action('wp_head', 'snarfed_add_recent_comments_widget_filter');

function recent_comments_widget_redirected() {
  global $wp_registered_widgets;
  $params=func_get_args();
  $id=array_pop($params);
  $callback=$wp_registered_widgets[$id]['callback_redirect'];
  ob_start();
  call_user_func_array($callback, $params);
  $widget_content = ob_get_contents();
  ob_end_clean();
  echo apply_filters('widget_content', $widget_content, $id);
}

function snarfed_recent_comments_remove_authors($orig) {
  return preg_replace(
    '/(<li class="recentcomments">).+ on (<a[^>]+>)([^ <]+)([ <])/U',
    '$1$2<nobr><img src="/w/wp-content/themes/snarfed/images/comment_16.png" />$3</nobr>$4',
    $orig);
}
add_filter('widget_content', 'snarfed_recent_comments_remove_authors');

/*
 * Add the "bypostauthor" class to comments that claim the blog's URL as their
 * own.
 */
function snarfed_comment_add_bypostauthor($orig) {
  if (get_comment_author_url() == get_bloginfo('url') ||
      get_comment_author_url() == get_bloginfo('url') . '/') {
    $orig[] = 'bypostauthor';
  }

  return $orig;
}
add_filter('comment_class', 'snarfed_comment_add_bypostauthor');

/*
 * If there are no comments, make the link say 'Comment', not 'Leave a comment'.
 */
function snarfed_postfooter_postcomments($orig) {
  $orig = str_replace('</a>', '...</a>', $orig);
  return str_replace('Leave a comment', 'Comment', $orig);
}
add_filter('thematic_postfooter_postcomments', 'snarfed_postfooter_postcomments');


/* --------------------------------------------------------------
 * Posts and Pages template
 * -------------------------------------------------------------- */
function childtheme_override_category_archives() {
  return false;
}
function childtheme_override_archivesopen() {
  return false;
}
function childtheme_override_archivesclose() {
  return false;
}

/*
 * Add the post date to each post's link, outside of the link itself.. Have to
 * parse this out of the link html because i don't know of a way to get at the
 * post itself, or its id, inside a get_archives_link or the_title filter.
 */
function snarfed_add_date_header($orig) {
  global $snarfed_add_date_header_last_year;
  preg_match("/<a href='[^']*(\d{4})-\d{2}-\d{2}/", $orig, $matches);
  if ($matches[1] != $snarfed_add_date_header_last_year) {
    $orig = '<h3>' . $matches[1] . ':</h3>' . $orig;
    $snarfed_add_date_header_last_year = $matches[1];
  }
  return $orig;
}
add_filter('get_archives_link', 'snarfed_add_date_header');

/*
 * Show the posts and pages archives, separately. The first div is list of all
 * posts, ordered by date descending. The second div is a list of all pages,
 * ordered alphabetically.
 */
function childtheme_override_monthly_archives() {
?>
  <div id="posts-and-pages-posts" class="posts-and-pages">
    <ul>
      <?php
        /* defined in wp-includes/general-template.php */
        wp_get_archives('type=postbypost')
      ?>
    </ul>
  </div>

  <div id="posts-and-pages-pages" class="posts-and-pages">
    <h3>Pages:</h3>
      <?php
        /* defined in wp-includes/post-template.php. also see wp_list_pages() */
    wp_list_pages(array('title_li' => null))
      ?>
  </div>
<?php
}


/* Add CSS to RSS feed.
 *
 * This doesn't actually work in feed readers. I need to embed styles in the
 * HTML tags. :/
 *
 * Background:
 * http://mondaybynoon.com/20060814/beginning-to-style-your-rss-feed/
 * http://wordpress.org/support/topic/xml-css-style
 * http://core.trac.wordpress.org/ticket/1380
 */
// function add_css_to_rss() {
//   echo '<?xml-stylesheet type="text/css" href="' . RSS_CSS_STYLESHEET . '" ?' . '>';
// }
