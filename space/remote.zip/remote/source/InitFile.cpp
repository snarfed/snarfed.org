/* File: InitFile.cpp
 * Author: Ryan Barrett
 * --------------------
 * Implementation of the InitFile class. See InitFile.h for more info.
 */

#include "InitFile.h"


/* FREE, DEL
 */
#define FREE(ptr)	if (ptr) free(ptr); (ptr) = NULL;
#define DEL(ptr)	if (ptr) delete (ptr); (ptr) = NULL;


/* VERROR, BERROR, PERROR
 */
#define VERROR(e)	{ error = (e); return; }
#define BERROR(e)	{ error = (e); return false; }
#define PERROR(e)	{ error = (e); return NULL; }
#define NOERR()		{ error = IF_ERR_NONE; }




// InitFile public methods


/* ctor
 */
InitFile::InitFile(char *filename, char *section) {
	// zero out members
	this->filename = this->section = NULL;
	numLines = allocLines = 0;
	lines = NULL;

	// check and copy filename and section
	if (!filename || strlen(filename) == 0)
		VERROR(IF_ERR_BAD_FILENAME);
	if (!section || strlen(section) == 0)
		VERROR(IF_ERR_BAD_SECTION);

	if (!(this->filename = new char[strlen(filename) + 1]))
		VERROR(IF_ERR_MEM);
	if (!(this->section = new char[strlen(section) + 1]))
		VERROR(IF_ERR_MEM);
	strcpy(this->filename, filename);
	strcpy(this->section, section);

	// read file
	if (!read())
		return;

	NOERR();
}


/* destructor
 */
InitFile::~InitFile() {
	DEL(filename);
	DEL(section);
	freeLines();
}


/* getValue
 */
template <typename T> bool InitFile::getValue(char *key, T *value) {
	int index;
	double valBuf;

	// find line
	if ((index = findKey(key)) < 0)
		BERROR(IF_ERR_KEY_NOT_FOUND);
	if (sscanf(lines[index].value, "%f", valBuf) != 1)
		BERROR(IF_ERR_CANNOT_CONVERT);

	// copy value
	*value = (T)valBuf;
	NOERR();
	return true;
}

// overridden (more or less) for char *
bool InitFile::getValue(char *key, char *value, size_t size) {
	int index;

	// find line
	if ((index = findKey(key)) < 0)
		BERROR(IF_ERR_KEY_NOT_FOUND);

	// copy value
	strncpy(value, lines[index].value, size);
	value[size - 1] = '\0';

	NOERR();
	return true;
}


/* getNumLines
 */
int InitFile::getNumLines() {
	return numLines;
}


/* getKey
 */
bool InitFile::getKey(int lineNo, char *key, size_t size) {
	if (lineNo < 0 || lineNo > numLines)
		BERROR(IF_ERR_BAD_LINENO);

	strncpy(key, lines[lineNo].key, size);
	key[size - 1] = '\0';
	NOERR();
	return true;
}


/* setValue
 */
template <typename T> bool InitFile::setValue(char *key, T value) {
	char valBuf[MAX_LINE_LEN + 1];

	sprintf(valBuf, "%d", value);
	return addLine(key, valBuf);
}

// overridden for char *
bool InitFile::setValue(char *key, char *value) {
	return addLine(key, value);
}


/* write
 */
bool InitFile::write() {
	FILE *file;

	if (!(file = fopen(filename, "wt")))
		BERROR(IF_ERR_BAD_FILENAME);

	// write section header and lines
	fprintf(file, "%c%s%c\n", SECTION_PREFIX, section, SECTION_SUFFIX);
	for (int i = 0; i < numLines; i++)
		fprintf(file, "%s=%s\n", lines[i].key, lines[i].value);

	fclose(file);
	NOERR();
	return true;
}

/* getError
 */
int InitFile::getError() {
	return error;
}


/* getErrorMsg
 */
char *InitFile::getErrorMsg(int error) {
	switch (error) {
	case IF_ERR_NONE:			return IF_ERRM_NONE;
	case IF_ERR_MEM:			return IF_ERRM_MEM;
	case IF_ERR_BAD_FILENAME:	return IF_ERRM_BAD_FILENAME;
	case IF_ERR_BAD_SECTION:	return IF_ERRM_BAD_SECTION;
	case IF_ERR_BAD_LINE:		return IF_ERRM_BAD_LINE;
	case IF_ERR_KEY_NOT_FOUND:	return IF_ERRM_KEY_NOT_FOUND;
	case IF_ERR_CANNOT_CONVERT:	return IF_ERRM_CANNOT_CONVERT;
	case IF_ERR_BAD_LINENO:		return IF_ERRM_BAD_LINENO;
	default:					return IF_ERRM_UNKNOWN;
	}
}



// Initfile protected methods


/* read
 * ----
 * Reads in a section fron an initfile and stores the key/value pairs.
 */
bool InitFile::read() {
	FILE *file;
	char line[MAX_LINE_LEN + 1], keyBuf[MAX_LINE_LEN + 1],
		valBuf[MAX_LINE_LEN + 1];

	if (!section)
		BERROR(IF_ERR_BAD_SECTION);
	if (!(file = fopen(filename, "rt")))
		BERROR(IF_ERR_BAD_FILENAME);

	// find section
	while (fscanf(file, " %[^\n]\n", line) != EOF) {
		if (line[0] == SECTION_PREFIX)
			if (_strnicmp(section, line + 1, strlen(section)) == 0)
				break;
	}

	// read in lines
	freeLines();
	while (fscanf(file, " %[^\n]\n", line) != EOF) {
		if (strlen(line) == 0)
			continue;
		if (line[0] == SECTION_PREFIX)
			break;

		// parse into key and value, add line
		if (sscanf(line, "%[^=]=%[^\n]\n", keyBuf, valBuf) != 2)
			continue;
		addLine(keyBuf, valBuf);
	}
	if (numLines == 0)
		BERROR(IF_ERR_BAD_SECTION);

	fclose(file);
	NOERR();
	return true;
}


/* addLine
 * -------
 * Adds a line with the given key and value. If the key exists, the value is
 * simply overwritten. If the key doesn't exist, a new line is created.
 */
bool InitFile::addLine(char *key, char *value) {
	int index;

	// check if key exists
	index = findKey(key);
	if (index < 0) {				// new key
		index = numLines;
		if (!growLines())
			return false;
		numLines++;
		lines[index].key = new char[strlen(key) + 1];
		strcpy(lines[index].key, key);
	} else
		DEL(lines[index].value);	// existing key

	// set value
	lines[index].value = new char[strlen(value) + 1];
	strcpy(lines[index].value, value);

	NOERR();
	return true;
}


/* findKey
 * -------
 * Returns the index of the line that matches the given key, or -1 if the key
 * is not found.
 */
int InitFile::findKey(char *key) {
	for (int i = 0; i < numLines; i++)
		if (strcmp(key, lines[i].key) == 0)
			return i;

	return -1;
}


/* growLines
 * ---------
 * Reallocates the lines array if it is at full capacity.
 */
bool InitFile::growLines() {
	if (numLines == allocLines) {
		lines = (struct line *)realloc(lines, (allocLines += GROW_BY) *
			sizeof(line));
		if (!lines) BERROR(IF_ERR_MEM);
	}

	NOERR();
	return true;
}


	
/* freeLines
 * ---------
 * Frees the lines array and sets numLines and allocLines to 0.
 */
void InitFile::freeLines() {
	for (int i = 0; i < numLines; i++) {
		DEL(lines[i].key);
		DEL(lines[i].value);
	}
	FREE(lines);
	numLines = allocLines = 0;
}


