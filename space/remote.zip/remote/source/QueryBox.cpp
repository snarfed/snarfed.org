/* File: QueryBox.cpp
 * Author: Ryan Barrett
 * --------------------
 *
 * Implements a class for a standard dialog box that prompts for a string.
 * See QueryBox.hpp for more details.
 */


#include "QueryBox.h"


// struct: params
struct params {
	char response[QB_MAX_LEN];
	char prompt[QB_MAX_LEN];
};


// public methods

bool QueryBox(HINSTANCE hInstance, HWND hwnd, char *prompt, char *response,
			  int n) {
	struct params p;
	bool success;

	if (hInstance == NULL || hwnd == NULL || prompt == NULL ||
		response == NULL || n <= 0 || strlen(prompt) > QB_MAX_LEN)
		return false;

	strncpy(p.prompt, prompt, QB_MAX_LEN);
	p.prompt[QB_MAX_LEN - 1] = '\0';

	success = (DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_QUERYBOX),
		hwnd, (DLGPROC)QueryProc, (LPARAM)&p) == IDOK);
	if (success) {
		strncpy(response, p.response, n);
		response[n - 1] = '\0';
	}

	return success;
}



// protected methods

BOOL CALLBACK QueryProc(HWND hdlg, UINT msg, WPARAM wParam,
								   LPARAM lParam) {
	static struct params *pPtr = NULL;

	switch (msg) {

	case WM_INITDIALOG:	//startup
		pPtr = (struct params *)lParam;
		SendDlgItemMessage(hdlg, IDC_PROMPT, WM_SETTEXT, 0, (LPARAM)pPtr->prompt);
		return true;

	case WM_COMMAND:	// ok or cancel

		switch (LOWORD(wParam)) {
		case IDOK:
			*(WORD *)(pPtr->response) = QB_MAX_LEN - 1;
			SendDlgItemMessage(hdlg, IDC_RESPONSE, EM_GETLINE, 0, (DWORD)pPtr->response);
			pPtr->response[QB_MAX_LEN - 1] = '\0';

			// fall through

		case IDCANCEL:
			EndDialog(hdlg, wParam);
			return true;
		}

	default: break;		// other message, don't process
	}

	return false;	// message was not processed
}