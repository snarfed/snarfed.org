/* File: polyRenderer.cpp
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Implements the polyRenderer class. For more information, see polyRenderer.h.
 */


#include "polyRenderer.h"




/* ctor
 */
polyRenderer::polyRenderer() {}


/* dtor
 */
polyRenderer::~polyRenderer() {}



/* render
 */
void polyRenderer::render(voxelmap *map, float cx, float cy, float cz, int ctheta) {
	struct voxel **v;
	float x, y, z;			// voxel coords as floats in the OpenGL world
	float vsize, vheight;	// size and height of a single voxel

	assert(map);
	assert(cx >= 0 && cx < map->size && cz >= 0 && cz < map->size);

	// set up voxel sizes
	v = map->voxels;
	vsize = 1.0 / map->size;
	vheight = 1.0 / 256;

	for (int i = 0; i < map->size; i++) {
		for (int j = 0; j < map->size; j++) {
			for (int k = 0; k < 50; k++) {
			x = (float)i / map->size;
			z = (float)j / map->size;
			y = ((float)v[i][j].height - k) * vheight;

			if (y < 0)
				continue;

			/* draw sides of voxel */
//			SetColor(cubies[i][j][z].sides[s]);
//			glColor3f(v[i][j].r, v[i][j].g, v[i][j].b);
			glColor3f(y, y, y);
			drawRect(x + vsize, y, z, right, vsize, vheight);
			drawRect(x, y + vheight, z, top, vsize, vsize);
			drawRect(x, y, z, front, vsize, vheight);
			drawRect(x, y, z - vsize, left, vsize, vheight);
			drawRect(x + vsize, y, z, bottom, vsize, vsize);
			drawRect(x + vsize, y, z - vsize, back, vsize, vheight);
			}
		}
	}
}


/* drawRect
 * --------
 * Draws a 3D rectangle at the point (x, y, z). The orientation is clockwise
 * to conform to OpenGL's GL_CW winding for culling faces.
 */
void polyRenderer::drawRect(float x, float y, float z, side s, float width, float height) {
	glBegin(GL_POLYGON);

	switch (s) {
	case left:	/* invert width for z orientation, then fall through */
		width = -width;
	case right:
		glVertex3f(x, y, z);
		glVertex3f(x, y + height, z);
		glVertex3f(x, y + height, z - width);
		glVertex3f(x, y, z - width);
		break;
	case bottom:	/* invert width for x orientation, then fall through */
		width = -width;
	case top:
		glVertex3f(x, y, z);
		glVertex3f(x, y, z - height);
		glVertex3f(x + width, y, z - height);
		glVertex3f(x + width, y, z);
		break;
	case back:	/* invert width for y orientation, then fall through */
		width = -width;
	case front:
		glVertex3f(x, y, z);
		glVertex3f(x, y + height, z);
		glVertex3f(x + width, y + height, z);
		glVertex3f(x + width, y, z);
		break;
	default: Err("invalid side\n");
	}

	glEnd();
}



/* resize
 */
void polyRenderer::resize(int width, int height) {
}