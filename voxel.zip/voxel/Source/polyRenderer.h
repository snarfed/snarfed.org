/* File: polyRenderer.h
 * Author: Ryan Barrett (rbarrett@stanford.edu)
 * --------------------------------------------
 * CS148 Fall 2000, Assignment 4.
 *
 * Defines the polyRenderer class, which uses a polygon-based Z-buffer
 * technique to render a voxel map. OpenGL is used as the 3D graphics API.
 * Voxels are rendered as cubes, and a square poly is drawn for each of a
 * voxel's six faces.
 *
 * The polyRenderer class is a subclass of renderer. It implements all of
 * renderer's virtual methods.
 *
 * This is a *very naive* way to render voxels. This is just for testing, and
 * should not be used in a finished product.
 */

#ifndef _POLYRENDERER_H
#define _POLYRENDERER_H

#include "glut.h"
#include "util.h"
#include "renderer.h"
#include "voxelmap.h"


/* Type: side
 * ----------
 * Side of a cube.
 */
typedef enum sidet { right = 0, top, front, left, bottom, back } side;



/* polyRenderer
 */
class polyRenderer : public renderer {

public:

	/* ctor
	 */
	polyRenderer();

	/* dtor
	 */
	~polyRenderer();

	/* render
	 */
	void render(voxelmap *map, float cx, float cy, float cz, int ctheta);

	/* resize
	 */
	void resize(int width, int height);

protected:

	void drawRect(float x, float y, float z, side s, float width, float height);
};



#endif /* _POLYRENDERER_H */