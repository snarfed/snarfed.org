/* File: Jump.h
 * Author: Ryan Barrett
 * --------------------
 * 
 * Implements the jump to file dialog box that prompts for a string. The
 * playlist is dynamically narrowed down to only that string. This lets the
 * user easily jump to a song by entering only a few characters of that
 * song's title or artist name.
 */

#ifndef _JUMP_H
#define _JUMP_H


#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include "QServer.h"


// constants
#define BUF_LEN		200
#define WHITESPACE	" \t"

// FREE
#define FREE(ptr)	free(ptr); (ptr) = NULL

/* JumpBox
 * -------
 * Shows the jump dialog box. Returns true on success, false on failure. On
 * success, the playlist position to jump to is written into the int buffer.
 */
bool JumpBox(HINSTANCE hInstance, HWND hwnd, QServer *server, int *pos);



#endif /* _JUMP_H */
