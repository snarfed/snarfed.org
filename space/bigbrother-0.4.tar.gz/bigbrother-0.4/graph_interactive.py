#!/usr/bin/python2.2
#

from pyx import graph, data

#a = graph.linaxis(painter = graph.axispainter(nameattrs = None)) # for single bars
#points = data.data([(1, 1, 2), (2, 1, 2), (3, 2, 3), (4, 2, 3), (5, 4, 6)])
points = data.data([(1, 1), (2, 1), (3, 2), (4, 2), (5, 4)])
#points = data.data([(1, 1, 2, 2, 4)])
d = graph.data(points, x = 1, y = 3)
#d.append([graph.data(points, x = 1, y = 3)])
#d = [graph.data(points, x="month", y="min"), graph.data(points, x = 1, y = 3)]

g = graph.graphxy(width = 8, height = 4, x = graph.linaxis(), y = graph.linaxis())
#g = graph.graphxy(ypos = 4.5, width = 8, height = 4, x = a)
g.plot(d)  #, graph.bar(stacked = 1))
g.writetofile("graphtest")
