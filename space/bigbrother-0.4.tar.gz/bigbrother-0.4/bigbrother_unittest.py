#!/usr/bin/python
#
# BigBrother
# http://snarfed.org/space/bigbrother
# Copyright 2003 Ryan Barrett <bigbrother@ryanb.org>
#
# File: bigbrother_unittest.py
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

"""
Unit tests for bigbrother.py.
"""

import sys
import deluxetest
import bigbrother
from bigbrother import *

LINES = """
Tue 2003-10-07 08:14:37 in the shower
Tue 2003-10-07 08:24:48 Online
Tue 2003-10-07 08:30:50 voting then train
Tue 2003-10-07 10:58:14 at work
Tue 2003-10-07 18:11:51 on the train
Tue 2003-10-07 18:29:53 at work
Tue 2003-10-07 18:30:14 on the train
Tue 2003-10-07 20:49:34 Online
Tue 2003-10-07 23:33:02 doing nothing. i love my life!
Tue 2003-10-07 23:41:53 Online
Tue 2003-10-07 23:41:53 asleep
Wed  2003-10-08 07:38:19 Online
Wed  2003-10-08 07:38:20 in the shower
Wed  2003-10-08 07:57:00 on the train
"""

MSGS_BY_TIME = [(1065539677, 'Tue', 'in the shower'),
                (1065540288, 'Tue', 'Online'),
                (1065540650, 'Tue', 'voting then train'),
                (1065549494, 'Tue', 'at work'),
                (1065575511, 'Tue', 'on the train'),
                (1065576593, 'Tue', 'at work'),
                (1065576614, 'Tue', 'on the train'),
                (1065584974, 'Tue', 'Online'),
                (1065594782, 'Tue', 'doing nothing. i love my life!'),
                (1065595313, 'Tue', 'asleep'),
                (1065623899, 'Wed', 'Online'),
                (1065623900, 'Wed', 'in the shower')]

TIMES_BY_MSG = {
  'Online': [(1065540288, 'Tue', 362), (1065584974, 'Tue', 9808),
             (1065623899, 'Wed', 1)],
  'asleep': [(1065595313, 'Tue', 28586)],
  'at work': [(1065549494, 'Tue', 26017), (1065576593, 'Tue', 21)],
  'doing nothing. i love my life!': [(1065594782, 'Tue', 531)],
  'in the shower': [(1065539677, 'Tue', 611),
                    (1065623900, 'Wed', 1120)],
  'on the train': [(1065575511, 'Tue', 1082), (1065576614, 'Tue', 8360)],
  'voting then train': [(1065540650, 'Tue', 8844)] }

FREQS = { 'Online': 3, 'at work': 2, 'doing nothing. i love my life!': 1,
          'in the shower': 2, 'on the train': 2, 'voting then train': 1,
          'asleep': 1 }

LENGTHS = { 'Online': 10171, 'at work': 26038, 'asleep': 28586,
            'doing nothing. i love my life!': 531, 'in the shower': 1731,
            'on the train': 9442, 'voting then train': 8844 }

AVG_LENGTHS = { 'Online': 3390 + float(1) / 3, 'at work': 13019,
            'doing nothing. i love my life!': 531, 'in the shower': 865.5,
            'on the train': 4721, 'voting then train': 8844, 'asleep': 28586 }


ONLINE_DAY_DIST = {
  secs_since_midnight(8, 0, 0): 2,
  secs_since_midnight(8, 30, 0): 1,
  secs_since_midnight(9, 0, 0): 1,
  secs_since_midnight(20, 30, 0): 1,
  secs_since_midnight(21, 0, 0): 1,
  secs_since_midnight(21, 30, 0): 1,
  secs_since_midnight(22, 0, 0): 1,
  secs_since_midnight(22, 30, 0): 1,
  secs_since_midnight(23, 0, 0): 1,
  secs_since_midnight(23, 30, 0): 1,
  secs_since_midnight(0, 0, 0): 1,
  secs_since_midnight(7, 30, 0): 1 }

ONLINE_WED_DIST = {
  secs_since_midnight(0, 0, 0): 1,
  secs_since_midnight(7, 30, 0): 1,
  secs_since_midnight(8, 0, 0): 1 }

ASLEEP_TUE_DIST = {
  secs_since_midnight(23, 30, 0): 1 }

ASLEEP_WED_DIST = {
  secs_since_midnight(0, 0, 0): 1,
  secs_since_midnight(0, 30, 0): 1,
  secs_since_midnight(1, 0, 0): 1,
  secs_since_midnight(1, 30, 0): 1,
  secs_since_midnight(2, 0, 0): 1,
  secs_since_midnight(2, 30, 0): 1,
  secs_since_midnight(3, 0, 0): 1,
  secs_since_midnight(3, 30, 0): 1,
  secs_since_midnight(4, 0, 0): 1,
  secs_since_midnight(4, 30, 0): 1,
  secs_since_midnight(5, 0, 0): 1,
  secs_since_midnight(5, 30, 0): 1,
  secs_since_midnight(6, 0, 0): 1,
  secs_since_midnight(6, 30, 0): 1,
  secs_since_midnight(7, 0, 0): 1,
  secs_since_midnight(7, 30, 0): 1,
  secs_since_midnight(8, 0, 0): 1 }

ONLINE_WEEK_DIST = { 0: 0, 1: 2, 2: 1, 3: 0, 4: 0, 5: 0, 6: 0 }

ASLEEP_WEEK_DIST = { 0: 0, 1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 0 }



class bigbrotherUnitTest(deluxetest.TestCase):

  def setUp(self):
    bigbrother.set_defaults()
    bigbrother.config.set('BigBrother', 'sample_interval', `30 * 60`)
    bigbrother.config.set('BigBrother', 'discard_blips', 'false')
    read_awaylog(LINES)


  def test_read_awaylog(self):
    self.assertEqual(bigbrother.msgs_by_time, MSGS_BY_TIME)
    self.assertEqual(bigbrother.times_by_msg, TIMES_BY_MSG)

    bigbrother.config.set('BigBrother', 'discard_blips', 'true')
    read_awaylog(LINES)

    MSGS_BY_TIME.insert(9, (1065595313, 'Tue', 'Online'))
    self.assertEqual(bigbrother.msgs_by_time, MSGS_BY_TIME)
    TIMES_BY_MSG['Online'].insert(2, (1065595313, 'Tue', 0))
    self.assertEqual(bigbrother.times_by_msg, TIMES_BY_MSG)

#    copy = list(msgs_by_time)
#    self.assertEqual(copy.sort(), msgs_by_time)


  def test_calc_freqs(self):
    self.assertEqual(calc_freqs(), FREQS)


  def test_calc_lengths(self):
    self.assertEqual(calc_lengths(), LENGTHS)


  def test_total_lengths(self):
    self.assertEqual(total_length(), 85343)


  def test_calc_avgs(self):
    self.assertEqual(calc_avg_lengths(), AVG_LENGTHS)

  def test_get_tier(self):
    self.assertEqual([], bigbrother.get_tier({}, 5))
    self.assertEqual([], bigbrother.get_tier(FREQS, 0))
    self.assertIsTier(bigbrother.get_tier(FREQS, 1), 1)
    self.assertIsTier(bigbrother.get_tier(FREQS, 2), 2)
    self.assertIsTier(bigbrother.get_tier(FREQS, 7), 7)
    self.assertIsTier(bigbrother.get_tier(FREQS, 20), 7)

  def test_calc_day_distribution(self):
    online_all = calc_day_distribution('Online')
    self.assertEqual(online_all, ONLINE_DAY_DIST)
    online_wed = calc_day_distribution('Online', ['Wed'])
    self.assertEqual(online_wed, ONLINE_WED_DIST)
    asleep_tue = calc_day_distribution('asleep', ['Tue'])
    self.assertEqual(asleep_tue, ASLEEP_TUE_DIST)
    asleep_wed = calc_day_distribution('asleep', ['Wed'])
    self.assertEqual(asleep_wed, ASLEEP_WED_DIST)

  def test_calc_week_distribution(self):
    self.assertEqual(calc_week_distribution('Online'),
                     ONLINE_WEEK_DIST)
    self.assertEqual(calc_week_distribution('asleep'),
                     ASLEEP_WEEK_DIST)

  #
  # test the bigbrother utility fns
  #
  def test_prettyprint(self):
    self.assertEqual(prettyprint([]), '')
    self.assertEqual(prettyprint([[], [], []]), '\n\n')
    self.assertEqual(prettyprint([['asdf']]), '"asdf"')
    self.assertEqual(prettyprint([[1]]), '1')
    self.assertEqual(prettyprint([[1.234], [5.6789]]), '1.23\n5.68')
    self.assertEqual(prettyprint([[1], [2], [3]]), '1\n2\n3')
    self.assertEqual(prettyprint([['a'], [3], [1.2]]), '"a" \n3   \n1.20')
    self.assertEqual(prettyprint([['abc'], ['d'], ['ef']]),
                     '"abc"\n"d"  \n"ef" ')
    self.assertEqual(
      prettyprint([['abc', 1, 234], [1, 'abcd', 234], [1, 234, 'abcde']]),
'''"abc" 1      234    
1     "abcd" 234    
1     234    "abcde"''')

    # different sized rows should throw an assertion
    try:
      prettyprint([[1], [2, 3]])
      fail('allowed rows with different sizes')
    except AssertionError:
      pass


  def test_tomorrow(self):
    self.assertEqual(tomorrow('Mon'), 'Tue')
    self.assertEqual(tomorrow('Tue'), 'Wed')
    self.assertEqual(tomorrow('Wed'), 'Thu')
    self.assertEqual(tomorrow('Thu'), 'Fri')
    self.assertEqual(tomorrow('Fri'), 'Sat')
    self.assertEqual(tomorrow('Sat'), 'Sun')
    self.assertEqual(tomorrow('Sun'), 'Mon')

  def test_secs_since_midnight(self):
    self.assertEqual(secs_since_midnight(0, 0, 0), 0)
    self.assertEqual(secs_since_midnight(0, 0, 5), 5)
    self.assertEqual(secs_since_midnight(0, 0, 61), 61)
    self.assertEqual(secs_since_midnight(0, 5, 3), 5 * 60 + 3)
    self.assertEqual(secs_since_midnight(0, 65, 3), 65 * 60 + 3)
    self.assertEqual(secs_since_midnight(1, 3, 3), 3600 + 3 * 60 + 3)
    self.assertEqual(secs_since_midnight(25, 3, 3), 25 * 3600 + 3 * 60 + 3)

  def test_secs_to_time(self):
    self.assertEqual(secs_to_time(0), '00:00')
    self.assertEqual(secs_to_time(5), '00:00')
    self.assertEqual(secs_to_time(61), '00:01')
    self.assertEqual(secs_to_time(5 * 60 + 3), '00:05')
    self.assertEqual(secs_to_time(65 * 60 + 3), '01:05')
    self.assertEqual(secs_to_time(1 * 3600 + 3 * 60 + 3), '01:03')
    self.assertEqual(secs_to_time(13 * 3600 + 3 * 60 + 3), '13:03')

  def test_normalize(self):
    self.assertAllClose(normalize([]), [])
    self.assertAllClose(normalize([0, 0, 0]), [0, 0, 0])
    self.assertAllClose(normalize([0, 1, 0]), [0, 1, 0])
    self.assertAllClose(normalize([3, 5, 4, 9, 1, 3]),
                        [.12, .20, .16, .36, .04, .12])
    self.assertAllClose(normalize([1.9, 98.5, 30.4, 63.8, 5.4]),
                        [.0095, .4925, .152, .319, .027])

  def test_sort_by_value(self):
    self.assertEqual(sort_by_value({}), [])
    self.assertEqual(sort_by_value({0: 0}), [(0, 0)])
    self.assertEqual(sort_by_value({'a': 1, 'b': 3, 'c': 0}),
                     [('c', 0), ('a', 1), ('b', 3)])
    self.assertEqual(sort_by_value({1: 'c', 3: 'a', 0: 'b'}),
                     [(3, 'a'), (0, 'b'), (1, 'c')])


  #
  # utility fns
  #
  def assertIsTier(self, tier, size):
    """ Raises an assertion if the parameter is not a tier of FREQS of the
    given size.
    """
    self.assertEqual(size, len(tier))

    # does the tier start with the most frequent msg?
    maxfreq = max(FREQS.values())
    self.assertEqual(maxfreq, FREQS[tier[0]])
    
    # is the rest of it a tier?
    freqs = [FREQS[msg] for msg in tier]
    sorted = freqs
    sorted.sort()
    sorted.reverse()
    self.assertEqual(sorted, freqs)

    
if __name__ == '__main__':
  deluxetest.main()
