/* File: QServer.hpp
 * Author: Ryan Barrett
 * --------------------
 * Defines the QServer class. Used to open a connection to an httpQ server,
 * send it various messages, and get information back.
 */


#ifndef _QSERVER_H
#define _QSERVER_H

#include <windows.h>
#include <wininet.h>
#include <stdio.h>
#include "string.h"


#define HTTPQ_ABOUT			""
#define HTTP_PREFIX			"http://"
#define MAX_ADDR_LEN		80
#define MAX_PASS_LEN		80
#define MAX_PORT			65535
#define MAX_RESPONSE_LEN	20000
#define BUF_LEN				200
#define ERROR_STR_LEN		80
#define TIMEOUT_MSECS		5000
#define TIMEOUT_MSG			"Timed out."

// httpQ command strings
#define QC_CONNECT		""
#define QC_GET_VER		"getversion"
#define QC_PREV			"prev"
#define QC_PLAY			"play"
#define QC_PAUSE		"pause"
#define QC_STOP			"stop"
#define QC_NEXT			"next"
#define QC_SET_REPEAT	"repeat"
#define QC_SET_SHUFFLE	"shuffle"
#define QC_CLEAR		"delete"
#define QC_ADD			"playfile"
#define QC_LIST_LEN		"getlistlength"
#define QC_CUR_POS		"getlistpos"
#define QC_CUR_TIME		"getoutputtime"
#define QC_GET_TITLE	"getplaylisttitle"
#define QC_GET_FILE		"getplaylistfile"
#define QC_SET_POS		"setplaylistpos"
#define QC_SET_TIME		"jumptotime"
#define QC_IS_PLAYING	"isplaying"

// httpQ response strings
#define QR_OK			"OK "
#define QR_TRUE			"TRUE"
#define QR_FALSE		"FALSE"
#define QR_BREAK		"<br>"
#define	QR_STOPPED		0
#define	QR_PLAYING		1
#define	QR_PAUSED		3
#define QR_WAITING		"waiting for response..."
#define QR_BAD_PASS		"incorrect password"


// error codes
#define Q_ERR_NONE				0
#define Q_ERR_MEM				1
#define Q_ERR_CONNECT_PARAM		2
#define Q_ERR_HTTPQ				3
#define Q_ERR_TERMINATION		4
#define Q_ERR_RESPONSE			6
#define Q_ERR_PASS				7
#define Q_ERR_CONNECT_END		20

#define Q_ERR_TIMEOUT			21
#define Q_ERR_I_OPEN			22
#define Q_ERR_I_OPEN_URL		23
#define Q_ERR_I_QDA				24
#define Q_ERR_I_READ_FILE		25
#define Q_ERR_I_READ_SIZE		26
#define Q_ERR_I_BAD_ADDR		27
#define Q_ERR_I_NO_CON			28
#define Q_ERR_I_RESPONSE_SIZE	29
#define Q_ERR_PLAY_ON_EMPTY		51

// error messages
#define Q_ERRM_UNKNOWN			"Unknown error."
#define Q_ERRM_NONE				"No error."
#define Q_ERRM_MEM				"Out of memory."
#define Q_ERRM_CONNECT_PARAM	"Invalid connection parameters."
#define Q_ERRM_HTTPQ			"httpQ error."
#define Q_ERRM_TERMINATION		"Connection terminated."
#define Q_ERRM_TIMEOUT			"Timed out waiting for response from server."
#define Q_ERRM_RESPONSE			"Invalid response from server."
#define Q_ERRM_PASS				"Incorrect password."
#define Q_ERRM_CONNECT_END		"Connection closed by server."
#define Q_ERRM_I_OPEN			"InternetOpen failed."
#define Q_ERRM_I_OPEN_URL		"InternetOpenUrl failed."
#define Q_ERRM_I_QDA			"InternetQueryDataAvailable failed."
#define Q_ERRM_I_READ_FILE		"InternetReadFile failed."
#define Q_ERRM_I_READ_SIZE		"Incorrect response size from server."
#define Q_ERRM_I_BAD_ADDR		"Invalid address or port, could not connect."
#define Q_ERRM_I_NO_CON			"No network connection."
#define Q_ERRM_I_RESPONSE_SIZE	"Server returned too much information."
#define Q_ERRM_PLAY_ON_EMPTY	"Playlist is empty."


class QServer
{
public:

	/* ctor
	 * ----
	 * Can take an address, password, port, any combination of these, or none.
	 */
	QServer(char *addr = NULL, char *pass = NULL, int port = 0);


	/* destructor
	 * ----------
	 * Frees any memory still allocated.
	 */
	~QServer();


	/* connect
	 * -------
	 * httpQ command: none
	 *
	 * Tries to connect to an httpQ server. since httpQ communication is
	 * connectionless, connect just queries the server without a command.
	 * If the response string matches HTTPQ_ABOUT, the server is up. connect
	 * returns TRUE if the server is up, FALSE if there is an error connecting.
	 * If connect has been called previously, omitting any of the arguments
	 * will use the previous value for that argument.
	 *
	 * All of the other public QServer methods have a return type of bool. If
	 * there is an error sending a command to the server (or the server doesn't
	 * respond), the associated method returns FALSE. If the command succeeds,
	 * the method returns TRUE.
	 */
	bool connect(char *addr = NULL, char *pass = NULL, int port = 0);


	/* isConnected
	 * -----------
	 * Accessor, returns TRUE if there is a live connection to an httpQ server.
	 * Since httpQ connections are connectionless, this is TRUE if the server
	 * responded to the last command request, FALSE otherwise.
	 */
	bool isConnected();


	/* getError
	 * --------
	 * Returns the error code of the last error, or -1 if no errors have
	 * occurred yet.
	 */
	int getError();

		
	/* getErrorMsg
	 * -----------
	 * Returns the error message associated with the given error code.
	 */
	char *getErrorMsg(int error);


	/* getPlaylist
	 * -----------
	 * Gets a pointer to the playlist (an array of strings). If refresh is
	 * true, getPlaylist queries the server for the title of each song in
	 * sequence. A pointer to the playlist (an array of strings) is written
	 * to playlistPtr (if it's not NULL), and the playlist length is written
	 * to lenPtr (if it's not NULL). getPlaylist returns true on success, false
	 * otherwise.
	 */
	bool getPlaylist(bool refresh, char ***playlistPtr, int *lenPtr);


	/* getResponse
	 * -----------
	 * Writes a pointer to the raw response string from the last command sent.
	 */
	void getResponse(char **ptr);


	/* getVer
	 * ------
	 * httpQ command: getversion
	 *
	 * Gets the version of the current httpQ server and writes it to the given
	 * buffer. Writes a maximum of n characters.
	 */
	bool getVer(char *buf, int n);


	/* previous, play, pause, stop, next
	 * ---------------------------------
	 * httpQ commands: prev, play, pause, stop, next
	 *
	 * These functions control playback.
	 */
	bool prev();
	bool play();
	bool pause();
	bool stop();
	bool next();


	/* isPlaying
	 * ---------
	 * httpQ command: isplaying
	 *
	 * Writes true if the server is playing, false if it is stopped or paused.
	 * This is since the last time the server was checked with updatePlaying().
	 */
	bool isPlaying();


	/* updatePlaying
	 * -------------
	 * Checks to see if the server is playing or not. This is called whenever a
	 * command is sent to the server. When isPlaying() is called, the return value
	 * is the server's response when updatePlaying() was last called.
	 */
	bool updatePlaying();


	/* getShuffle, getRepeat
	 * ---------------------
	 * httpQ commands: shuffle, repeat
	 *
	 * Accessors for shuffle and repeat. The buffer is set to the current
	 * value of shuffle or repeat, respectively.
	 */
	bool getShuffle(bool *buf);
	bool getRepeat(bool *buf);

	
	/* setShuffle, setRepeat
	 * ---------------------
	 * httpQ commands: shuffle, repeat
	 *
	 * Modifiers for shuffle and repeat. They turn shuffle or repeat on if the
	 * argument is TRUE, off if the argument is FALSE.
	 */
	bool setRepeat(bool repeat);
	bool setShuffle(bool shuffle);


	/* clear
	 * -----
	 * httpQ command: delete
	 *
	 * Clears the current playlist.
	 */
	bool clear();


	/* add
	 * ---
	 * httpQ command: playfile
	 *
	 * Adds a file to the playlist. If the file is a playlist, all of the
	 * included songs are added.
	 */
	bool add(char *filename);


	/* listLen
	 * -------
	 * httpQ command: getlistlength
	 *
	 * Writes the length of the current playlist (in songs) to the buffer.
	 */
	bool listLen(int *buf);


	/* curPos, curTime, curLen
	 * -----------------------
	 * httpQ commands: getlistpos, getoutputtime
	 *
	 * Writes the playlist position or time (in milliseconds) or length
	 * (in seconds) of the current song to the buffer.
	 */
	bool curPos(int *buf);
	bool curTime(int *buf);
	bool curLen(int *buf);


	/* getTitle, getFile
	 * -----------------
	 * httpQ commands: getplaylisttitle, getplaylistfile
	 *
	 * Writes the title or filename of the song at position pos to the given
	 * buffer. Writes a maximum of n characters.
	 */
	bool getTitle(char *buf, int n, int pos);
	bool getFile(char *buf, int n, int pos);


	/* setPos
	 * ------
	 * httpQ command: setplaylistpos
	 *
	 * Plays the song at the given playlist position.
	 */
	bool setPos(int pos);


	/* setTime
	 * -------
	 * httpQ command: jumptotime
	 *
	 * Jumps to the specified time in the current song. The time is given in
	 * milliseconds.
	 */
	bool setTime(int ms);


protected:
	// protected members
	char **playlist;
	int playlistLen;

	char addr[MAX_ADDR_LEN], pass[MAX_PASS_LEN];
	char *response;
	int port;
	bool connected;
	bool playing;
	HINTERNET internet;
	int error;

	// protected methods
	void setError(int error);
	bool sendCmd(char *cmd = "", char *arg = "");
	bool getInt(char *cmd, int *buf, char *arg = "");
	bool getStr(char *cmd, char *buf, int n, char *arg = "");
	bool getStatus(char *cmd, bool *buf);
	bool setStatus(char *cmd, bool status);
	void freePlaylist();

};


#endif  /* _QSERVER_H */
